// ─── Example prompts ──────────────────────────────────────────────────────────
// Three things a person could actually say to Claude to put each tool or skill
// to work. Rendered as click-to-copy sentences in the expanded Supercharge
// cards, so each one is written as a complete, paste-ready request in the
// user's voice, not as a description of the tool.
//
// Kept apart from catalog.js so the catalog stays about *what* each entry is,
// and so copy can be edited here without touching the structural fields.
// catalog.js merges these in and validate() fails the build if any tool or
// skill is missing exactly three.
'use strict';

const TOOL_EXAMPLES = {
  // Connect & diagnose
  list_targets: [
    'Is Claude connected to my Figma file and Chrome right now?',
    'Before we start, check which NiCE Designer clients are live.',
    'Can you see my browser tab, or only Figma?',
  ],
  get_diagnostics: [
    'Nothing is connecting. Figure out why and tell me what to click.',
    'Run diagnostics on the NiCE Designer bridge and explain the result in plain English.',
    'The plugin says connected but your tools fail. Check the connection health.',
  ],
  check_libraries: [
    'Is the Lyra library actually linked to this Figma file?',
    'Before I convert anything, check that the design library is attached.',
    'Why are my conversions using bundled values? Check the linked libraries.',
  ],
  analytics_summary: [
    'Show me which NiCE Designer tools I use the most.',
    'How many minutes have I spent in the plugin, and is analytics uploading?',
    'What are my top skills this month?',
  ],
  list_skills: [
    'What skills do you have available through NiCE Designer?',
    'Show me every skill that helps with research.',
    'Which skills were built by other people on the team?',
  ],
  get_skill: [
    'Load the a11y-triage skill and follow it.',
    'Read the full instructions for the lyra-visual-patterns skill before we convert this page.',
    'Pull up the north-star-fox skill so I can see what it does.',
  ],
  find_capability: [
    'Is there anything in NiCE Designer that helps with color contrast?',
    'Find me a tool or skill for dark mode problems.',
    'I need to hand this to a developer. What could help?',
  ],

  // Choose what to work on
  get_selection_info: [
    'What do I have selected right now?',
    'Confirm which element you will audit before you start.',
    'Tell me what the inspected element is on this page.',
  ],
  select_page: [
    'Zoom back out and audit the whole page again.',
    'Clear the inspected element so the next audit covers everything.',
    'Reset the scope to the full page.',
  ],
  start_inspect: [
    'Turn on inspect mode so I can click the element I mean.',
    'Let me point at the button I want you to look at.',
    'Start element picking in Chrome.',
  ],
  stop_inspect: [
    'Turn off inspect mode but keep what I picked.',
    'I am done picking elements, stop inspecting.',
    'Leave inspect mode without clearing my selection.',
  ],
  focus_node: [
    'Jump to the layer with the contrast issue in Figma.',
    'Select node 123:456 and scroll to it.',
    'Take me to the first off-token fill you found.',
  ],
  screenshot_page: [
    'Take a screenshot of this page and tell me what looks off.',
    'Capture the selected artboard so you can compare it to the live site.',
    'Grab an image of the current view before we change anything.',
  ],

  // Score & measure
  run_full_audit: [
    'Audit this page against Lyra and give me the compliance score.',
    'Run a full audit on my selected frame and show the issues by category.',
    'How compliant is this screen with SOL?',
  ],
  lyra_compliance_report: [
    'Write me a Lyra compliance report for this page.',
    'Give me something I can share with my team about how Lyra-ready this screen is.',
    'Produce a compliance report, not a raw issue dump.',
  ],
  audit_colors: [
    'Which colors on this page are not Lyra tokens?',
    'Check my fills and strokes for wrong-system or unbound colors.',
    'How many of the color issues here can be fixed with one click?',
  ],
  audit_text_styles: [
    'Do all the text nodes here match Lyra type tokens?',
    'Which headings are using the wrong size or weight?',
    'Find text that is close to a token but not quite on it.',
  ],
  audit_spacing: [
    'Find spacing that is off the Lyra scale.',
    'Which paddings and gaps are on-scale but not bound to a variable?',
    'Check the spacing in the selected frame.',
  ],
  audit_radius: [
    'Are my corner radii on the Lyra scale?',
    'Find rounded corners that are not bound to a radius token.',
    'Audit the border radius on this page.',
  ],
  audit_components: [
    'Which instances in this file come from the wrong library?',
    'Find components I should swap for the Lyra equivalent.',
    'Audit the components in my selected frame.',
  ],
  audit_accessibility: [
    'Check this page for accessibility problems.',
    'Scan for contrast failures and tap targets that are too small.',
    'Audit headings, landmarks, alt text and focus outlines on this screen.',
  ],
  scan_variables: [
    'Which variables are bound in this frame, and what should be but is not?',
    'List every property here that is missing a variable binding.',
    'Show me the variable coverage for my selection.',
  ],
  get_audit_filters: [
    'Which issue types are currently excluded from my score?',
    'Show me my active audit filters.',
    'Why does my score look higher than I expected? Check the filters.',
  ],
  set_audit_filters: [
    'Exclude spacing issues from my audit score.',
    'Turn the radius checks back on.',
    'Ignore component issues for now and keep that setting for next time.',
  ],

  // Fix everything at once
  convert_page_to_lyra: [
    'Convert this page to Lyra, tokens only, and show me a dry run first.',
    'Do a full Lyra conversion on this page and tell me how much the score moves.',
    'What would converting this page to Lyra change? Do not apply anything yet.',
  ],
  migrate_to_lyra: [
    'Migrate my selected frame to Lyra, colors and type only.',
    'Run a dry-run Lyra migration on this artboard and show the score change.',
    'Convert this frame to Lyra and keep the layout as it is.',
  ],
  convert_colors: [
    'Bind every exact-match color to its Lyra token and leave the rest for me.',
    'Convert the colors in this frame to Lyra, dry run first.',
    'Apply all the suggested color tokens.',
  ],
  convert_text_styles: [
    'Apply Lyra type tokens to all the text here except the logo.',
    'Convert the text styles on this page, dry run first.',
    'Which text nodes would change if you converted to Lyra type?',
  ],
  fix_spacing: [
    'Snap the off-scale spacing here to the nearest Lyra token.',
    'Bind spacing variables to every unbound padding and gap in this frame.',
    'Fix the spacing and tell me the before and after.',
  ],
  fix_radius: [
    'Bind radius tokens to every corner that is off the scale.',
    'Fix the border radius on this page and show me what changed.',
    'Dry-run a radius fix on my selection.',
  ],
  fix_accessibility: [
    'Fix the accessibility issues that can be fixed automatically.',
    'Apply the contrast fix to this element.',
    'Which a11y issues would you fix, and which need my judgement?',
  ],
  convert_component: [
    'Swap this button for the Lyra button, and tell me the name first.',
    'Replace the selected instance with its Lyra equivalent.',
    'Is there a Lyra version of this component I can swap in?',
  ],
  convert_mode: [
    'Switch this frame to dark mode tokens.',
    'Re-bind the selection to Lyra light mode.',
    'Show me this screen in dark mode using the real tokens.',
  ],
  generate_multi_system: [
    'Make a Lyra copy of this SOL screen next to the original.',
    'Duplicate my selection and convert the copy to SOL.',
    'Give me both design system versions of this frame side by side.',
  ],

  // Fix one thing at a time
  apply_single_color: [
    'Change just this fill to the Lyra primary color token.',
    'Bind the selected stroke to the right border token.',
    'Apply the hex #1A73E8 to this one fill.',
  ],
  apply_single_text: [
    'Make only this heading use the Lyra title token.',
    'Apply the body type token to the selected text.',
    'Set this one label to 14px.',
  ],
  apply_single_spacing: [
    'Set this padding to the nearest Lyra spacing token.',
    'Bind the gap on this frame to a spacing variable.',
    'Change just this margin to 16.',
  ],
  apply_single_radius: [
    'Give this card the Lyra medium radius token.',
    'Set all four corners on the selection to the same radius token.',
    'Change just the top-left corner radius.',
  ],
  revert_single_color: [
    'Undo the color change on that one fill.',
    'Put the stroke back to what it was before.',
    'Revert the last single color edit.',
  ],
  revert_single_text: [
    'Undo the type change on that heading.',
    'Restore the original text style on the node I just changed.',
    'Revert that one text edit.',
  ],
  revert_single_spacing: [
    'Put that padding back the way it was.',
    'Undo the spacing change on this frame.',
    'Revert the last single spacing edit.',
  ],
  revert_single_radius: [
    'Undo the radius change on that card.',
    'Restore the original corner radius.',
    'Revert the last single radius edit.',
  ],

  // Undo & history
  undo_last_conversion: [
    'Undo that last conversion.',
    'That page conversion went wrong. Roll it back.',
    'Take me back to before the bulk fix.',
  ],
  get_conversion_history: [
    'Show me everything we have changed so far.',
    'List the history of applied conversions.',
    'Where am I in the change history?',
  ],
  revert_to_history_index: [
    'Go back to the state after the second change.',
    'Step the design back to history entry 3.',
    'Undo everything after the color conversion but keep the color conversion.',
  ],

  // Restyle the live page
  apply_css_overrides: [
    'Try making the primary buttons on this page use the Lyra blue.',
    'Inject a CSS override so the header uses the dark surface color.',
    'Show me the selectors you would change, then apply them.',
  ],
  clear_css_overrides: [
    'Remove all the CSS you injected.',
    'Put the page back to how it shipped.',
    'Clear the overrides and reload the original look.',
  ],
  polish_page: [
    'Turn on dark mode simulation for this page.',
    'Show hover overlays and token-styled scrollbars.',
    'Polish this page so it looks right for a demo.',
  ],
  a11y_overlay: [
    'Highlight every tap target that is too small.',
    'Simulate what this page looks like with deuteranopia.',
    'Flag the colors on this page that are not tokens.',
  ],

  // Spec Mode
  extract_dev_details: [
    'Give me the dev specs for the element I selected.',
    'What are the size, fills, type and layout for this layer?',
    'I need the CSS for this button. What is it?',
  ],
  extract_all_css: [
    'Export the CSS for everything in this frame.',
    'Give me one CSS document for the whole selection.',
    'Generate CSS I can hand to a developer for this screen.',
  ],
  extract_token_css: [
    'Give me the Lyra tokens as CSS custom properties.',
    'Export the SOL design tokens as CSS variables.',
    'I need the dark mode token CSS for Lyra.',
  ],
  export_design_tokens: [
    'Export the full Lyra color and type palette.',
    'Give me the SOL spacing and radius tokens as data.',
    'Show me the Lyra dark mode colors.',
  ],
  sync_storybook_components: [
    'Sync the components from our Storybook.',
    'Pull the latest Lyra component list from Storybook into the plugin.',
    'Refresh the component inventory, replacing what is there.',
  ],
  get_storybook_sync_status: [
    'When did Storybook last sync?',
    'How many components did the last sync bring in?',
    'Is my component inventory up to date?',
  ],

  // Decide & review
  run_ux_eval: [
    'Run a UX eval on this page before it goes to dev.',
    'Here is the Figma link and the Jira ticket. Is this ready for the next step?',
    'Evaluate this design against the 10 prioritization questions.',
  ],

  // Keep the server current
  check_for_updates: [
    'Is my NiCE Designer connector up to date?',
    'Check whether there are new commits for the MCP server.',
    'What would I get if I updated the connector?',
  ],
  install_update: [
    'Show me the pending updates, then install them.',
    'Update the local MCP server to the latest version.',
    'Pull in the newest changes and run npm install.',
  ],
  reinstall_connector: [
    'My connector is out of date. Relaunch the installer.',
    'Reinstall the NiCE Designer connector for me.',
    'The Supercharge page says to reinstall. Do that.',
  ],

  // Escape hatch
  call_plugin: [
    'Send this raw message to the plugin and show me what comes back.',
    'None of the tools cover this. Call the plugin directly.',
    'Forward a custom UIMessage to Figma.',
  ],
};

const SKILL_EXAMPLES = {
  'claude-design-prompt': [
    'Turn the audit results for this page into a Claude Design prompt.',
    'Write me a prompt I can paste into Claude Design to fix this screen in Lyra.',
    'Audit this frame and give me a design brief for Claude Design, accessibility first.',
  ],
  'a11y-triage': [
    'I have hundreds of accessibility issues on this page. Where do I start?',
    'Triage the a11y issues here and give me the top 10 to fix first.',
    'Which accessibility problems affect the most users?',
  ],
  'manual-fixes-checklist': [
    'What is left for me to fix by hand after the auto-fixers run?',
    'Dry-run every fixer and list only what still needs a human.',
    'Make me a manual fixes checklist for this page.',
  ],
  'lyra-visual-patterns': [
    'What should a correctly converted Lyra page look like?',
    'Load the Lyra visual patterns before we convert this screen.',
    'How should Lyra tables, panels and chips look in dark mode?',
  ],
  'figma-element-css': [
    'What is the CSS for this layer?',
    'Turn the selected Figma node into production CSS with Lyra tokens.',
    'Write CSS for this card using token variables wherever they match.',
  ],
  'browser-element-specs': [
    'What are the design specs for the element I inspected?',
    'Annotate every raw value on this element with its nearest token.',
    'Give me a spec sheet for this button.',
  ],
  'figma-chrome-parity': [
    'Does the live site actually match the Figma?',
    'Diff this artboard against the page that implements it.',
    'Find every place the build drifted from the design in color, type and spacing.',
  ],
  'artboard-to-page': [
    'Make this live page look like my selected artboard.',
    'Show me the mapping from artboard layers to page selectors before applying.',
    'Push the artboard styling onto the page as CSS overrides.',
  ],
  'dark-mode-parity': [
    'Does this page work in dark mode?',
    'Audit the colors in light, then dark, and tell me what breaks.',
    'Check dark mode parity and put the page back how it was.',
  ],
  'token-candidates': [
    'Which of these custom values should become Lyra tokens?',
    'Find recurring raw values on this page worth promoting.',
    'Rank the custom colors and spacing we use most often.',
  ],
  'ux-eval': [
    'Is this ready to go to dev? Run a UX eval.',
    'Evaluate this design and tell me pass, pass with conditions, or not yet.',
    'Run the 10 questions on this feature using the Jira ticket as context.',
  ],
  'north-star-fox': [
    'Check this AI design against the NiCE AI design tenets.',
    'Does this Jira ticket hold up against our AI-first principles?',
    'Run North Star Fox on this screen and give me pass or fail per section.',
  ],
  'nice-product-knowledge': [
    'What does Enlighten AI actually do and who uses it?',
    'Give me background on CXone Mpower before I design for it.',
    'Which NICE product line does this feature belong to?',
  ],
  'team-strengths': [
    'What are the top strengths for the people on my team?',
    'Who should I staff on this project, and what will the group be missing?',
    'Help me prep a strengths-based 1:1 with someone.',
  ],
  'eac-framework-guide': [
    'Which EAC tenet does this situation fall under?',
    'What should I show my manager as evidence for this behavior?',
    'Help me prep for a calibration conversation using the framework.',
  ],
  'ux-research-planning': [
    'What research method answers this question?',
    'Write me a discussion guide for a usability study on this flow.',
    'Draft a screener and brief for recruiting admins.',
  ],
  'ux-research-synthesis': [
    'I have eight interview transcripts. What themes do you see?',
    'Turn these notes into personas.',
    'Build a journey map from these sessions and flag the thin signals.',
  ],
  'ux-research-readouts': [
    'Turn these findings into a readout for stakeholders.',
    'Write an executive summary of this study.',
    'Make this research into an HTML deliverable for the leadership team.',
  ],
  defuddle: [
    'Give me the article from this URL as clean markdown.',
    'Strip the ads and navigation from this page and summarize what is left.',
    'Pull the readable content out of this docs page.',
  ],
  'prompt-guru': [
    'Is this prompt going to get me what I want?',
    'Rewrite this vague prompt so it works better and explain what you changed.',
    'Improve my prompt and run the better version.',
  ],
  'emotional-intelligence': [
    'Does this feedback read as clear or defensive?',
    'Rewrite this message so it is direct without being harsh.',
    'Help me word a hard conversation with a teammate.',
  ],
  'ui-bug-hunter': [
    'What is wrong with this screenshot?',
    'Do a visual QA pass on this build and write Jira tickets for what you find.',
    'Review this screen recording for UI bugs.',
  ],
  'obsidian-power-user': [
    'Build me a project tracker in my Obsidian vault.',
    'Set up a weekly review template with Templater.',
    'Create a Dataview query that lists my open research tasks.',
  ],
  'obsidian-markdown': [
    'How do I write callouts and embeds in Obsidian?',
    'Format this note with wikilinks and properties.',
    'Convert this plain Markdown into Obsidian-flavored notes.',
  ],
  'obsidian-bases': [
    'Give me a table view of all my meeting notes.',
    'Create a base with filters for notes tagged research.',
    'Make a card view of my projects sorted by due date.',
  ],
  'obsidian-cli': [
    'Search my vault for notes that mention onboarding.',
    'Create a new note in my running Obsidian from this summary.',
    'Reload my plugin in Obsidian and screenshot the result.',
  ],
  'json-canvas': [
    'Lay out this process as an Obsidian canvas.',
    'Turn these ideas into a mind map I can open in Obsidian.',
    'Create a canvas with groups for each phase of the project.',
  ],
  'meeting-distiller': [
    'Turn these discovery meeting notes into a design brief.',
    'Here is a transcript. What is the problem we should design for?',
    'Distill this call into goals, constraints and open questions.',
  ],
  'fast-research-pack': [
    'What has already been tried for this problem?',
    'Build a research pack from this design brief.',
    'Show me analogous solutions and anti-patterns for this flow.',
  ],
  'proposal-generator': [
    'Give me three different directions for this brief.',
    'Generate conservative, progressive and disruptive proposals.',
    'Compare the options in a scoring matrix.',
  ],
  'wireframe-generator': [
    'Turn this proposal into a clickable prototype.',
    'Build a responsive HTML wireframe for the progressive option.',
    'Make an annotated wireframe I can share with the team.',
  ],
  'figma-push': [
    'Push this proposal into Figma as real frames.',
    'Create named, auto-laid-out frames from these screens.',
    'Get the wireframe into Figma with design tokens bound.',
  ],
  'design-ops': [
    'Set up a critique framework for my design team.',
    'Write a handoff process for design and engineering.',
    'Draft an onboarding plan for a new designer.',
  ],
  'design-research': [
    'Plan a usability test for this flow end to end.',
    'Write an interview guide for admins who manage routing.',
    'Analyze the results of this card sort.',
  ],
  'ux-strategy': [
    'Help me write design principles for this product area.',
    'Draft a UX vision that ties to the business goals.',
    'Frame this problem so it connects to what the company cares about.',
  ],
  'product-thinking-partner': [
    'Push back on this idea instead of agreeing with me.',
    'Which parts of my claim are evidence and which are hypothesis?',
    'Pressure-test this framing before I put it in a doc.',
  ],
  prism: [
    'I have messy notes. Help me turn them into a clear position.',
    'Draft a PRD from these inputs.',
    'Write a stakeholder update from my rough notes.',
  ],
  'figma-a11y-instructions': [
    'Write the accessibility spec for this Figma screen.',
    'Give me tab order, keyboard patterns and screen reader text for this design.',
    'Make a contrast table with WCAG-passing recommendations for this frame.',
  ],
  'hero-flows-research-os': [
    'Set up a lightweight research process for a team of one.',
    'Which effort mode should I use for this small study?',
    'Help me write a decision brief from this evidence.',
  ],
  'nice-present': [
    'Build me a deck for this project update.',
    'Create an exec update presentation from these notes.',
    'Make a roadmap slide deck for the team.',
  ],
  'pm-brain': [
    'Set up a second brain for this product.',
    'Interview me and build a folder structure for my product notes.',
    'Migrate my existing notes into a product brain.',
  ],
  'lyra-ui-prototyping': [
    'Build a clickable prototype of this screen from real Lyra components.',
    'Make an HTML demo of an admin settings page using Lyra.',
    'Prototype this flow in React with the Lyra component library.',
  ],
  'sol-ui-prototyping': [
    'Build a clickable prototype of this screen from real SOL components.',
    'Prototype this flow in React with SOL and tell me what SOL is missing.',
    'Make this demo 100 percent SOL and list the gaps.',
  ],
  'lynn-ui-prototyping': [
    'Build this project in Lynn using the real components.',
    'Make a dark, animated landing page with lynn-ui.',
    'Audit my live page against Lynn and fix what is off.',
  ],
  'design-system-agent': [
    'Keep fixing this page until it hits 95 percent Lyra compliance.',
    'Build this screen from real Lyra Storybook components and audit it live.',
    'Loop audit, fix and re-audit on my dev server until the score holds.',
  ],
  'persona-maya-chen': [
    'Interview Maya about this new onboarding flow.',
    'How would a brand-new agent react to this screen mid-call?',
    'Ask a first-week agent whether this is too much to figure out on the fly.',
  ],
  'persona-jordan-reyes': [
    'Ask a supervisor whether this dashboard change helps during a live shift.',
    'Interview Jordan about this real-time monitoring redesign.',
    'Would this slow down a supervisor triaging SLA breaches?',
  ],
  'persona-patricia-odom': [
    'What is the VP pitch for this feature?',
    'Interview an executive sponsor about whether this is worth funding.',
    'Would leadership actually approve this, or does it need a different pitch?',
  ],
  'persona-sam-whitfield': [
    'Ask a coach whether this scorecard change actually helps them coach.',
    'Interview Sam about this quality-monitoring feature.',
    'Would this give a coach something concrete to tell an agent?',
  ],
};

module.exports = { TOOL_EXAMPLES, SKILL_EXAMPLES };
