// ─── Tool + skill catalog ─────────────────────────────────────────────────────
// Single source of truth for how every MCP tool and Claude skill is *presented*
// — the human title, the group it belongs to, what it does in one line, and
// what the user actually gets out of it ("what's in it for me").
//
// Consumed in two places:
//   1. packages/mcp-server/src/index.js — merged into the MCP ListTools response
//      as `title`, `annotations`, and an appended "What you get / Ask first"
//      block on each description, so Claude picks the right tool and knows when
//      to stop and ask the user a question.
//   2. src/ui/mcp-catalog.ts — generated from this file by
//      `node scripts/gen-catalog.mjs`, and rendered on the plugin's Supercharge
//      page. Never edit the generated file by hand.
//
// Tool *ids* (the `name` field) are the wire contract — skills, docs and the
// MCP protocol all reference them, so they never change. The `title` is the
// rename lane: it is what humans read.
'use strict';

// Every tool ships from the NiCE Designer team unless an entry sets its own
// `author` — third-party skills (and, eventually, tools) added to the catalog
// should set `author` to the name/handle that should get visible credit on
// the Supercharge cards. Set `thirdParty: true` alongside `author` when the
// entry was built by someone outside the core NiCE Designer team — that pair
// is what puts a skill in the Supercharge "Marketplace" section and makes it
// match the marketplace-only filter. An `author` with no `thirdParty` flag is
// just an in-house credit (e.g. crediting the person whose framework a skill
// wraps) and stays in its normal topic group.
const DEFAULT_AUTHOR = 'NiCE Designer';

// Groups are ordered the way a user actually moves through the product:
// connect → run a skill → choose a scope → measure → fix → undo → restyle →
// hand off → decide.
const TOOL_GROUPS = [
  {
    id: 'connect',
    label: 'Connect & diagnose',
    blurb: 'Confirm Claude can actually see Figma and Chrome before anything else runs.',
  },
  {
    id: 'skills',
    label: 'Run a skill',
    blurb: 'Find a skill by name or topic, then load its full instructions — no separate install needed.',
  },
  {
    id: 'scope',
    label: 'Choose what to work on',
    blurb: 'Set the scope — a whole page, one artboard, or a single inspected element.',
  },
  {
    id: 'measure',
    label: 'Score & measure',
    blurb: 'Read your current state. The audits return a gauge plus the issue list behind it.',
  },
  {
    id: 'fix-bulk',
    label: 'Fix everything at once',
    blurb: 'Whole-page and whole-frame conversions. Dry-run by default, and they report the score they moved.',
  },
  {
    id: 'fix-one',
    label: 'Fix one thing at a time',
    blurb: 'Surgical, per-property edits with a clean one-click revert for each.',
  },
  {
    id: 'undo',
    label: 'Undo & history',
    blurb: 'Step back out of any bulk change without leaving the conversation.',
  },
  {
    id: 'restyle',
    label: 'Restyle the live page',
    blurb: 'Chrome only. Inject CSS, flip dark mode, and switch on accessibility overlays.',
  },
  {
    id: 'handoff',
    label: 'Spec Mode',
    blurb: 'Turn a design into CSS, tokens, and specs a developer can paste in.',
  },
  {
    id: 'decide',
    label: 'Decide & review',
    blurb: 'Judgement calls — is this good enough to move to the next step?',
  },
  {
    id: 'maintain',
    label: 'Keep the server current',
    blurb: 'Check whether a newer MCP server build is available, and pull it in.',
  },
  {
    id: 'escape',
    label: 'Escape hatch',
    blurb: 'Raw access for anything the tools above do not cover yet.',
  },
];

// kind: 'read' (no mutation) | 'write' (mutates the design) | 'toggle'
//       (reversible view-only state) | 'bridge' (infrastructure)
// clients: 'both' | 'figma' | 'chrome'
// scored: returns an inline gauge / numeric score
// ask: the clarifying question Claude should put to the user *before* running.
const TOOLS = [
  // ─── Connect & diagnose ─────────────────────────────────────────────────────
  {
    name: 'list_targets',
    title: 'See what is connected',
    group: 'connect',
    kind: 'bridge',
    clients: 'both',
    what: 'Lists which clients — Figma, Chrome, or both — are live on the MCP hub right now.',
    benefit: 'Stops you from waiting on a tool that was never going to reach anything. Always the cheapest first call.',
  },
  {
    name: 'get_diagnostics',
    title: 'Troubleshoot the connection',
    group: 'connect',
    kind: 'bridge',
    clients: 'both',
    what: 'Full health report on the bridge: this process, the hub, connected sessions, recent drop-outs, and a plain-English next step.',
    benefit: 'Turns "it just does not work" into a specific thing to click. Run it the moment a tool says nothing is connected.',
  },
  {
    name: 'check_libraries',
    title: 'Check the design library is linked',
    group: 'connect',
    kind: 'read',
    clients: 'figma',
    what: 'Verifies the SOL or Lyra library is actually linked to the open Figma file.',
    benefit: 'A missing library silently makes every conversion fall back to bundled values. This catches that before you convert anything.',
  },

  // ─── Run a skill ────────────────────────────────────────────────────────────
  {
    name: 'analytics_summary',
    title: 'Show my usage',
    group: 'connect',
    kind: 'read',
    clients: 'both',
    what: 'Reads this install\'s local analytics store and reports total events, panel minutes, top tools, top skills, and whether uploading is configured.',
    benefit: 'Answers "what am I actually using?" from your own machine, and tells you at a glance whether analytics is recording and reaching the dashboard.',
  },
  {
    name: 'list_skills',
    title: 'Browse available skills',
    group: 'skills',
    kind: 'read',
    clients: 'both',
    what: 'Returns every skill in the catalog — id, title, the question it answers, what it does, and who built it. Checks a small hosted catalog first, bundled list as fallback.',
    benefit: 'Say "run North Star Fox" or "what skills do you have" and Claude finds the right one by name or topic — no id-guessing, and a skill added after you installed still shows up.',
  },
  {
    name: 'get_skill',
    title: "Load a skill's instructions",
    group: 'skills',
    kind: 'read',
    clients: 'both',
    what: "Fetches the full SKILL.md body for a skill id from list_skills, plus any reference file inside that skill's own folder. Live copy first, this server's bundled copy as an offline fallback.",
    benefit: 'Flip the Supercharge toggle and every skill works immediately — nothing else to install, and skill fixes/updates land without waiting on a connector reinstall.',
  },

  // ─── Choose what to work on ─────────────────────────────────────────────────
  {
    name: 'get_selection_info',
    title: 'What is selected right now',
    group: 'scope',
    kind: 'read',
    clients: 'both',
    what: 'Reports the selected Figma layer or the inspected Chrome element, so scope is explicit rather than assumed.',
    benefit: 'Guarantees the audit or fix lands on the thing you meant. No silent whole-page conversions when you wanted one button.',
  },
  {
    name: 'select_page',
    title: 'Reset scope to the whole page',
    group: 'scope',
    kind: 'toggle',
    clients: 'chrome',
    what: 'Clears the inspected element so audits and fixes cover the entire page again.',
    benefit: 'One call to zoom back out after drilling into a component.',
  },
  {
    name: 'start_inspect',
    title: 'Start element picking',
    group: 'scope',
    kind: 'toggle',
    clients: 'chrome',
    what: 'Turns on the extension\'s inspect mode so the next element you click becomes the scope.',
    benefit: 'Point at the thing you care about instead of describing it in words.',
  },
  {
    name: 'stop_inspect',
    title: 'Stop element picking',
    group: 'scope',
    kind: 'toggle',
    clients: 'chrome',
    what: 'Leaves inspect mode without changing the current selection.',
    benefit: 'Gets the picking cursor out of your way so you can use the page normally.',
  },
  {
    name: 'focus_node',
    title: 'Jump to a layer in Figma',
    group: 'scope',
    kind: 'toggle',
    clients: 'figma',
    what: 'Scrolls to and selects a specific node id on the Figma canvas.',
    benefit: 'Every audit row becomes clickable — go straight from "issue #14" to the actual layer.',
  },
  {
    name: 'screenshot_page',
    title: 'Screenshot what you are looking at',
    group: 'scope',
    kind: 'read',
    clients: 'both',
    what: 'Captures the current page or artboard as an image Claude can look at directly.',
    benefit: 'Lets Claude judge things a token audit cannot see — visual hierarchy, crowding, whether it simply looks wrong.',
  },

  // ─── Score & measure ────────────────────────────────────────────────────────
  {
    name: 'run_full_audit',
    title: 'Full compliance score',
    group: 'measure',
    kind: 'read',
    clients: 'both',
    scored: true,
    what: 'Audits colors, typography, spacing, radius, components and accessibility in one pass and returns an overall 0–100 score with per-domain issue counts.',
    benefit: 'One number you can put in front of a stakeholder, plus the exact list of what is dragging it down.',
    ask: 'Audit only the current selection, or the whole page/artboard? And which system — Lyra (default) or SOL?',
  },
  {
    name: 'lyra_compliance_report',
    title: 'Lyra readiness report',
    group: 'measure',
    kind: 'read',
    clients: 'both',
    scored: true,
    what: 'A full audit plus the accessibility pass, pinned to Lyra, formatted as a report rather than a raw issue dump.',
    benefit: 'The artifact to paste into a design review or a ticket — score, gauge, and the top offenders, already prose.',
  },
  {
    name: 'audit_colors',
    title: 'Score the colors',
    group: 'measure',
    kind: 'read',
    clients: 'both',
    scored: true,
    what: 'Classifies every fill and stroke as on-token, bound to the wrong design system, or a raw value with no binding.',
    benefit: 'Tells you not just how many colors are off but how many are one click from being right — so you know whether this is ten minutes of work or a week.',
  },
  {
    name: 'audit_text_styles',
    title: 'Score the typography',
    group: 'measure',
    kind: 'read',
    clients: 'both',
    scored: true,
    what: 'Matches every text node on family, size and weight together, and names the role-equivalent token it should be using.',
    benefit: 'Catches the sneaky case — right size, wrong family — that eyeballing a design never finds.',
  },
  {
    name: 'audit_spacing',
    title: 'Score the spacing',
    group: 'measure',
    kind: 'read',
    clients: 'both',
    scored: true,
    what: 'Finds padding, gap and margin values that are off-scale, or on-scale but not bound to a variable.',
    benefit: 'Surfaces the "looks fine, breaks on theme change" class of problem, which is most of what fails in handoff.',
  },
  {
    name: 'audit_radius',
    title: 'Score the corner radii',
    group: 'measure',
    kind: 'read',
    clients: 'both',
    scored: true,
    what: 'Finds corner radii that are off-scale or unbound, reading the real per-corner binding slots.',
    benefit: 'Radius drift is the fastest way a page stops looking like the system. This is the cheapest audit to act on.',
  },
  {
    name: 'audit_components',
    title: 'Score the components',
    group: 'measure',
    kind: 'read',
    clients: 'figma',
    scored: true,
    what: 'Finds instances from the wrong library or from no library, and names a 1:1 replacement where one exists.',
    benefit: 'Detached and off-system components are what make a file un-maintainable. This is the list to fix first.',
  },
  {
    name: 'audit_accessibility',
    title: 'Score accessibility',
    group: 'measure',
    kind: 'read',
    clients: 'both',
    scored: true,
    what: 'WCAG-oriented scan: contrast, tap targets, small text, ARIA, alt text, labels, focus outlines, heading order, landmarks.',
    benefit: 'Errors and warnings split out separately, so you can see what is a genuine blocker versus what is polish.',
    ask: 'Want the fixable issues applied afterwards, or just the report?',
  },
  {
    name: 'scan_variables',
    title: 'List the variables in use',
    group: 'measure',
    kind: 'read',
    clients: 'both',
    what: 'Enumerates every variable currently bound in the scope, and every property that should be bound but is not.',
    benefit: 'The raw data behind the spacing and radius scores, if you want to reason about bindings yourself.',
  },
  {
    name: 'get_audit_filters',
    title: 'See what the score ignores',
    group: 'measure',
    kind: 'read',
    clients: 'both',
    what: 'Returns the user\'s active audit filters — which issue classes are currently excluded from the score.',
    benefit: 'Keeps the score honest. A 96 with contrast checks switched off is not a 96, and this is how you find out.',
  },
  {
    name: 'set_audit_filters',
    title: 'Change what the score ignores',
    group: 'measure',
    kind: 'toggle',
    clients: 'both',
    what: 'Turns individual issue classes in or out of scope for the score.',
    benefit: 'Lets you park issues that are genuinely out of scope for this project without them nagging in every audit.',
    ask: 'Which checks should be excluded, and should that stick for later audits too?',
  },

  // ─── Fix everything at once ─────────────────────────────────────────────────
  {
    name: 'convert_page_to_lyra',
    title: 'Convert the whole page to Lyra',
    group: 'fix-bulk',
    kind: 'write',
    clients: 'chrome',
    scored: true,
    reversible: true,
    what: 'Runs every applicable fixer across a live page and returns a before/after score delta.',
    benefit: 'The single biggest jump in score you can get in one call — and you see exactly how many points it bought.',
    ask: 'Tokens-only (precise, keeps the layout — best for demos and finished work) or a full conversion (also normalises layout, components and a11y — best for early mockups)?',
  },
  {
    name: 'migrate_to_lyra',
    title: 'Convert the whole frame to Lyra',
    group: 'fix-bulk',
    kind: 'write',
    clients: 'figma',
    scored: true,
    reversible: true,
    what: 'The Figma equivalent: applies the selected fixer families across a frame and reports the score delta.',
    benefit: 'Migrates a whole artboard without hand-picking rows, with a before/after gauge to show your team.',
    ask: 'Which families should run — colors, typography, spacing, radius, accessibility? And tokens-only or a full conversion?',
  },
  {
    name: 'convert_colors',
    title: 'Apply color tokens',
    group: 'fix-bulk',
    kind: 'write',
    clients: 'both',
    scored: true,
    reversible: true,
    what: 'Binds the chosen color tokens to the listed fills and strokes.',
    benefit: 'Reports how many of the original color issues it actually resolved, so a partial fix never gets reported as a win.',
    ask: 'Apply every suggested color, or only the exact matches and leave the judgement calls to you?',
  },
  {
    name: 'convert_text_styles',
    title: 'Apply typography tokens',
    group: 'fix-bulk',
    kind: 'write',
    clients: 'both',
    scored: true,
    reversible: true,
    what: 'Applies the matching type token to the given text nodes, or to every eligible one.',
    benefit: 'Type is the most visible domain — this is the change people notice, and it comes with a resolved-count.',
    ask: 'All text nodes, or should any be skipped (logos and custom display type usually should)?',
  },
  {
    name: 'fix_spacing',
    title: 'Bind spacing tokens',
    group: 'fix-bulk',
    kind: 'write',
    clients: 'both',
    scored: true,
    reversible: true,
    what: 'Binds spacing variables to off-scale or unbound padding, gap and margin values.',
    benefit: 'Usually the highest-yield, lowest-risk fix in the set — values barely move, but the score does.',
  },
  {
    name: 'fix_radius',
    title: 'Bind radius tokens',
    group: 'fix-bulk',
    kind: 'write',
    clients: 'both',
    scored: true,
    reversible: true,
    what: 'Binds radius variables to off-scale or unbound corner radii.',
    benefit: 'Small visual change, large consistency gain, and it takes one call.',
  },
  {
    name: 'fix_accessibility',
    title: 'Apply accessibility fixes',
    group: 'fix-bulk',
    kind: 'write',
    clients: 'both',
    scored: true,
    reversible: true,
    what: 'Applies the automated remediation for a specific accessibility issue type on a node.',
    benefit: 'Clears the mechanical a11y failures — labels, alt text, tap targets — so human attention goes to the judgement calls.',
    ask: 'Auto-fixable issues only, or should we also attempt the ones that need judgement (contrast trade-offs, copy rewrites)?',
  },
  {
    name: 'convert_component',
    title: 'Swap a component for its system twin',
    group: 'fix-bulk',
    kind: 'write',
    clients: 'figma',
    reversible: true,
    what: 'Replaces one instance with the equivalent component from the target design system.',
    benefit: 'Gets you a real library instance — inheriting future updates — instead of a look-alike that drifts.',
    ask: 'Confirm the replacement component name before swapping — a wrong swap loses instance overrides.',
  },
  {
    name: 'convert_mode',
    title: 'Switch light / dark mode',
    group: 'fix-bulk',
    kind: 'write',
    clients: 'both',
    reversible: true,
    what: 'Re-binds the scope to the light or dark tokens of the given system.',
    benefit: 'Produces a genuine dark variant built from tokens, not an inverted screenshot.',
  },
  {
    name: 'generate_multi_system',
    title: 'Duplicate into the other system',
    group: 'fix-bulk',
    kind: 'write',
    clients: 'figma',
    what: 'Copies the selection and converts the copy to the other design system, leaving the original untouched.',
    benefit: 'Side-by-side SOL and Lyra versions for a migration pitch, with zero risk to the original.',
  },

  // ─── Fix one thing at a time ────────────────────────────────────────────────
  {
    name: 'apply_single_color',
    title: 'Set one color',
    group: 'fix-one',
    kind: 'write',
    clients: 'both',
    reversible: true,
    what: 'Applies one color token — or a raw hex via customHex — to a single fill or stroke.',
    benefit: 'Try a value in one call and undo it in one call. This is the lane for "just make this blue".',
  },
  {
    name: 'apply_single_text',
    title: 'Set one text style',
    group: 'fix-one',
    kind: 'write',
    clients: 'both',
    reversible: true,
    what: 'Applies one type token — or a raw size via customFontSize — to a single text node.',
    benefit: 'Iterate on one heading without touching the other forty.',
  },
  {
    name: 'apply_single_spacing',
    title: 'Set one spacing value',
    group: 'fix-one',
    kind: 'write',
    clients: 'both',
    reversible: true,
    what: 'Applies one spacing token — or a raw number via customValue — to a single property.',
    benefit: 'Nudge one gap by hand when the token scale genuinely does not have the right step.',
  },
  {
    name: 'apply_single_radius',
    title: 'Set one corner radius',
    group: 'fix-one',
    kind: 'write',
    clients: 'both',
    reversible: true,
    what: 'Applies one radius token — or a raw number via customValue — to a single corner or all four.',
    benefit: 'Fix the one card whose corners are wrong, without a page-wide pass.',
  },
  {
    name: 'revert_single_color',
    title: 'Undo that one color',
    group: 'fix-one',
    kind: 'write',
    clients: 'both',
    what: 'Restores the snapshot captured when that exact fill or stroke was changed.',
    benefit: 'Per-row undo that survives other edits — no losing four good changes to walk back a fifth.',
  },
  {
    name: 'revert_single_text',
    title: 'Undo that one text style',
    group: 'fix-one',
    kind: 'write',
    clients: 'both',
    what: 'Restores the snapshot captured when that text node was changed.',
    benefit: 'Try a type token, dislike it, put it back exactly as it was.',
  },
  {
    name: 'revert_single_spacing',
    title: 'Undo that one spacing value',
    group: 'fix-one',
    kind: 'write',
    clients: 'both',
    what: 'Restores the snapshot captured when that spacing property was changed.',
    benefit: 'Reverses a single nudge without disturbing the rest of the layout.',
  },
  {
    name: 'revert_single_radius',
    title: 'Undo that one corner radius',
    group: 'fix-one',
    kind: 'write',
    clients: 'both',
    what: 'Restores the snapshot captured when that radius was changed.',
    benefit: 'Reverses a single radius edit cleanly.',
  },

  // ─── Undo & history ─────────────────────────────────────────────────────────
  {
    name: 'undo_last_conversion',
    title: 'Undo the last bulk change',
    group: 'undo',
    kind: 'write',
    clients: 'both',
    what: 'Rolls back the most recent bulk conversion in one call.',
    benefit: 'Lets you run a big conversion to see what it does, knowing the exit is one sentence away.',
  },
  {
    name: 'get_conversion_history',
    title: 'List every change made',
    group: 'undo',
    kind: 'read',
    clients: 'both',
    what: 'Returns the ordered history of applied changes with the current position in it.',
    benefit: 'A written record of what this session actually touched — useful for a changelog or a handoff note.',
  },
  {
    name: 'revert_to_history_index',
    title: 'Rewind to an earlier point',
    group: 'undo',
    kind: 'write',
    clients: 'both',
    what: 'Steps the design back to a chosen entry in the history.',
    benefit: 'Explore aggressively, then land on whichever version was best — not just the last one.',
    ask: 'Which history entry should we land on? Everything after it will be undone.',
  },

  // ─── Restyle the live page ──────────────────────────────────────────────────
  {
    name: 'apply_css_overrides',
    title: 'Inject CSS rules',
    group: 'restyle',
    kind: 'write',
    clients: 'chrome',
    reversible: true,
    what: 'Injects selector-scoped CSS declarations into the live page.',
    benefit: 'Restyle anything on a page you do not own, and see the result immediately. Pass clear:true so re-runs replace rather than stack.',
    ask: 'Show the selector-to-declaration table and get a yes before injecting — a wrong selector can restyle the whole page.',
  },
  {
    name: 'clear_css_overrides',
    title: 'Remove injected CSS',
    group: 'restyle',
    kind: 'write',
    clients: 'chrome',
    what: 'Strips every override this session injected, returning the page to its shipped styling.',
    benefit: 'A clean baseline in one call, so an experiment never contaminates the next audit.',
  },
  {
    name: 'polish_page',
    title: 'Page view toggles',
    group: 'restyle',
    kind: 'toggle',
    clients: 'chrome',
    what: 'Toggles dark-mode simulation, token-styled scrollbars, and positional hover overlays.',
    benefit: 'Dark mode without a build, on any page — the fastest way to find out what breaks.',
  },
  {
    name: 'a11y_overlay',
    title: 'Accessibility overlays',
    group: 'restyle',
    kind: 'toggle',
    clients: 'chrome',
    what: 'Toggles small-tap-target highlighting, non-token color flagging, and colorblind simulation.',
    benefit: 'Makes accessibility problems visible on screen, which is far more persuasive in a review than a list of counts.',
  },

  // ─── Spec Mode ──────────────────────────────────────────────────────────────
  {
    name: 'extract_dev_details',
    title: 'Spec sheet for one element',
    group: 'handoff',
    kind: 'read',
    clients: 'both',
    what: 'Size, fills, strokes, typography, auto-layout and CSS for the current selection.',
    benefit: 'The handoff spec a developer asks for, without a screenshot-and-annotate round trip.',
  },
  {
    name: 'extract_all_css',
    title: 'Export the whole thing as CSS',
    group: 'handoff',
    kind: 'read',
    clients: 'both',
    what: 'Emits a CSS document covering every node in scope.',
    benefit: 'A real starting point for implementation rather than a pile of values to retype.',
  },
  {
    name: 'extract_token_css',
    title: 'Export CSS custom properties',
    group: 'handoff',
    kind: 'read',
    clients: 'both',
    what: 'Emits the design system\'s tokens as CSS custom properties.',
    benefit: 'Drop it into a stylesheet and the rest of the exported CSS resolves against real tokens.',
  },
  {
    name: 'export_design_tokens',
    title: 'Export the token palettes',
    group: 'handoff',
    kind: 'read',
    clients: 'both',
    what: 'Returns the color, type, spacing and radius palettes for SOL or Lyra in either mode.',
    benefit: 'Lets Claude propose real token names instead of guessing at them from memory.',
  },
  {
    name: 'sync_storybook_components',
    title: 'Sync components from Storybook',
    group: 'handoff',
    kind: 'write',
    clients: 'both',
    what: 'Pulls the live component inventory from a Storybook instance into the plugin.',
    benefit: 'Component audits start matching what engineering actually shipped, not last quarter\'s library.',
    ask: 'Which Storybook URL, and should this replace the current inventory or merge into it?',
  },
  {
    name: 'get_storybook_sync_status',
    title: 'Storybook sync status',
    group: 'handoff',
    kind: 'read',
    clients: 'both',
    what: 'Reports when the last sync ran and how many components it brought in.',
    benefit: 'Tells you whether a component audit is trustworthy or built on stale data.',
  },

  // ─── Decide & review ────────────────────────────────────────────────────────
  {
    name: 'run_ux_eval',
    title: 'Ten-question UX eval',
    group: 'decide',
    kind: 'read',
    clients: 'both',
    scored: true,
    what: 'Assembles a live audit, the design and ticket links, and the 10-question prioritisation framework — then hands the judgement to Claude.',
    benefit: 'The answer to "is this ready for dev?" argued on reach, real pain and opportunity cost — not just on whether the tokens are clean.',
    ask: 'Design or page link, an optional Jira link, and any context you have — whatever you have is enough to start.',
  },

  // ─── Keep the server current ────────────────────────────────────────────────
  {
    name: 'check_for_updates',
    title: 'Check for a newer server build',
    group: 'maintain',
    kind: 'read',
    clients: 'both',
    what: 'Fetches origin and reports whether the local MCP server checkout is behind, with the commit list and version numbers.',
    benefit: 'Know there is an update before running it, instead of finding out a feature is missing after the fact.',
  },
  {
    name: 'install_update',
    title: 'Pull and install the latest build',
    group: 'maintain',
    kind: 'write',
    clients: 'both',
    reversible: false,
    what: 'Fast-forwards the local checkout to origin and runs npm install for whatever changed. Only works from a git checkout, and only when the working tree is clean.',
    benefit: 'Gets new tools and fixes onto disk in one call — though the running process still needs a restart to actually load them, which the response always states.',
    ask: 'Show the pending commits (from check_for_updates or a dry run) and confirm before running with dryRun:false.',
  },

  // ─── Escape hatch ───────────────────────────────────────────────────────────
  {
    name: 'call_plugin',
    title: 'Send a raw plugin message',
    group: 'escape',
    kind: 'write',
    clients: 'both',
    what: 'Forwards any raw UIMessage straight to the plugin, bypassing the typed tools.',
    benefit: 'Reaches plugin capability that has no tool yet. Powerful, unvalidated — use it when nothing else fits.',
    ask: 'Confirm the exact message payload first; this path has no dry-run and no schema validation.',
  },
];

// ─── Claude skills ────────────────────────────────────────────────────────────
// `id` matches the directory under skills/. `question` is the user's own words —
// the thing they are actually trying to find out.
const SKILL_GROUPS = [
  { id: 'measure', label: 'Score & triage', blurb: 'Turn a pile of issues into a ranked list of what to do first.' },
  { id: 'convert', label: 'Convert to Lyra', blurb: 'Set expectations and scope before anything gets rewritten.' },
  { id: 'handoff', label: 'Spec Mode', blurb: 'Produce the spec or the CSS a developer can build from.' },
  { id: 'parity', label: 'Design ↔ build parity', blurb: 'Compare what was designed against what actually shipped.' },
  { id: 'qa', label: 'Live-page QA', blurb: 'Catch what only breaks in the real browser.' },
  { id: 'system', label: 'Design-system maintenance', blurb: 'Feed what you learn back into the system itself.' },
  { id: 'decide', label: 'Decide & review', blurb: 'Pass, fail, or not-yet — with the reasoning written down.' },
  { id: 'knowledge', label: 'Context & knowledge', blurb: 'Real context on NICE, its products, and the team, so design and staffing decisions are grounded instead of generic.' },
];

const SKILLS = [
  {
    id: 'a11y-triage',
    title: 'Accessibility triage',
    group: 'measure',
    clients: 'both',
    question: 'I have hundreds of a11y issues — where do I actually start?',
    what: 'Ranks accessibility issues by severity × reach and returns a top-N action list.',
    benefit: 'Converts an unreadable issue dump into three things to fix this afternoon.',
    tools: ['audit_accessibility'],
  },
  {
    id: 'manual-fixes-checklist',
    title: 'Manual-fixes checklist',
    group: 'measure',
    clients: 'both',
    question: 'What is left for a human after the auto-fixers have run?',
    what: 'Audits, dry-runs every fixer, then reports only what survives — grouped and prioritised.',
    benefit: 'An honest to-do list for the last mile to 100%, so nobody promises a score the tools cannot reach.',
    tools: ['run_full_audit', 'convert_page_to_lyra', 'migrate_to_lyra'],
  },
  {
    id: 'lyra-visual-patterns',
    title: 'Lyra visual patterns',
    group: 'convert',
    clients: 'both',
    question: 'What is a correctly-converted Lyra page supposed to look like?',
    what: 'Reference for Lyra page chrome, surfaces, tables, panels, nav, chips and AI affordances in light and dark.',
    benefit: 'Load it before any conversion and you know what you are going to get — no surprise redesigns.',
    tools: ['convert_page_to_lyra', 'migrate_to_lyra', 'convert_mode'],
  },
  {
    id: 'figma-element-css',
    title: 'Figma element → CSS',
    group: 'handoff',
    clients: 'figma',
    question: 'What is the CSS for this layer?',
    what: 'Turns the selected Figma node into production CSS with Lyra tokens substituted where they match.',
    benefit: 'Output that survives a theme change, instead of hard-coded hex and px.',
    tools: ['get_selection_info', 'extract_dev_details', 'extract_token_css'],
  },
  {
    id: 'browser-element-specs',
    title: 'Browser element → spec sheet',
    group: 'handoff',
    clients: 'chrome',
    question: 'What are the design specs of this element on the page?',
    what: 'Pulls computed CSS for the inspected element and annotates every raw value with its nearest token.',
    benefit: 'A spec a developer can act on, not just a description of what is there.',
    tools: ['get_selection_info', 'extract_dev_details', 'audit_colors'],
  },
  {
    id: 'figma-chrome-parity',
    title: 'Figma ↔ Chrome parity',
    group: 'parity',
    clients: 'both-required',
    question: 'Does the live site actually match the Figma?',
    what: 'Aligns Figma layers to page elements by name and diffs colors, type, spacing, radius and shadows.',
    benefit: 'Ends the "it looks off but I cannot say why" review with a per-property drift table.',
    tools: ['extract_dev_details', 'get_selection_info'],
  },
  {
    id: 'artboard-to-page',
    title: 'Artboard → live page',
    group: 'parity',
    clients: 'both-required',
    question: 'Can we make this real page look like this artboard?',
    what: 'Maps artboard styling onto page selectors and applies it as CSS overrides after you confirm the mapping.',
    benefit: 'Demo a redesign on the real product in minutes, with no branch and no build.',
    tools: ['extract_dev_details', 'apply_css_overrides', 'clear_css_overrides'],
  },
  {
    id: 'dark-mode-parity',
    title: 'Dark-mode parity',
    group: 'qa',
    clients: 'chrome',
    question: 'Does this page work in dark mode, or only in light?',
    what: 'Audits colors in light, simulates dark, audits again, and always restores the baseline.',
    benefit: 'Only the delta — what breaks in dark and what breaks in light. No re-reading the full audit.',
    tools: ['audit_colors', 'polish_page'],
  },
  {
    id: 'token-candidates',
    title: 'Token candidates',
    group: 'system',
    clients: 'both',
    question: 'Which of these custom values should just become Lyra tokens?',
    what: 'Groups recurring raw values across all four domains and ranks the ones worth promoting.',
    benefit: 'Fixes the cause once upstream instead of the same symptom on thirty screens.',
    tools: ['audit_colors', 'audit_text_styles', 'audit_spacing', 'audit_radius'],
  },
  {
    id: 'ux-eval',
    title: 'Ten-question UX eval',
    group: 'decide',
    clients: 'both',
    question: 'Is this good enough to move to the next step, or to dev?',
    what: 'Answers all ten prioritisation questions against real evidence, then states pass / pass-with-conditions / not-yet. For AI-surface designs, also layers in the North Star Fox tenet check.',
    benefit: 'A defensible verdict with the reasoning attached — the thing you can actually take to a VP.',
    tools: ['run_ux_eval', 'run_full_audit'],
    author: 'Bill Bangs',
    thirdParty: true,
  },
  {
    id: 'north-star-fox',
    title: 'North Star Fox',
    group: 'decide',
    clients: 'both',
    question: 'Does this design or JIRA ticket actually hold up against our AI-first tenets?',
    what: "Scores a CXone AI design, screen, or JIRA ticket against the twelve NiCE AI design tenets, plus Lyra Foundations and NiCE Brand adherence, and returns a fixed-shape pass/fail verdict per section.",
    benefit: 'A critical look at designs and JIRA tickets to ensure alignment with our Core Values around AI architecture at NiCE.',
    tools: [],
    author: 'Janet Gonzales',
    thirdParty: true,
  },
  {
    id: 'nice-product-knowledge',
    title: 'NiCE product knowledge',
    group: 'knowledge',
    clients: 'both',
    question: 'What does this NICE product actually do, and who uses it?',
    what: 'Sourced reference on NICE the company and its product lines (CXone Mpower, Enlighten AI, Actimize, Evidencentral) — compiled from public material with citations.',
    benefit: 'Design decisions grounded in what the real product and its real users are, instead of generic SaaS assumptions.',
    tools: [],
  },
  {
    id: 'team-strengths',
    title: 'Team strengths',
    group: 'knowledge',
    clients: 'both',
    question: 'Who should I put on this, and what will this group get wrong?',
    what: "The design team's CliftonStrengths grid (45 people, top 10 themes each) plus the analysis: lookup, group composition, find-the-person matching, and 1:1 coaching prep.",
    benefit: 'Staffing and 1:1 decisions grounded in how people actually work, instead of who was free.',
    tools: [],
  },
  {
    id: 'eac-framework-guide',
    title: 'EAC Framework Guide',
    group: 'knowledge',
    clients: 'both',
    question: 'Which tenet does this fall under, and what do I actually show my manager?',
    what: "The eight Personal behaviors cards from the Engagement Orchestration PM framework: purpose, capabilities, and the verbatim 'show your manager' column, plus routing, calibration prep, self-assessment and manager-side calibration.",
    benefit: 'Turns a framework you skim once into the specific instance you bring to your next 1:1.',
    tools: [],
    author: 'EAC Team',
    thirdParty: true,
  },
];

// ─── Derived lookups + integrity check ────────────────────────────────────────
const TOOLS_BY_NAME = Object.create(null);
for (const t of TOOLS) TOOLS_BY_NAME[t.name] = t;

const GROUP_LABELS = Object.create(null);
for (const g of TOOL_GROUPS) GROUP_LABELS[g.id] = g.label;

// Every tool must land in a declared group, and no name may repeat. Surfaced as
// a thrown error rather than a silent miss, because a tool with no catalog entry
// loses its title, its annotations and its Supercharge row all at once.
function validate() {
  const problems = [];
  const seen = new Set();
  for (const t of TOOLS) {
    if (seen.has(t.name)) problems.push(`duplicate tool entry: ${t.name}`);
    seen.add(t.name);
    if (!GROUP_LABELS[t.group]) problems.push(`${t.name}: unknown group "${t.group}"`);
    if (!t.title || !t.what || !t.benefit) problems.push(`${t.name}: missing title/what/benefit`);
  }
  const skillGroups = new Set(SKILL_GROUPS.map(g => g.id));
  for (const s of SKILLS) {
    if (!skillGroups.has(s.group)) problems.push(`skill ${s.id}: unknown group "${s.group}"`);
  }
  return problems;
}

module.exports = { TOOL_GROUPS, TOOLS, SKILL_GROUPS, SKILLS, TOOLS_BY_NAME, DEFAULT_AUTHOR, validate };
