# SOL: known gaps (curated)

What a CXone screen routinely needs that is **not among the 43 SOL components** in the bundled Storybook seed. Use it to declare gaps up front in `GAPS.md`.

How to read it: "not in the seed" is provable, "SOL has no such thing" is not. The seed covers the component pages only, not the whole Storybook (foundations, patterns, shell). Before writing a gap row, spend one search in the live Storybook (`na1.dev.nice-incontact.com/sol`). If it exists there, use it and fix this list.

Basis: the seed's component list compared with the component inventory of `@nicecxone/lyra-ui` (commit 2b0e88a, the library that does ship these), which shows what real screens end up needing.

## Not in the seed, needed by real screens

| Need | In SOL's 43? | Closest SOL pieces | Handling |
|---|---|---|---|
| Avatar (initials, image, status) | No | Icon | Gap. Do not draw a circle with initials. |
| Badge / count bubble | No | Chip | Gap for count and notification badges. Chip is a chip, not a badge. |
| Tag / status pill | No | Chip, Chip Group | Use Chip only when the meaning is a chip (filter, selection). A read-only status pill is a gap. |
| Link (styled text link) | No | Button `variant="tertiary"` | Use tertiary Button for actions. A navigation link inside prose is a gap. |
| Divider / separator | No | none | Gap. Prefer spacing and `Card`/`Panel` grouping. |
| Empty state | No | none | Gap. |
| Page header / title bar | No | Breadcrumb | Gap for the header block; Breadcrumb covers the trail only. |
| App header, left nav, nav rail (shell) | No | none | Gap unless the live Storybook has a shell pattern. |
| Data table with column menus, sorting, toolbar | Partly | Grid (ag-Grid based) | Use Grid. Features beyond its documented props are gaps. |
| Tree menu / tree view | No | Menu | Gap. |
| Transfer box (dual list) | No | none | Gap. |
| Charts (bar, line, donut, gauge, heatmap, funnel, sparkline) | No | none | Gap. Never hand-draw a chart in SVG as if it were SOL. |
| Phone, email, password, tags input | No | Text Input | Use Text Input with its real props. Masking, country picker and tag entry are gaps. |
| Date and time together; time range | No | Date Picker, Time Picker | Compose the two real pickers, and note the composition. |
| Single-value slider | No | Range Slider | Range Slider with one thumb is not documented. Gap unless the props allow it. |
| Skeleton / loading placeholder | No | Spinner | Spinner only. |

## In SOL, but Angular only (React build)

See `not-available.md` (generated): 19 components have no React API. In a React-first build these are gaps unless the user agrees to a mixed build.

## What the seed cannot tell you

- Do/don't guidance, variant descriptions and use cases: none are in the seed. Read the component's docs page.
- Which props are required, and which are silent no-ops without a partner prop.
- React package name and registry (not recorded in this repo).
