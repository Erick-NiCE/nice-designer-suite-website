// ─── ADQR design review: the rule layer ──────────────────────────────────────
// Port of the deterministic half of ADQR (AI Design Quality Review, by Prafull
// Mane): given per-dimension bands that Claude has already judged against the
// rubric, apply ADQR's fixed rules and return the four pillar scores, the
// confidence level and the ship verdict.
//
// Why this is code and not skill text: ADQR's spec is explicit that caps,
// exclusions, confidence and the verdict are "plain rule-based code, never
// left to the model". Claude judges each band; everything after that is
// arithmetic, so the same bands always produce the same verdict.
//
// The rubric itself (questions, anchors, evaluate-for / do-not-evaluate) is
// design-review-rubric.json, copied verbatim from ADQR's rubric.js. The
// adqr-design-review skill's references are generated from that same file
// (npm run gen:adqr-refs), so the skill and this scorer can never disagree on
// which dimensions exist. Not ported: ADQR's form_quality dimension, which is
// scored from Playwright DOM signals this connector does not collect (ADQR
// itself omits it for anything that is not a live page).
//
// Deliberate differences from ADQR's demo build, each one toward its spec:
//   - All four pillars are active. The demo paused Business Alignment and AI
//     Experience (ACTIVE_PILLARS); this connector scores and gates on all four.
//   - A requirement element marked "conflict" forces Low confidence, per the
//     confidence table in ADQR's scoring.md. The demo never wired that row up.
//   - Every applicable dimension must be scored. The demo silently treated a
//     missing AI Experience band as 0, which the spec forbids ("absence of
//     evidence is never a default score").
'use strict';

const RUBRIC = require('./design-review-rubric.json');

const BANDS = [0, 2, 4, 6, 8, 10];
const MODALITIES = ['static', 'semi_interactive', 'fully_interactive'];
const EVIDENCE_TAGS = ['observed', 'inferred', 'assumed'];
const ELEMENT_STATUSES = ['covered', 'partial', 'missing', 'conflict', 'not_verifiable'];
const CONTEXT_FIELDS = ['requirement', 'businessGoal', 'userGoal', 'businessOutcome', 'businessRules', 'successCriteria', 'scope'];

const PILLARS = [
  { key: 'business_alignment', label: 'Business Alignment', dims: RUBRIC.BUSINESS_ALIGNMENT },
  { key: 'requirement_coverage', label: 'Requirement Coverage', dims: RUBRIC.REQUIREMENT_COVERAGE },
  { key: 'ux_experience', label: 'UX Experience', dims: RUBRIC.UX_EXPERIENCE },
  { key: 'ai_experience', label: 'AI Experience', dims: RUBRIC.AI_EXPERIENCE, ai: true },
];
const DIM_PILLAR = new Map();
for (const p of PILLARS) for (const d of p.dims) DIM_PILLAR.set(d.key, p.key);

// The three fields whose absence is an input gap, and the pillar that reads
// each one. A gap only counts against confidence while its pillar actually
// produced a score (ADQR's filterActionableGaps).
const INPUT_FIELDS = [
  { key: 'requirement', gap: 'missing_requirement', pillar: 'requirement_coverage' },
  { key: 'businessGoal', gap: 'missing_business_goal', pillar: 'business_alignment' },
  { key: 'userGoal', gap: 'missing_user_goal', pillar: 'requirement_coverage' },
];

const FIELD_LABEL = {
  requirement: 'requirement', businessGoal: 'business goal', userGoal: 'user goal',
  businessOutcome: 'business outcome', businessRules: 'business rules',
  successCriteria: 'success criteria', scope: 'scope',
};

const REASON_SHORT = {
  missing_field: (dim) => `No ${FIELD_LABEL[dim.requiresField] || dim.requiresField} provided.`,
  insufficient_evidence: () => 'Only one screen reviewed.',
  insufficient_modality_evidence: () => 'Needs an interactive version to verify.',
  out_of_scope: () => "Doesn't apply to this design.",
};

const VERDICT_LABEL = {
  ready_for_engineering: 'Ready for engineering',
  revise_before_engineering: 'Revise before engineering',
  ux_review_required: 'Needs UX review',
  insufficient_evidence: 'Insufficient evidence',
};

const has = (v) => typeof v === 'string' && v.trim() !== '';

/**
 * Applies ADQR's rules to Claude's judged bands. Throws with a full list of
 * problems when the input is incomplete or malformed, so a bad call is fixed
 * in one round trip rather than one error at a time.
 */
function scoreDesignReview(input) {
  const problems = [];
  const {
    title = '', modality, screenCount, sufficientContent, contentNote = '', aiPresent,
    context = {}, dimensions = [], flowRisks, requirementElements = [],
    missingRequirements = [], extraFeatures = [],
  } = input || {};

  if (!MODALITIES.includes(modality)) problems.push(`modality must be one of ${MODALITIES.join(', ')}`);
  if (!Number.isInteger(screenCount) || screenCount < 1) problems.push('screenCount must be a whole number of at least 1');
  if (typeof sufficientContent !== 'boolean') problems.push('sufficientContent must be true or false');
  if (typeof aiPresent !== 'boolean') problems.push('aiPresent must be true or false');
  if (!has(contentNote)) problems.push('contentNote is required: one sentence on what the screens actually show');

  const fields = {};
  for (const f of CONTEXT_FIELDS) fields[f] = has(context[f]) ? context[f].trim() : '';

  // Index the judged dimensions, rejecting unknown keys, duplicates, and
  // bands that are not one of the six anchors.
  const raw = new Map();
  for (const d of Array.isArray(dimensions) ? dimensions : []) {
    if (!d || !DIM_PILLAR.has(d.key)) { problems.push(`unknown dimension key "${d && d.key}"`); continue; }
    if (raw.has(d.key)) { problems.push(`dimension "${d.key}" was scored twice`); continue; }
    if (!d.outOfScope) {
      if (!BANDS.includes(d.band)) problems.push(`${d.key}: band must be one of ${BANDS.join('/')}`);
      if (!EVIDENCE_TAGS.includes(d.evidenceTag)) problems.push(`${d.key}: evidenceTag must be one of ${EVIDENCE_TAGS.join(', ')}`);
      if (!has(d.evidence)) problems.push(`${d.key}: evidence is required`);
    }
    if (d.outOfScope && DIM_PILLAR.get(d.key) !== 'ai_experience') problems.push(`${d.key}: outOfScope only applies to AI Experience dimensions`);
    raw.set(d.key, d);
  }

  const caps = RUBRIC.MODALITY_CAPS[modality] || {};
  const excluded = [];
  const pillars = [];

  for (const p of PILLARS) {
    const out = [];
    for (const dim of p.dims) {
      const r = raw.get(dim.key);
      const base = {
        key: dim.key, label: dim.label,
        evidence: r ? r.evidence || null : null,
        evidenceShort: r ? r.evidenceShort || null : null,
        evidenceTag: r && !r.outOfScope ? r.evidenceTag || null : null,
        impact: r ? r.impact || null : null,
      };
      const exclude = (reason) => {
        excluded.push({ pillar: p.key, dimension: dim.label, key: dim.key, reason });
        out.push({ ...base, band: null, appliedBand: null, capped: false, applicable: false, reason, reasonText: REASON_SHORT[reason](dim) });
      };

      if (p.ai) {
        // Precedence (scoring.md): out_of_scope first, independent of
        // modality, so a dimension is never double-excluded.
        if (aiPresent === false) { exclude('out_of_scope'); continue; }
        if (r && r.outOfScope) { exclude('out_of_scope'); continue; }
        const cap = caps[dim.key];
        if (cap === 'n/a') { exclude('insufficient_modality_evidence'); continue; }
        if (!r) { problems.push(`${dim.key}: not scored. Score it, or mark it outOfScope if this concern genuinely does not apply`); continue; }
        const applied = typeof cap === 'number' && r.band > cap ? cap : r.band;
        out.push({ ...base, band: r.band, appliedBand: applied, capped: applied !== r.band, cap: typeof cap === 'number' ? cap : null, applicable: true, reason: null });
        continue;
      }

      // ADQR's applyDimensionGating, in its order: field, then screens,
      // then interactivity.
      if (dim.requiresField && !fields[dim.requiresField]) { exclude('missing_field'); continue; }
      if (dim.requiresMultiScreen && screenCount < 2) { exclude('insufficient_evidence'); continue; }
      if (dim.requiresInteractive && modality === 'static') { exclude('insufficient_modality_evidence'); continue; }
      if (!r) { problems.push(`${dim.key}: not scored, and nothing excludes it for this input`); continue; }
      out.push({ ...base, band: r.band, appliedBand: r.band, capped: false, applicable: true, reason: null });
    }

    const applicable = out.filter((d) => d.applicable);
    let score = null;
    if (applicable.length) {
      const sum = applicable.reduce((s, d) => s + d.appliedBand, 0);
      score = Math.round((sum / (10 * applicable.length)) * 100);
    }
    pillars.push({
      key: p.key, label: p.label, score,
      scoredCount: applicable.length, totalCount: p.dims.length,
      nullReason: score === null ? pillarNullReason(p, aiPresent, out) : null,
      dimensions: out,
    });
  }

  // Requirement elements: the requirement split into individually checkable
  // claims, each traced to the screens. Optional, but it is the evidence
  // behind Requirement Coverage and the only input that can flag a conflict.
  const elements = [];
  for (const [i, e] of (Array.isArray(requirementElements) ? requirementElements : []).entries()) {
    if (!e || !has(e.text)) { problems.push(`requirementElements[${i}]: text is required`); continue; }
    if (!ELEMENT_STATUSES.includes(e.status)) { problems.push(`requirementElements[${i}]: status must be one of ${ELEMENT_STATUSES.join(', ')}`); continue; }
    elements.push({ id: has(e.id) ? e.id : `R${i + 1}`, text: e.text, status: e.status, evidence: e.evidence || null });
  }

  // Flow risks: highlight-only, never scored. Each one needs a whole flow,
  // so a single screen cannot establish that a state is absent.
  const risks = [];
  if (screenCount >= 2) {
    const given = new Map((Array.isArray(flowRisks) ? flowRisks : []).map((f) => [f && f.key, f]));
    for (const c of RUBRIC.FLOW_RISK_CHECKS) {
      const f = given.get(c.key);
      if (!f || typeof f.present !== 'boolean') { problems.push(`flowRisks: "${c.key}" needs present: true or false (${screenCount} screens were reviewed)`); continue; }
      risks.push({ key: c.key, label: c.label, applicable: true, present: f.present, evidence: f.evidence || null });
    }
    for (const k of given.keys()) if (!RUBRIC.FLOW_RISK_CHECKS.some((c) => c.key === k)) problems.push(`flowRisks: unknown key "${k}"`);
  } else {
    for (const c of RUBRIC.FLOW_RISK_CHECKS) risks.push({ key: c.key, label: c.label, applicable: false, present: null, evidence: null, reasonText: 'Needs more than one screen.' });
  }

  if (problems.length) {
    const err = new Error('score_design_review could not score this input:\n- ' + problems.join('\n- '));
    err.problems = problems;
    throw err;
  }

  const scoreOf = Object.fromEntries(pillars.map((p) => [p.key, p.score]));
  const inputGaps = INPUT_FIELDS.filter((f) => !fields[f.key]).map((f) => f.gap);
  const actionableGaps = inputGaps.filter((g) => {
    const pillar = INPUT_FIELDS.find((f) => f.gap === g).pillar;
    return scoreOf[pillar] !== null && scoreOf[pillar] !== undefined;
  });
  const conflicts = elements.filter((e) => e.status === 'conflict');
  const { level: confidence, reasons: confidenceReasons } = computeConfidence({
    modality, aiPresent, sufficientContent, actionableGaps,
    modalityExcluded: excluded.filter((d) => d.reason === 'insufficient_modality_evidence' && d.pillar === 'ai_experience').length,
    conflictCount: conflicts.length,
  });
  const verdict = computeVerdict(pillars, confidence);

  return {
    title, modality, screenCount, sufficientContent, contentNote, aiPresent,
    confidence, confidenceReasons, verdict,
    pillars,
    excludedDimensions: excluded,
    inputGaps, actionableGaps,
    requirementElements: elements,
    missingRequirements: Array.isArray(missingRequirements) ? missingRequirements : [],
    extraFeatures: Array.isArray(extraFeatures) ? extraFeatures : [],
    flowRisks: risks,
    rubric: 'ADQR by Prafull Mane. Rules applied in code; the rubric has not been through its calibration study yet.',
  };
}

function pillarNullReason(p, aiPresent, dims) {
  if (p.ai && aiPresent === false) return 'No AI feature in this design.';
  if (p.ai) return dims.every((d) => d.reason === 'out_of_scope') ? "None of these concerns apply here." : "Can't tell from this input.";
  const missing = [...new Set(dims.filter((d) => d.reason === 'missing_field').map((d) => FIELD_LABEL[p.dims.find((x) => x.key === d.key).requiresField]))];
  if (missing.length > 2) return 'No business context provided.';
  if (missing.length) return `No ${missing.join(' or ')} provided.`;
  return 'Nothing scorable from this input.';
}

/**
 * ADQR's computeConfidence, plus the spec's "conflicting requirements" row.
 * Returns the level and the plain reasons behind it, so the chat can say why
 * rather than just showing a label.
 */
function computeConfidence({ modality, aiPresent, sufficientContent, actionableGaps, modalityExcluded, conflictCount }) {
  const reasons = [];
  // Checked first and overrides everything (decisions.md #011).
  if (sufficientContent === false) {
    return { level: 'low', reasons: ["The screens don't show enough real product UI to judge (a loading screen, cover page, blank or error state)."] };
  }
  const gapText = actionableGaps.map((g) => g.replace(/^missing_/, '').replace(/_/g, ' '));
  if (actionableGaps.length) reasons.push(`Missing ${gapText.join(', ')}.`);
  if (conflictCount) reasons.push(`${conflictCount} requirement ${conflictCount === 1 ? 'element conflicts' : 'elements conflict'} with the design.`);

  // Modality is an AI-Experience-only concern, so a complete, no-AI review
  // can reach High from a static screenshot.
  if (!aiPresent) {
    return actionableGaps.length || conflictCount ? { level: 'low', reasons } : { level: 'high', reasons: ['Every scored pillar had the context it needs, and there is no AI feature for the input type to limit.'] };
  }
  if (!actionableGaps.length && !conflictCount && modality === 'fully_interactive' && modalityExcluded <= 1) {
    return { level: 'high', reasons: ['Every scored pillar had the context it needs, the input was fully interactive, and the AI behaviour was checkable.'] };
  }
  if (modality === 'static') reasons.push('Static screens cannot show how the AI features behave.');
  if (modalityExcluded > 4) reasons.push(`${modalityExcluded} AI Experience checks could not be judged from this input.`);
  if (actionableGaps.length || conflictCount || modality === 'static' || modalityExcluded > 4) return { level: 'low', reasons };
  if (modality === 'semi_interactive') reasons.push('Semi-interactive input caps several AI Experience checks.');
  if (modalityExcluded >= 2) reasons.push(`${modalityExcluded} AI Experience checks could not be judged from this input.`);
  return { level: 'medium', reasons };
}

/**
 * Gated on the weakest scored pillar, never an average (decisions.md #010):
 * one genuinely bad area drives the outcome even when the rest are fine.
 * Low confidence overrides every score-based call.
 */
function computeVerdict(pillars, confidence) {
  if (confidence === 'low') return { decision: 'insufficient_evidence', label: VERDICT_LABEL.insufficient_evidence, gatingPillar: null };
  const scored = pillars.filter((p) => p.score !== null);
  if (!scored.length) return { decision: 'insufficient_evidence', label: VERDICT_LABEL.insufficient_evidence, gatingPillar: null };
  const worst = scored.reduce((w, p) => (p.score < w.score ? p : w));
  const decision = worst.score < 60 ? 'ux_review_required' : worst.score < 80 ? 'revise_before_engineering' : 'ready_for_engineering';
  return { decision, label: VERDICT_LABEL[decision], gatingPillar: worst.label, gatingPillarKey: worst.key, gatingScore: worst.score };
}

module.exports = {
  RUBRIC, BANDS, MODALITIES, EVIDENCE_TAGS, ELEMENT_STATUSES, CONTEXT_FIELDS, PILLARS,
  scoreDesignReview, computeConfidence, computeVerdict,
};
