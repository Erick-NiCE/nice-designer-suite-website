#!/bin/sh
# macOS: double-click this file in Finder.
cd "$(dirname "$0")"
node install.js
echo
echo "Press any key to close…"
read -n 1 -s -r
