#!/usr/bin/env node
// ─── nice-designer-mcp ────────────────────────────────────────────────────────
// Local MCP server that fronts the NiCE Designer plugin over a WebSocket hub.
// Claude connects via stdio (standard MCP transport); the Figma UI and/or the
// Chrome extension background service worker connect out to ws://127.0.0.1:7331
// and register as 'figma' or 'chrome' targets.  Tool calls are correlated by
// a server-generated request id and a response envelope.
//
// See packages/mcp-server/README.md for setup.

'use strict';

const path = require('path');
const { WebSocketServer } = require('ws');
const { randomUUID } = require('crypto');

// Two layouts are supported:
//   dev:  .../nice-designer-plugin/packages/mcp-server/src/index.js → REPO_ROOT = nice-designer-plugin/
//   dist: .../chrome/mcp-server/src/index.js                        → REPO_ROOT = chrome/
const REPO_ROOT = path.basename(path.resolve(__dirname, '..', '..')) === 'packages'
  ? path.resolve(__dirname, '..', '..', '..')
  : path.resolve(__dirname, '..', '..');
const { Server } = require('@modelcontextprotocol/sdk/server/index.js');
const { StdioServerTransport } = require('@modelcontextprotocol/sdk/server/stdio.js');
const {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} = require('@modelcontextprotocol/sdk/types.js');

// ─── Config ───────────────────────────────────────────────────────────────────

const WS_PORT = Number(process.env.NICE_MCP_WS_PORT) || 7331;
const REQUEST_TIMEOUT_MS = 30_000;
const HEARTBEAT_MS = 15_000;
const SESSION_STALE_MS = 45_000; // 3 missed heartbeats
const PROXY_REQUEST_TIMEOUT_MS = 35_000;
const { WebSocket } = require('ws');

// ─── Mode: primary hub vs proxy client ────────────────────────────────────────
// Only one nice-designer-mcp process can bind port 7331. That one is "primary"
// and owns the WebSocket hub the plugin connects to. Any additional
// nice-designer-mcp processes (Claude Desktop often spawns several — one per
// window / project) become "proxy" processes: they open a WS client to the
// primary and forward every tool call over it. Without this, only one Claude
// process sees sessions and the others silently return "No targets".

const MODE = { kind: 'starting', startedAt: Date.now(), pid: process.pid };
let proxyWs = null;                              // set when MODE.kind === 'proxy'
let proxyReconnectTimer = null;
const proxyPending = new Map();                  // reqId → {resolve, reject, timer}
let cachedProxySessions = [];                    // last-known targets from primary
let cachedProxyHubInfo = null;                   // {pid, port, startedAt, isPrimary:true}

// ─── WebSocket hub ────────────────────────────────────────────────────────────
// Each connecting plugin registers via `{kind:'hello', target, label}`. We keep
// at most one active session per target. Heartbeats drop stale sessions so
// list_targets never reports a ghost.

/** @type {Map<string, {ws: import('ws').WebSocket, target: 'figma'|'chrome', label: string, connectedAt: number, lastSeen: number}>} */
const sessions = new Map();
/** @type {Map<string, {resolve: (msgs: any[]) => void, reject: (e: Error) => void, timer: NodeJS.Timeout}>} */
const pending = new Map();
/** @type {Set<import('ws').WebSocket>} */
const proxyClients = new Set();                  // other MCP processes talking to us
const recentDisconnects = [];                    // last 10 drop events

function logErr(...args) { console.error('[nice-designer-mcp]', ...args); }

function recordDisconnect(entry) {
  recentDisconnects.push({ ...entry, at: Date.now() });
  if (recentDisconnects.length > 10) recentDisconnects.shift();
}

function pickSession(target) {
  for (const s of sessions.values()) if (s.target === target) return s;
  return null;
}

function listLocalSessions() {
  const out = [];
  for (const [id, s] of sessions.entries()) {
    out.push({
      sessionId: id, target: s.target, label: s.label,
      connectedAt: s.connectedAt, lastSeen: s.lastSeen,
    });
  }
  return out;
}

function hubInfo() {
  return {
    pid: process.pid,
    port: WS_PORT,
    startedAt: MODE.startedAt,
    isPrimary: MODE.kind === 'primary',
    mode: MODE.kind,
  };
}

// Resolve target for tool calls. In primary mode, uses local sessions. In proxy
// mode, uses the last list pushed by the primary.
function resolveTarget(target) {
  if (target && target !== 'auto') return target;
  const pool = MODE.kind === 'primary'
    ? Array.from(new Set(Array.from(sessions.values()).map(s => s.target)))
    : Array.from(new Set(cachedProxySessions.map(s => s.target)));
  if (pool.length === 1) return pool[0];
  if (pool.length === 0) throw new Error("No plugin is connected. Install the Figma plugin or Chrome extension, turn the 'Connect to Claude MCP' toggle on, make sure Claude Desktop is running, and retry. Call get_diagnostics for details.");
  throw new Error("Multiple targets connected (figma + chrome). Pass target explicitly, or call list_targets first.");
}

// ─── sendRequest: primary = direct, proxy = forwarded ─────────────────────────

function sendRequestPrimary(target, message) {
  const session = pickSession(target);
  if (!session) {
    return Promise.reject(new Error(
      `No '${target}' plugin is connected. Open the NiCE Designer ${target === 'figma' ? 'Figma plugin' : 'Chrome extension'} and retry. get_diagnostics shows who is currently connected.`
    ));
  }
  const id = randomUUID();
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(new Error(`Request ${id} (${message.type}) timed out after ${REQUEST_TIMEOUT_MS} ms`));
    }, REQUEST_TIMEOUT_MS);
    pending.set(id, { resolve, reject, timer });
    try {
      session.ws.send(JSON.stringify({ kind: 'request', id, message }));
    } catch (e) {
      clearTimeout(timer);
      pending.delete(id);
      reject(e);
    }
  });
}

function sendRequestProxy(target, message) {
  if (!proxyWs || proxyWs.readyState !== 1) {
    return Promise.reject(new Error('Proxy MCP process cannot reach the primary hub. Try restarting Claude, or confirm no stale nice-designer-mcp processes are running.'));
  }
  const reqId = randomUUID();
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      proxyPending.delete(reqId);
      reject(new Error(`Proxy request ${reqId} (${message.type}) timed out after ${PROXY_REQUEST_TIMEOUT_MS} ms`));
    }, PROXY_REQUEST_TIMEOUT_MS);
    proxyPending.set(reqId, { resolve, reject, timer });
    try {
      proxyWs.send(JSON.stringify({ kind: 'proxy_request', reqId, target, message }));
    } catch (e) {
      clearTimeout(timer);
      proxyPending.delete(reqId);
      reject(e);
    }
  });
}

function sendRequest(target, message) {
  target = resolveTarget(target);
  if (MODE.kind === 'proxy') return sendRequestProxy(target, message);
  return sendRequestPrimary(target, message);
}

// ─── Primary hub ──────────────────────────────────────────────────────────────

function broadcastSessionsToProxies() {
  if (proxyClients.size === 0) return;
  const payload = JSON.stringify({
    kind: 'proxy_sessions',
    sessions: listLocalSessions(),
    hub: hubInfo(),
  });
  for (const pc of proxyClients) {
    try { pc.send(payload); } catch { /* proxy gone */ }
  }
}

function sweepStaleSessions() {
  const now = Date.now();
  let changed = false;
  for (const [sid, s] of sessions.entries()) {
    if (now - s.lastSeen > SESSION_STALE_MS) {
      logErr(`session ${sid.slice(0, 8)} (${s.target}) stale — dropping`);
      recordDisconnect({ sessionId: sid, target: s.target, reason: 'stale' });
      try { s.ws.close(); } catch { /* noop */ }
      sessions.delete(sid);
      changed = true;
    }
  }
  if (changed) broadcastSessionsToProxies();
}

function startPrimaryHub(wss) {
  MODE.kind = 'primary';
  logErr(`WebSocket hub listening on ws://127.0.0.1:${WS_PORT} (primary, pid=${process.pid})`);
  setInterval(sweepStaleSessions, 5_000).unref();

  wss.on('connection', (ws) => {
    const sid = randomUUID();
    let isProxy = false;

    ws.on('message', (raw) => {
      let data;
      try { data = JSON.parse(String(raw)); } catch { return; }
      if (!data || typeof data !== 'object') return;

      // Plugin hello
      if (data.kind === 'hello' && (data.target === 'figma' || data.target === 'chrome')) {
        sessions.set(sid, {
          ws,
          target: data.target,
          label: String(data.label || ''),
          connectedAt: Date.now(),
          lastSeen: Date.now(),
        });
        logErr(`session ${sid.slice(0, 8)} registered as '${data.target}'${data.label ? ` (${data.label})` : ''}`);
        try {
          ws.send(JSON.stringify({ kind: 'hello_ack', repoRoot: REPO_ROOT, platform: process.platform, heartbeatMs: HEARTBEAT_MS }));
        } catch { /* socket closed mid-ack */ }
        broadcastSessionsToProxies();
        return;
      }

      // Proxy (other MCP process) hello
      if (data.kind === 'hello_proxy') {
        isProxy = true;
        proxyClients.add(ws);
        logErr(`proxy client attached (now ${proxyClients.size})`);
        try {
          ws.send(JSON.stringify({
            kind: 'proxy_sessions',
            sessions: listLocalSessions(),
            hub: hubInfo(),
          }));
        } catch { /* noop */ }
        return;
      }

      // Plugin heartbeat
      if (data.kind === 'ping') {
        const s = sessions.get(sid);
        if (s) s.lastSeen = Date.now();
        try { ws.send(JSON.stringify({ kind: 'pong', t: Date.now() })); } catch { /* noop */ }
        return;
      }

      // Plugin response to request
      if (data.kind === 'response' && typeof data.id === 'string') {
        const s = sessions.get(sid);
        if (s) s.lastSeen = Date.now();
        // Primary's own pending
        const p = pending.get(data.id);
        if (p) {
          clearTimeout(p.timer);
          pending.delete(data.id);
          p.resolve(Array.isArray(data.messages) ? data.messages : []);
          return;
        }
        // Response to a proxy_request we forwarded on behalf of a proxy
        const proxyReq = proxyResponseRouter.get(data.id);
        if (proxyReq) {
          proxyResponseRouter.delete(data.id);
          try {
            proxyReq.proxy.send(JSON.stringify({
              kind: 'proxy_response',
              reqId: proxyReq.reqId,
              ok: true,
              messages: Array.isArray(data.messages) ? data.messages : [],
            }));
          } catch { /* proxy gone */ }
        }
        return;
      }

      // Proxy forwarding a Claude tool call
      if (data.kind === 'proxy_request' && typeof data.reqId === 'string' && data.message) {
        const target = data.target;
        const session = pickSession(target);
        if (!session) {
          try {
            ws.send(JSON.stringify({
              kind: 'proxy_response', reqId: data.reqId, ok: false,
              error: `No '${target}' plugin is connected on primary hub.`,
            }));
          } catch { /* noop */ }
          return;
        }
        const id = randomUUID();
        proxyResponseRouter.set(id, { proxy: ws, reqId: data.reqId });
        // Safety timeout so router doesn't leak if plugin never replies
        setTimeout(() => {
          if (proxyResponseRouter.has(id)) {
            proxyResponseRouter.delete(id);
            try {
              ws.send(JSON.stringify({
                kind: 'proxy_response', reqId: data.reqId, ok: false,
                error: 'Upstream plugin response timed out on primary hub.',
              }));
            } catch { /* noop */ }
          }
        }, REQUEST_TIMEOUT_MS + 5_000).unref();
        try {
          session.ws.send(JSON.stringify({ kind: 'request', id, message: data.message }));
        } catch (e) {
          proxyResponseRouter.delete(id);
          try {
            ws.send(JSON.stringify({
              kind: 'proxy_response', reqId: data.reqId, ok: false,
              error: `Primary hub failed to forward to plugin: ${e.message}`,
            }));
          } catch { /* noop */ }
        }
        return;
      }

      // Proxy asking for a fresh sessions dump
      if (data.kind === 'proxy_list_sessions') {
        try {
          ws.send(JSON.stringify({
            kind: 'proxy_sessions',
            sessions: listLocalSessions(),
            hub: hubInfo(),
          }));
        } catch { /* noop */ }
        return;
      }
    });

    ws.on('close', () => {
      if (sessions.has(sid)) {
        const s = sessions.get(sid);
        logErr(`session ${sid.slice(0, 8)} (${s.target}) disconnected`);
        recordDisconnect({ sessionId: sid, target: s.target, reason: 'close' });
        sessions.delete(sid);
        broadcastSessionsToProxies();
      }
      if (isProxy) {
        proxyClients.delete(ws);
        logErr(`proxy client detached (now ${proxyClients.size})`);
      }
    });
    ws.on('error', (e) => logErr(`ws error on ${sid.slice(0, 8)}:`, e.message));
  });
  wss.on('error', (e) => logErr('hub error:', e.message));
}

// Maps the plugin-side request id (generated when primary forwards a
// proxy_request) back to the proxy ws and proxy-side reqId so responses can be
// routed home.
const proxyResponseRouter = new Map();

// ─── Proxy mode: connect to an already-running primary ───────────────────────

function connectProxy() {
  if (MODE.kind === 'starting') MODE.kind = 'proxy';
  try {
    proxyWs = new WebSocket(`ws://127.0.0.1:${WS_PORT}`);
  } catch (e) {
    logErr('proxy WebSocket construct failed:', e.message);
    scheduleProxyReconnect();
    return;
  }
  proxyWs.on('open', () => {
    logErr(`proxy connected to primary hub on :${WS_PORT}`);
    try { proxyWs.send(JSON.stringify({ kind: 'hello_proxy', pid: process.pid })); } catch { /* noop */ }
  });
  proxyWs.on('message', (raw) => {
    let data;
    try { data = JSON.parse(String(raw)); } catch { return; }
    if (!data || typeof data !== 'object') return;

    if (data.kind === 'proxy_sessions') {
      cachedProxySessions = Array.isArray(data.sessions) ? data.sessions : [];
      cachedProxyHubInfo = data.hub || null;
      return;
    }
    if (data.kind === 'proxy_response' && typeof data.reqId === 'string') {
      const p = proxyPending.get(data.reqId);
      if (!p) return;
      clearTimeout(p.timer);
      proxyPending.delete(data.reqId);
      if (data.ok) p.resolve(Array.isArray(data.messages) ? data.messages : []);
      else p.reject(new Error(String(data.error || 'proxy_response: primary reported failure')));
      return;
    }
  });
  proxyWs.on('close', () => {
    logErr('proxy WebSocket closed — will retry');
    proxyWs = null;
    // Fail any pending requests immediately with a clear error so Claude can retry
    for (const [, p] of proxyPending) {
      clearTimeout(p.timer);
      try { p.reject(new Error('Primary hub connection lost before response.')); } catch { /* noop */ }
    }
    proxyPending.clear();
    scheduleProxyReconnect();
  });
  proxyWs.on('error', (e) => logErr('proxy ws error:', e.message));
}

function scheduleProxyReconnect() {
  if (proxyReconnectTimer) return;
  proxyReconnectTimer = setTimeout(() => {
    proxyReconnectTimer = null;
    // Before reconnecting as proxy, try to re-bind in case primary died.
    tryBindOrProxy();
  }, 2_000).unref();
}

// ─── Startup: try to bind, fall back to proxy ────────────────────────────────

function tryBindOrProxy() {
  const wss = new WebSocketServer({ host: '127.0.0.1', port: WS_PORT });
  let decided = false;
  wss.on('listening', () => {
    decided = true;
    startPrimaryHub(wss);
  });
  wss.on('error', (err) => {
    if (decided) { logErr('hub error post-listen:', err.message); return; }
    decided = true;
    if (err && err.code === 'EADDRINUSE') {
      logErr(`port ${WS_PORT} already in use — starting in proxy mode`);
      connectProxy();
    } else {
      logErr('failed to bind hub:', err && err.message);
      // Retry shortly — might be a transient bind race
      setTimeout(tryBindOrProxy, 2_000).unref();
    }
  });
}

function startHub() { tryBindOrProxy(); }

// ─── Tool surface ─────────────────────────────────────────────────────────────
// Most tools pass a typed payload straight through as a UIMessage.  We also
// expose `call_plugin` as an escape hatch for the full ~35-operation surface
// without having to enumerate each one here, and two orchestration tools
// (`lyra_compliance_report`, `migrate_to_lyra`) that compose several calls.

const TARGET_ENUM = { type: 'string', enum: ['figma', 'chrome', 'auto'], description: "'auto' picks the single connected target — use list_targets first if both are connected." };
const SYSTEM_ENUM = { type: 'string', enum: ['sol', 'lyra'] };

// ─── Helpers for inline summaries / gauges ────────────────────────────────────
// Mutation tools call an audit before+after and return a compact markdown gauge
// so Claude can surface the delta inline. Plain text works across every MCP
// client; no base64 images needed.

function resolveTarget(target) {
  if (target && target !== 'auto') return target;
  const targets = Array.from(new Set(Array.from(sessions.values()).map(s => s.target)));
  if (targets.length === 1) return targets[0];
  if (targets.length === 0) throw new Error("No plugin is connected. Install the Figma plugin or Chrome extension, turn the 'Connect to Claude MCP' toggle on, and retry.");
  throw new Error("Multiple targets connected (figma + chrome). Pass target explicitly, or call list_targets first.");
}

function extractAuditReport(msgs) {
  if (!Array.isArray(msgs)) return null;
  const hit = msgs.find(m => m && m.type === 'AUDIT_REPORT' && m.report);
  return hit ? hit.report : null;
}

function gauge(score, width = 20) {
  const s = Math.max(0, Math.min(100, Math.round(Number(score) || 0)));
  const filled = Math.round((s / 100) * width);
  return `[${'█'.repeat(filled)}${'░'.repeat(width - filled)}] ${s}%`;
}

// Domains differ by target: Chrome DOM has no reusable components, so the
// Components row is hidden there.  Accessibility is only shown when the
// report actually contains a11y data.
function domainRows(report, target) {
  const rows = [
    ['Colors',      report.colorIssues?.length],
    ['Text styles', report.textIssues?.length],
    ['Spacing',     report.spacingIssues?.length],
  ];
  if (target !== 'chrome') {
    rows.push(['Components', report.componentIssues?.length]);
  }
  if (Array.isArray(report.accessibilityIssues)) {
    rows.push(['Accessibility', report.accessibilityIssues.length]);
  }
  return rows;
}

function summarizeAudit(report, system, target) {
  if (!report) return `No audit data returned from ${target}.`;
  const lines = [];
  lines.push(`### ${String(system || '').toUpperCase()} compliance — ${target}`);
  lines.push('');
  lines.push(`Overall  ${gauge(report.score)}`);
  if (Array.isArray(report.accessibilityIssues)) {
    lines.push(`A11y     ${gauge(report.accessibilityScore)}`);
  }
  lines.push('');
  lines.push(`| Domain | Issues |`);
  lines.push(`| --- | --- |`);
  for (const [name, count] of domainRows(report, target)) {
    lines.push(`| ${name} | ${count ?? 0} |`);
  }
  lines.push(`| Nodes scanned | ${report.totalNodes ?? 0} |`);
  return lines.join('\n');
}

// Collect currently-connected clients plus their current selection, so the
// audit output leads with "which target(s) am I looking at?".
async function buildClientsHeader() {
  const pool = MODE.kind === 'primary'
    ? listLocalSessions()
    : cachedProxySessions;
  const seen = new Set();
  const entries = [];
  for (const s of pool) {
    if (seen.has(s.target)) continue;
    seen.add(s.target);
    const label = await selectionLabel(s.target);
    const display = s.target === 'chrome' ? 'Chrome' : s.target === 'figma' ? 'Figma' : s.target;
    entries.push(`${display} "${label}"`);
  }
  if (entries.length === 0) return null;
  return `**Clients:** ${entries.join(', ')}`;
}

async function selectionLabel(target) {
  try {
    const msgs = await sendRequest(target, { type: 'GET_SELECTION_INFO' });
    const hit = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'SELECTION_INFO' && m.info) : null;
    if (hit?.info?.nodeName) return hit.info.nodeName;
  } catch { /* ignore — fall through to defaults */ }
  return target === 'chrome' ? 'Selected Page' : 'Selected Artboard';
}

function summarizeDelta(before, after, system, target) {
  if (!before || !after) return summarizeAudit(after || before, system, target);
  const d = (a, b) => `${a} → ${b} (${b - a >= 0 ? '+' : ''}${b - a})`;
  const lines = [];
  lines.push(`### ${String(system || '').toUpperCase()} delta — ${target}`);
  lines.push('');
  lines.push(`Overall  ${gauge(before.score)}  →  ${gauge(after.score)}`);
  lines.push(`A11y     ${gauge(before.accessibilityScore)}  →  ${gauge(after.accessibilityScore)}`);
  lines.push('');
  lines.push(`| Domain | Before → After |`);
  lines.push(`| --- | --- |`);
  lines.push(`| Colors | ${d(before.colorIssues?.length ?? 0, after.colorIssues?.length ?? 0)} |`);
  lines.push(`| Text styles | ${d(before.textIssues?.length ?? 0, after.textIssues?.length ?? 0)} |`);
  lines.push(`| Spacing | ${d(before.spacingIssues?.length ?? 0, after.spacingIssues?.length ?? 0)} |`);
  if (target !== 'chrome') {
    lines.push(`| Components | ${d(before.componentIssues?.length ?? 0, after.componentIssues?.length ?? 0)} |`);
  }
  if (Array.isArray(before.accessibilityIssues) || Array.isArray(after.accessibilityIssues)) {
    lines.push(`| A11y | ${d(before.accessibilityIssues?.length ?? 0, after.accessibilityIssues?.length ?? 0)} |`);
  }
  return lines.join('\n');
}

// Wrap a handler result so it returns both a markdown summary (for inline
// display) and the raw JSON (for Claude to reason over).  Optional `svg` is
// surfaced as an inline image content block — clients that render image/svg+xml
// (Claude Desktop) show the gauge visually; others fall back to the markdown.
function richResult(summary, data, svg) {
  return { __rich: true, summary, data, svg: svg || null };
}

// ─── SVG gauge rendering ──────────────────────────────────────────────────────
// Plain SVG (no <foreignObject>, no JS) so any client that accepts an image
// content block can rasterize it.

function escapeXml(s) {
  return String(s).replace(/[<>&"']/g, c =>
    ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c])
  );
}

function gaugeColor(score) {
  const s = Math.max(0, Math.min(100, Number(score) || 0));
  if (s >= 80) return '#16a34a';
  if (s >= 60) return '#ca8a04';
  return '#dc2626';
}

function svgGaugeRow({ label, score, y, width, labelW = 120 }) {
  const s = Math.max(0, Math.min(100, Math.round(Number(score) || 0)));
  const trackX = labelW + 16;
  const trackW = width - trackX - 56;
  const fillW = Math.max(2, Math.round(trackW * s / 100));
  const color = gaugeColor(s);
  return [
    `<text x="20" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="13" font-weight="500" fill="#0f172a">${escapeXml(label)}</text>`,
    `<rect x="${trackX}" y="${y}" width="${trackW}" height="18" rx="9" fill="#e2e8f0" />`,
    `<rect x="${trackX}" y="${y}" width="${fillW}" height="18" rx="9" fill="${color}" />`,
    `<text x="${trackX + trackW + 8}" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="12" font-weight="700" fill="#334155">${s}%</text>`,
  ].join('');
}

function gaugeSvg(report, system, target) {
  if (!report) return null;
  const W = 580;
  const parts = [];
  let y = 50;
  const title = `${String(system || '').toUpperCase()} compliance — ${target}`;
  parts.push(`<text x="20" y="28" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="15" font-weight="700" fill="#0f172a">${escapeXml(title)}</text>`);
  parts.push(svgGaugeRow({ label: 'Overall', score: report.score, y, width: W }));
  y += 32;
  if (Array.isArray(report.accessibilityIssues)) {
    parts.push(svgGaugeRow({ label: 'Accessibility', score: report.accessibilityScore, y, width: W }));
    y += 32;
  }
  y += 8;
  parts.push(`<line x1="20" x2="${W - 20}" y1="${y - 4}" y2="${y - 4}" stroke="#e2e8f0" stroke-width="1"/>`);
  for (const [name, count] of domainRows(report, target)) {
    const c = count || 0;
    parts.push(`<text x="20" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="12" fill="#334155">${escapeXml(name)}</text>`);
    parts.push(`<text x="${W - 20}" y="${y + 14}" text-anchor="end" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="12" font-weight="600" fill="${c > 0 ? '#dc2626' : '#16a34a'}">${c} ${c === 1 ? 'issue' : 'issues'}</text>`);
    y += 22;
  }
  parts.push(`<text x="20" y="${y + 16}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="11" fill="#64748b">Nodes scanned: ${report.totalNodes || 0}</text>`);
  y += 30;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${y}" viewBox="0 0 ${W} ${y}"><rect width="100%" height="100%" fill="#ffffff"/>${parts.join('')}</svg>`;
}

function gaugeDeltaSvg(before, after, system, target) {
  if (!after) return gaugeSvg(before, system, target);
  if (!before) return gaugeSvg(after, system, target);
  const W = 640;
  const parts = [];
  let y = 50;
  const title = `${String(system || '').toUpperCase()} delta — ${target}`;
  parts.push(`<text x="20" y="28" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="15" font-weight="700" fill="#0f172a">${escapeXml(title)}</text>`);

  const rowDelta = (label, beforeScore, afterScore) => {
    const out = [];
    out.push(`<text x="20" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="13" font-weight="500" fill="#0f172a">${escapeXml(label)}</text>`);
    const bx = 140, gw = 200;
    const beforeFill = Math.round(gw * Math.max(0, Math.min(100, Number(beforeScore) || 0)) / 100);
    out.push(`<rect x="${bx}" y="${y}" width="${gw}" height="18" rx="9" fill="#e2e8f0"/>`);
    out.push(`<rect x="${bx}" y="${y}" width="${beforeFill}" height="18" rx="9" fill="${gaugeColor(beforeScore)}" opacity="0.55"/>`);
    out.push(`<text x="${bx + gw + 8}" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="11" fill="#64748b">${Math.round(beforeScore || 0)}%</text>`);
    out.push(`<text x="${bx + gw + 36}" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="13" fill="#64748b">→</text>`);
    const ax = bx + gw + 56;
    const afterFill = Math.round(gw * Math.max(0, Math.min(100, Number(afterScore) || 0)) / 100);
    out.push(`<rect x="${ax}" y="${y}" width="${gw}" height="18" rx="9" fill="#e2e8f0"/>`);
    out.push(`<rect x="${ax}" y="${y}" width="${afterFill}" height="18" rx="9" fill="${gaugeColor(afterScore)}"/>`);
    out.push(`<text x="${ax + gw + 8}" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="12" font-weight="700" fill="#334155">${Math.round(afterScore || 0)}%</text>`);
    return out.join('');
  };

  parts.push(rowDelta('Overall', before.score, after.score));
  y += 32;
  if (Array.isArray(before.accessibilityIssues) || Array.isArray(after.accessibilityIssues)) {
    parts.push(rowDelta('Accessibility', before.accessibilityScore, after.accessibilityScore));
    y += 32;
  }
  y += 8;
  parts.push(`<line x1="20" x2="${W - 20}" y1="${y - 4}" y2="${y - 4}" stroke="#e2e8f0" stroke-width="1"/>`);
  const rows = [
    ['Colors', before.colorIssues?.length ?? 0, after.colorIssues?.length ?? 0],
    ['Text styles', before.textIssues?.length ?? 0, after.textIssues?.length ?? 0],
    ['Spacing', before.spacingIssues?.length ?? 0, after.spacingIssues?.length ?? 0],
  ];
  if (target !== 'chrome') rows.push(['Components', before.componentIssues?.length ?? 0, after.componentIssues?.length ?? 0]);
  if (Array.isArray(before.accessibilityIssues) || Array.isArray(after.accessibilityIssues)) {
    rows.push(['A11y', before.accessibilityIssues?.length ?? 0, after.accessibilityIssues?.length ?? 0]);
  }
  for (const [name, b, a] of rows) {
    parts.push(`<text x="20" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="12" fill="#334155">${escapeXml(name)}</text>`);
    const delta = a - b;
    const deltaStr = `${b} → ${a} (${delta >= 0 ? '+' : ''}${delta})`;
    const color = delta < 0 ? '#16a34a' : delta > 0 ? '#dc2626' : '#64748b';
    parts.push(`<text x="${W - 20}" y="${y + 14}" text-anchor="end" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="12" font-weight="600" fill="${color}">${deltaStr}</text>`);
    y += 22;
  }
  y += 8;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${y}" viewBox="0 0 ${W} ${y}"><rect width="100%" height="100%" fill="#ffffff"/>${parts.join('')}</svg>`;
}

const TOOLS = [
  {
    name: 'list_targets',
    description: 'List plugin sessions (figma / chrome) currently connected to the MCP hub. Always returns hub info so you can tell whether you are on the primary hub or a proxy.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: async () => {
      if (MODE.kind === 'proxy') {
        // Ask the primary for a fresh dump, but still return the cached list
        // immediately so Claude never blocks waiting for a sessions push.
        if (proxyWs && proxyWs.readyState === 1) {
          try { proxyWs.send(JSON.stringify({ kind: 'proxy_list_sessions' })); } catch { /* noop */ }
        }
        return {
          targets: cachedProxySessions,
          hub: cachedProxyHubInfo || { ...hubInfo(), primaryReachable: !!(proxyWs && proxyWs.readyState === 1) },
          thisProcess: hubInfo(),
        };
      }
      return { targets: listLocalSessions(), hub: hubInfo() };
    },
  },
  {
    name: 'get_diagnostics',
    description: 'Return a full health report on the MCP bridge: this process, the hub, connected plugin sessions, and recent disconnects. Call this first if list_targets looks wrong.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: async () => {
      const now = Date.now();
      const base = {
        now,
        thisProcess: hubInfo(),
        heartbeatMs: HEARTBEAT_MS,
        sessionStaleMs: SESSION_STALE_MS,
      };
      if (MODE.kind === 'proxy') {
        return {
          ...base,
          primaryReachable: !!(proxyWs && proxyWs.readyState === 1),
          primaryHub: cachedProxyHubInfo,
          targetsFromPrimary: cachedProxySessions,
          pendingProxyRequests: proxyPending.size,
          advice: cachedProxySessions.length === 0
            ? 'Primary is reachable but reports no plugin sessions. Check the extension/plugin toggle and that the browser tab is open.'
            : 'Bridge is healthy.',
        };
      }
      return {
        ...base,
        hub: hubInfo(),
        sessions: listLocalSessions().map(s => ({ ...s, staleInMs: SESSION_STALE_MS - (now - s.lastSeen) })),
        proxyClients: proxyClients.size,
        pendingRequests: pending.size,
        recentDisconnects,
        advice: sessions.size === 0
          ? "Hub is up but no plugin has connected. Confirm the 'Connect to Claude MCP' toggle is on in the Chrome extension / Figma plugin and that it can reach ws://127.0.0.1:" + WS_PORT + '.'
          : 'Bridge is healthy.',
      };
    },
  },
  {
    name: 'get_selection_info',
    description: 'Figma: return info about the currently selected node. Chrome: return info about the currently inspected element.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM },
      required: ['target'],
      additionalProperties: false,
    },
    handler: ({ target }) => sendRequest(target, { type: 'GET_SELECTION_INFO' }),
  },
  {
    name: 'check_libraries',
    description: 'Figma only: verify the SOL or Lyra library is linked to the current file. The plugin caps library lookups at 10 seconds with a fallback to the bundled palette, so this never hangs even when a library is offline.',
    inputSchema: {
      type: 'object',
      properties: { system: SYSTEM_ENUM },
      required: ['system'],
      additionalProperties: false,
    },
    handler: ({ system }) => sendRequest('figma', { type: 'CHECK_LIBRARIES', system }),
  },
  {
    name: 'export_design_tokens',
    description: 'Return the color / text / spacing / radius token palettes for a design system.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        system: SYSTEM_ENUM,
        mode: { type: 'string', enum: ['light', 'dark'] },
      },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system, mode }) => sendRequest(target, { type: 'PREFETCH_TOKENS', system, mode }),
  },
  {
    name: 'run_full_audit',
    description: 'Run the full audit (colors, text, components, spacing, accessibility) and return the combined AuditReport. The report now includes per-category totals (totalColorPaints, totalTextNodes, totalComponentNodes, totalVariableProps) so you can show "X/Y" compliance and compute a meaningful design score on moderately-bad files. Cross-system bindings (Lyra token applied in SOL mode and vice versa) are flagged authoritatively via library variable key membership, not just naming convention. Text issues match font family + size + weight, so an Inter row in SOL mode surfaces as wrong-system with sol/heading/* as the suggested target.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, system: SYSTEM_ENUM },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: async ({ target, system }) => {
      const t = resolveTarget(target);
      const msgs = await sendRequest(t, { type: 'RUN_AUDIT_REPORT', system });
      const report = extractAuditReport(msgs);
      const clients = await buildClientsHeader();
      const body = summarizeAudit(report, system, t);
      const summary = clients ? `${clients}\n\n${body}` : body;
      return richResult(summary, { target: t, system, report, raw: msgs }, gaugeSvg(report, system, t));
    },
  },
  {
    name: 'audit_colors',
    description: 'Scan the current selection / page for color fills and strokes. Each item is classified as on-token (bound to current-system variable), wrong-system (bound to the OTHER system\'s variable, detected via library variable key membership), or off-token (raw color, no binding). Items carry isExact / wrongSystem / boundTokenName fields you can use to triage.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        mode: { type: 'string', enum: ['light', 'dark'] },
      },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system, mode }) => sendRequest(target, { type: 'PREVIEW_COLORS', system, mode }),
  },
  {
    name: 'audit_text_styles',
    description: 'Scan text nodes for typography that does not match a token. Matching is family + size + weight aware: an Inter 16/500 node in SOL mode is now correctly flagged as wrong-system (since Lyra owns Inter) and the suggested token is the role-equivalent SOL token (e.g. lyra/heading/md → sol/heading/md). Items where the family is not in the current system at all are also flagged as wrong-system.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, system: SYSTEM_ENUM },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system }) => sendRequest(target, { type: 'PREVIEW_TEXT_STYLES', system }),
  },
  {
    name: 'audit_spacing',
    description: 'Scan padding / gap / margin values for non-token spacing. Reports include items where the value matches a token but the property is NOT bound to a variable, AND items bound to the OTHER system\'s variable (cross-system, detected via library variable key membership). Mirrors what the Variables tab in the UI surfaces.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, system: SYSTEM_ENUM },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system }) => sendRequest(target, { type: 'PREVIEW_SPACING', system }),
  },
  {
    name: 'audit_radius',
    description: 'Scan corner radius values for non-token radii. Same dual-detection as audit_spacing: matches that aren\'t bound, and bindings from the wrong system. For unified corner radius, the audit now correctly reads the binding from the topLeftRadius slot (Figma stores per-corner; the audit was previously looking at the unbindable cornerRadius slot).',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, system: SYSTEM_ENUM },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system }) => sendRequest(target, { type: 'PREVIEW_RADIUS', system }),
  },
  {
    name: 'audit_components',
    description: 'Find instances from the wrong design system and suggest 1:1 replacements.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, system: SYSTEM_ENUM },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system }) => sendRequest(target, { type: 'RUN_COMPONENT_AUDIT', system }),
  },
  {
    name: 'audit_accessibility',
    description: 'Run the accessibility scan (contrast, touch targets, ARIA, alt text, heading hierarchy, etc).',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM },
      required: ['target'],
      additionalProperties: false,
    },
    handler: ({ target }) => sendRequest(target, { type: 'RUN_ACCESSIBILITY_SCAN' }),
  },
  {
    name: 'convert_colors',
    description: 'Apply color tokens from the given overrides list to the selection. Respects dryRun (default true) which just re-runs the preview.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        system: SYSTEM_ENUM,
        mode: { type: 'string', enum: ['light', 'dark'] },
        overrides: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              nodeId: { type: 'string' },
              property: { type: 'string', enum: ['fill', 'stroke'] },
              fillIndex: { type: 'number' },
              tokenName: { type: 'string' },
            },
            required: ['nodeId', 'property', 'fillIndex', 'tokenName'],
            additionalProperties: false,
          },
        },
        dryRun: { type: 'boolean', default: true },
      },
      required: ['target', 'system', 'overrides'],
      additionalProperties: false,
    },
    handler: ({ target, system, mode, overrides, dryRun = true }) => {
      if (dryRun) return sendRequest(target, { type: 'PREVIEW_COLORS', system, mode });
      return sendRequest(target, { type: 'CONVERT_COLORS', system, overrides, mode, skipPreview: true });
    },
  },
  {
    name: 'convert_text_styles',
    description: 'Apply typography tokens to the given text nodes (or all eligible text nodes). Dry-run by default.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeIds: { type: 'array', items: { type: 'string' } },
        skipNodeIds: { type: 'array', items: { type: 'string' } },
        dryRun: { type: 'boolean', default: true },
      },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system, nodeIds, skipNodeIds, dryRun = true }) => {
      if (dryRun) return sendRequest(target, { type: 'PREVIEW_TEXT_STYLES', system });
      return sendRequest(target, { type: 'CONVERT_TEXT_STYLES', system, nodeIds, skipNodeIds, skipPreview: true });
    },
  },
  {
    name: 'fix_spacing',
    description: 'Bind spacing tokens to non-token spacing values. Dry-run by default.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeIds: { type: 'array', items: { type: 'string' } },
        dryRun: { type: 'boolean', default: true },
      },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system, nodeIds, dryRun = true }) => {
      if (dryRun) return sendRequest(target, { type: 'PREVIEW_SPACING', system });
      return sendRequest(target, { type: 'FIX_SPACING', system, nodeIds, skipPreview: true });
    },
  },
  {
    name: 'fix_radius',
    description: 'Bind radius tokens to non-token corner radii. Dry-run by default.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeIds: { type: 'array', items: { type: 'string' } },
        dryRun: { type: 'boolean', default: true },
      },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system, nodeIds, dryRun = true }) => {
      if (dryRun) return sendRequest(target, { type: 'PREVIEW_RADIUS', system });
      return sendRequest(target, { type: 'FIX_RADIUS', system, nodeIds, skipPreview: true });
    },
  },
  {
    name: 'convert_component',
    description: 'Swap a single component instance for its equivalent in the target design system.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeId: { type: 'string' },
        targetName: { type: 'string' },
      },
      required: ['target', 'system', 'nodeId', 'targetName'],
      additionalProperties: false,
    },
    handler: ({ target, system, nodeId, targetName }) =>
      sendRequest(target, { type: 'CONVERT_COMPONENT', nodeId, targetName, system }),
  },
  {
    name: 'fix_accessibility',
    description: 'Apply an automated fix for a specific accessibility issue on a node.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        nodeId: { type: 'string' },
        issueType: { type: 'string' },
        dryRun: { type: 'boolean', default: true },
      },
      required: ['target', 'nodeId', 'issueType'],
      additionalProperties: false,
    },
    handler: ({ target, nodeId, issueType, dryRun = true }) => {
      if (dryRun) return sendRequest(target, { type: 'RUN_ACCESSIBILITY_SCAN' });
      return sendRequest(target, { type: 'FIX_ACCESSIBILITY', nodeId, issueType, skipPreview: true });
    },
  },
  {
    name: 'generate_multi_system',
    description: 'Figma: duplicate the current selection and convert the copy to the target design system. Returns the new frame id.',
    inputSchema: {
      type: 'object',
      properties: { targetSystem: SYSTEM_ENUM },
      required: ['targetSystem'],
      additionalProperties: false,
    },
    handler: ({ targetSystem }) =>
      sendRequest('figma', { type: 'GENERATE_MULTI_SYSTEM', targetSystem }),
  },
  {
    name: 'convert_mode',
    description: 'Convert the selection to light or dark mode of the given system.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        mode: { type: 'string', enum: ['light', 'dark'] },
      },
      required: ['target', 'system', 'mode'],
      additionalProperties: false,
    },
    handler: ({ target, system, mode }) =>
      sendRequest(target, { type: mode === 'dark' ? 'CONVERT_DARK_MODE' : 'CONVERT_LIGHT_MODE', system }),
  },
  {
    name: 'extract_dev_details',
    description: 'Return dev-handoff details (size, fills, strokes, typography, auto-layout, CSS) for the current selection.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM },
      required: ['target'],
      additionalProperties: false,
    },
    handler: ({ target }) => sendRequest(target, { type: 'GET_DEV_DETAILS' }),
  },
  {
    name: 'extract_all_css',
    description: 'Return CSS for every node in the current scope as a single document.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM },
      required: ['target'],
      additionalProperties: false,
    },
    handler: ({ target }) => sendRequest(target, { type: 'GET_ALL_CSS' }),
  },
  {
    name: 'extract_token_css',
    description: 'Return the active design system\'s tokens as a :root { --token: value } CSS block.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, system: SYSTEM_ENUM },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system }) => sendRequest(target, { type: 'GET_TOKEN_CSS', system }),
  },
  {
    name: 'undo_last_conversion',
    description: 'Undo the most recent color conversion (snapshot-based, plugin-local).',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM },
      required: ['target'],
      additionalProperties: false,
    },
    handler: ({ target }) => sendRequest(target, { type: 'UNDO_COLORS' }),
  },
  {
    name: 'focus_node',
    description: 'Scroll/zoom to a node (Figma) or highlight an element (Chrome) by id/selector.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, nodeId: { type: 'string' } },
      required: ['nodeId'], additionalProperties: false,
    },
    handler: ({ target, nodeId }) => sendRequest(target, { type: 'FOCUS_NODE', nodeId }),
  },
  {
    name: 'scan_variables',
    description: 'Figma: list variables from the given design system library that are bound into the current file.',
    inputSchema: {
      type: 'object',
      properties: { system: SYSTEM_ENUM },
      required: ['system'], additionalProperties: false,
    },
    handler: ({ system }) => sendRequest('figma', { type: 'SCAN_VARIABLES', system }),
  },
  {
    name: 'start_inspect',
    description: 'Chrome only: enter element-picker mode so the next click on the page becomes the inspected target.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: () => sendRequest('chrome', { type: 'START_INSPECT' }),
  },
  {
    name: 'stop_inspect',
    description: 'Chrome only: exit element-picker mode.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: () => sendRequest('chrome', { type: 'STOP_INSPECT' }),
  },
  {
    name: 'select_page',
    description: 'Chrome only: set the scan scope to the whole page (<body>).',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: () => sendRequest('chrome', { type: 'SELECT_PAGE' }),
  },
  {
    name: 'polish_page',
    description: 'Chrome only: toggle page-level polish overlays (dark mode, scrollbars, positional hover).',
    inputSchema: {
      type: 'object',
      properties: {
        darkMode: { type: 'boolean' },
        scrollbars: { type: 'boolean' },
        positionalHover: { type: 'boolean' },
      },
      additionalProperties: false,
    },
    handler: async ({ darkMode, scrollbars, positionalHover }) => {
      const out = [];
      if (typeof darkMode === 'boolean') out.push(await sendRequest('chrome', { type: 'POLISH_DARK_MODE', enabled: darkMode }));
      if (typeof scrollbars === 'boolean') out.push(await sendRequest('chrome', { type: 'POLISH_SCROLLBARS', enabled: scrollbars }));
      if (typeof positionalHover === 'boolean') out.push(await sendRequest('chrome', { type: 'POLISH_POSITIONAL_HOVER', enabled: positionalHover }));
      return { applied: { darkMode, scrollbars, positionalHover }, responses: out };
    },
  },
  {
    name: 'a11y_overlay',
    description: 'Chrome only: toggle accessibility overlays (tap targets, non-token colors, colorblind simulation).',
    inputSchema: {
      type: 'object',
      properties: {
        tapTargets: { type: 'boolean' },
        nonTokenColors: { type: 'boolean' },
        system: SYSTEM_ENUM,
        colorblind: { type: 'string', enum: ['none', 'protanopia', 'deuteranopia', 'tritanopia'] },
      },
      additionalProperties: false,
    },
    handler: async ({ tapTargets, nonTokenColors, system, colorblind }) => {
      const out = [];
      if (typeof tapTargets === 'boolean') out.push(await sendRequest('chrome', { type: 'A11Y_OVERLAY_TAP_TARGETS', enabled: tapTargets }));
      if (typeof nonTokenColors === 'boolean') out.push(await sendRequest('chrome', { type: 'A11Y_OVERLAY_NON_TOKEN_COLORS', enabled: nonTokenColors, system: system || 'lyra' }));
      if (colorblind) out.push(await sendRequest('chrome', { type: 'A11Y_OVERLAY_COLORBLIND', mode: colorblind }));
      return { applied: { tapTargets, nonTokenColors, colorblind }, responses: out };
    },
  },
  {
    name: 'apply_css_overrides',
    description: 'Chrome only: inject (or clear) a stylesheet of selector → declarations onto the current page. Used by the artboard-to-page skill to push Figma-derived styling onto a live DOM. Rules accumulate across calls; pass clear:true to wipe and start fresh.',
    inputSchema: {
      type: 'object',
      properties: {
        rules: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              selector: { type: 'string' },
              declarations: {
                type: 'object',
                additionalProperties: { type: 'string' },
              },
            },
            required: ['selector', 'declarations'],
            additionalProperties: false,
          },
          default: [],
        },
        clear: { type: 'boolean', default: false },
      },
      additionalProperties: false,
    },
    handler: ({ rules = [], clear = false }) =>
      sendRequest('chrome', { type: 'APPLY_CSS_OVERRIDES', rules, clear }),
  },
  {
    name: 'clear_css_overrides',
    description: 'Chrome only: remove every rule previously injected by apply_css_overrides, leaving the page untouched by the skill.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: () => sendRequest('chrome', { type: 'CLEAR_CSS_OVERRIDES' }),
  },
  {
    name: 'apply_single_color',
    description: 'Apply one color to one fill/stroke on one node. Two lanes: pass tokenName to bind a design-system token (preferred), OR pass customHex (e.g. "#0a84ff") to write a raw off-token color for live-editing. Either way the plugin captures a per-row snapshot, so revert_single_color undoes it cleanly. Surgical alternative to convert_colors.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeId: { type: 'string' },
        property: { type: 'string', enum: ['fill', 'stroke'] },
        fillIndex: { type: 'number', default: 0 },
        tokenName: { type: 'string', description: 'Design-system token name (e.g. "lyra/base/color/blue/500"). Use "__custom__" with customHex for off-token live edits.' },
        customHex: { type: 'string', description: 'Raw hex like "#0a84ff" (3- or 6-digit, "#" optional). When set, the plugin skips the palette and writes this color, unbinding any prior variable. The row will surface as off-token after apply.' },
      },
      required: ['system', 'nodeId', 'property', 'tokenName'], additionalProperties: false,
    },
    handler: ({ target, system, nodeId, property, fillIndex = 0, tokenName, customHex }) =>
      sendRequest(target, { type: 'APPLY_SINGLE_COLOR', nodeId, property, fillIndex, tokenName, system, ...(customHex ? { customHex } : {}) }),
  },
  {
    name: 'apply_single_text',
    description: 'Apply one text-style token to one node, OR live-edit just the font size with customFontSize. Family-aware token matching means the suggested token only matches when the family also matches. Snapshot captured for revert_single_text.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeId: { type: 'string' },
        tokenName: { type: 'string', description: 'Typography token name (e.g. "sol/heading/md"). Use "__custom__" with customFontSize for off-token size-only edits.' },
        customFontSize: { type: 'number', description: 'Raw font size in px. When set, the plugin writes only font-size and leaves family/weight/line-height/letter-spacing as-is. Useful for "make this 18px" without changing the typeface.' },
      },
      required: ['system', 'nodeId', 'tokenName'], additionalProperties: false,
    },
    handler: ({ target, system, nodeId, tokenName, customFontSize }) =>
      sendRequest(target, { type: 'APPLY_SINGLE_TEXT', nodeId, tokenName, system, ...(typeof customFontSize === 'number' ? { customFontSize } : {}) }),
  },
  {
    name: 'apply_single_spacing',
    description: 'Bind one spacing token to one property on one node, OR live-edit a raw px value with customValue. property is a Figma field name (paddingTop / paddingBottom / paddingLeft / paddingRight / itemSpacing) for figma target, or a hyphenated CSS property (padding-top / gap / margin-top) for chrome target. Snapshot captured for revert_single_spacing.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeId: { type: 'string' },
        property: { type: 'string' },
        tokenName: { type: 'string', description: 'Spacing token name (e.g. "SOL/size/spacing/md"). Use "__custom__" with customValue for off-token raw values.' },
        customValue: { type: 'number', description: 'Raw spacing value in px. When set, unbinds any prior variable and writes this number. Row surfaces as off-token afterwards.' },
      },
      required: ['system', 'nodeId', 'property', 'tokenName'], additionalProperties: false,
    },
    handler: ({ target, system, nodeId, property, tokenName, customValue }) =>
      sendRequest(target, { type: 'APPLY_SINGLE_SPACING', nodeId, property, tokenName, system, ...(typeof customValue === 'number' ? { customValue } : {}) }),
  },
  {
    name: 'apply_single_radius',
    description: 'Bind one radius token to one corner on one node, OR live-edit a raw px value with customValue. property is "all" for unified corner radius, or "topLeft"/"topRight"/"bottomLeft"/"bottomRight" for a specific corner. The Figma plugin binds all four corners to the same variable for "all" since Figma rejects cornerRadius itself as a bindable field. Snapshot captured for revert_single_radius.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeId: { type: 'string' },
        property: { type: 'string', description: '"all" or "topLeft"/"topRight"/"bottomLeft"/"bottomRight"' },
        tokenName: { type: 'string', description: 'Radius token name. Use "__custom__" with customValue for off-token raw values.' },
        customValue: { type: 'number', description: 'Raw corner radius in px. When set, unbinds any prior variable and writes this number.' },
      },
      required: ['system', 'nodeId', 'property', 'tokenName'], additionalProperties: false,
    },
    handler: ({ target, system, nodeId, property, tokenName, customValue }) =>
      sendRequest(target, { type: 'APPLY_SINGLE_RADIUS', nodeId, property, tokenName, system, ...(typeof customValue === 'number' ? { customValue } : {}) }),
  },
  {
    name: 'revert_single_color',
    description: 'Undo one apply_single_color (token or custom hex) on a specific node/fill. Restores the exact paint that was there before — including a prior variable binding if one existed. Snapshot is in-memory and lives until the plugin reloads.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        nodeId: { type: 'string' },
        property: { type: 'string', enum: ['fill', 'stroke'] },
        fillIndex: { type: 'number', default: 0 },
      },
      required: ['nodeId', 'property'], additionalProperties: false,
    },
    handler: ({ target, nodeId, property, fillIndex = 0 }) =>
      sendRequest(target, { type: 'REVERT_SINGLE_COLOR', nodeId, property, fillIndex }),
  },
  {
    name: 'revert_single_text',
    description: 'Undo one apply_single_text (token or custom size) on a specific text node. Restores the exact font name, size, line height, letter spacing, and any prior textStyleId. In-memory snapshot, lives until plugin reload.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        nodeId: { type: 'string' },
      },
      required: ['nodeId'], additionalProperties: false,
    },
    handler: ({ target, nodeId }) =>
      sendRequest(target, { type: 'REVERT_SINGLE_TEXT', nodeId }),
  },
  {
    name: 'revert_single_spacing',
    description: 'Undo one apply_single_spacing on a specific node/property. Restores the prior numeric value AND re-binds any prior variable.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        nodeId: { type: 'string' },
        property: { type: 'string' },
      },
      required: ['nodeId', 'property'], additionalProperties: false,
    },
    handler: ({ target, nodeId, property }) =>
      sendRequest(target, { type: 'REVERT_SINGLE_SPACING', nodeId, property }),
  },
  {
    name: 'revert_single_radius',
    description: 'Undo one apply_single_radius on a specific node/corner. For property="all" it restores all four individual corner values + their prior bindings.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        nodeId: { type: 'string' },
        property: { type: 'string' },
      },
      required: ['nodeId', 'property'], additionalProperties: false,
    },
    handler: ({ target, nodeId, property }) =>
      sendRequest(target, { type: 'REVERT_SINGLE_RADIUS', nodeId, property }),
  },
  {
    name: 'convert_page_to_lyra',
    description: 'Chrome composite: audit the current page, apply colors/text/spacing/radius fixes, then re-audit and return a before/after delta with visual gauges.',
    inputSchema: {
      type: 'object',
      properties: {
        applyColors: { type: 'boolean', default: true },
        applyText: { type: 'boolean', default: true },
        applySpacing: { type: 'boolean', default: true },
        applyRadius: { type: 'boolean', default: true },
        applyA11y: { type: 'boolean', default: true },
        dryRun: { type: 'boolean', default: true },
      },
      additionalProperties: false,
    },
    handler: async (args) => {
      const t = 'chrome';
      const dryRun = args.dryRun !== false;
      const before = extractAuditReport(await sendRequest(t, { type: 'RUN_AUDIT_REPORT', system: 'lyra' }));
      if (dryRun) {
        return richResult(
          summarizeAudit(before, 'lyra', t) + '\n\n_(dry-run — nothing applied)_',
          { audit: before, applied: { colors: false, text: false, spacing: false, radius: false, a11y: false }, dryRun: true },
          gaugeSvg(before, 'lyra', t),
        );
      }
      const applied = await applyAuditFixes(t, before, 'lyra', {
        applyColors: args.applyColors !== false,
        applyText: args.applyText !== false,
        applySpacing: args.applySpacing !== false,
        applyRadius: args.applyRadius !== false,
        applyA11y: args.applyA11y !== false,
      });
      const after = extractAuditReport(await sendRequest(t, { type: 'RUN_AUDIT_REPORT', system: 'lyra' }));
      return richResult(summarizeDelta(before, after, 'lyra', t), { before, after, applied }, gaugeDeltaSvg(before, after, 'lyra', t));
    },
  },
  {
    name: 'call_plugin',
    description: 'Escape hatch: send any UIMessage directly to the plugin backend. Use this for operations not covered by a named tool.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        message: { type: 'object', description: 'A UIMessage object (see src/types.ts).', additionalProperties: true },
      },
      required: ['target', 'message'],
      additionalProperties: false,
    },
    handler: ({ target, message }) => sendRequest(target, message),
  },
  {
    name: 'lyra_compliance_report',
    description: 'Composite: run every audit against Lyra and return a single consolidated report.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM },
      required: ['target'],
      additionalProperties: false,
    },
    handler: async ({ target }) => {
      const t = resolveTarget(target);
      const msgs = await sendRequest(t, { type: 'RUN_AUDIT_REPORT', system: 'lyra' });
      const a11y = await sendRequest(t, { type: 'RUN_ACCESSIBILITY_SCAN' });
      const report = extractAuditReport(msgs);
      const clients = await buildClientsHeader();
      const body = summarizeAudit(report, 'lyra', t);
      const summary = clients ? `${clients}\n\n${body}` : body;
      return richResult(summary, { system: 'lyra', target: t, report, accessibility: a11y }, gaugeSvg(report, 'lyra', t));
    },
  },
  {
    name: 'migrate_to_lyra',
    description: 'Composite: audit in Lyra then optionally apply color / text / spacing fixes. Dry-run by default.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        applyColors: { type: 'boolean', default: false },
        applyText: { type: 'boolean', default: false },
        applySpacing: { type: 'boolean', default: false },
        applyRadius: { type: 'boolean', default: false },
        applyA11y: { type: 'boolean', default: false },
        dryRun: { type: 'boolean', default: true },
      },
      required: ['target'],
      additionalProperties: false,
    },
    handler: async ({ target, applyColors, applyText, applySpacing, applyRadius, applyA11y, dryRun = true }) => {
      const t = resolveTarget(target);
      const before = extractAuditReport(await sendRequest(t, { type: 'RUN_AUDIT_REPORT', system: 'lyra' }));
      const result = { target: t, before, applied: { colors: false, text: false, spacing: false, radius: false, a11y: false } };
      if (dryRun) {
        return richResult(summarizeAudit(before, 'lyra', t) + '\n\n_(dry-run — nothing applied)_', result, gaugeSvg(before, 'lyra', t));
      }
      result.applied = await applyAuditFixes(t, before, 'lyra', {
        applyColors: !!applyColors,
        applyText: !!applyText,
        applySpacing: !!applySpacing,
        applyRadius: !!applyRadius,
        applyA11y: !!applyA11y,
      });
      const after = extractAuditReport(await sendRequest(t, { type: 'RUN_AUDIT_REPORT', system: 'lyra' }));
      result.after = after;
      return richResult(summarizeDelta(before, after, 'lyra', t), result, gaugeDeltaSvg(before, after, 'lyra', t));
    },
  },
  {
    name: 'screenshot_page',
    description: 'Capture a visual of the current view. Chrome: screenshots the visible region of the active tab. Figma: exports the current selection as PNG (or the current page if nothing is selected). Returns an inline image so Claude can see what the user is looking at.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        format: { type: 'string', enum: ['png', 'jpeg'], default: 'png', description: 'Chrome only — Figma always returns PNG.' },
        maxWidth: { type: 'number', description: 'Figma only — caps the exported PNG width (default 1280).' },
      },
      required: ['target'],
      additionalProperties: false,
    },
    handler: async ({ target, format, maxWidth }) => {
      const t = resolveTarget(target);
      const msgs = await sendRequest(t, { type: 'CAPTURE_SCREENSHOT', format, maxWidth });
      const hit = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'SCREENSHOT_CAPTURED' && m.dataUrl) : null;
      if (!hit) {
        const err = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'ERROR') : null;
        throw new Error(err?.message || `No screenshot returned by ${t}.`);
      }
      return { __image: true, dataUrl: hit.dataUrl, mimeType: hit.mimeType || 'image/png', target: t, source: hit.source };
    },
  },
];

function extractItems(responseMsgs, type) {
  if (!Array.isArray(responseMsgs)) return [];
  const hit = responseMsgs.find(m => m && m.type === type);
  return hit && Array.isArray(hit.items) ? hit.items : [];
}

// Mirror of src/ui/index.tsx handleAuditFixAll — keep parity so MCP and UI
// produce identical re-audit deltas.
const RADIUS_PROPS = new Set(['all', 'topLeft', 'topRight', 'bottomLeft', 'bottomRight']);
const AUTOFIXABLE_A11Y = new Set([
  'missing-aria-label', 'broken-aria-describedby', 'missing-alt',
  'missing-label', 'positive-tabindex', 'icon-button-no-title', 'focus-outline-removed',
]);

async function applyAuditFixes(target, before, system, opts) {
  const { applyColors, applyText, applySpacing, applyRadius, applyA11y } = opts;
  const applied = { colors: false, text: false, spacing: false, radius: false, a11y: false };

  if (applyColors && before?.colorIssues?.length) {
    const overrides = before.colorIssues
      .filter(i => i && i.suggestedToken)
      .map(i => ({ nodeId: i.nodeId, property: i.property, fillIndex: i.fillIndex, tokenName: i.suggestedToken }));
    if (overrides.length) {
      await sendRequest(target, { type: 'CONVERT_COLORS', system, overrides, skipPreview: true });
      applied.colors = true;
    }
  }
  if (applyText && before?.textIssues?.length) {
    const nodeIds = before.textIssues.map(i => i.nodeId);
    await sendRequest(target, { type: 'CONVERT_TEXT_STYLES', system, nodeIds, skipPreview: true });
    applied.text = true;
  }
  if (applySpacing && before?.spacingIssues?.length) {
    const nodeIds = before.spacingIssues.filter(i => !RADIUS_PROPS.has(i.property)).map(i => i.nodeId);
    if (nodeIds.length) {
      await sendRequest(target, { type: 'FIX_SPACING', system, nodeIds, skipPreview: true });
      applied.spacing = true;
    }
  }
  if (applyRadius && before?.spacingIssues?.length) {
    const nodeIds = before.spacingIssues.filter(i => RADIUS_PROPS.has(i.property)).map(i => i.nodeId);
    if (nodeIds.length) {
      await sendRequest(target, { type: 'FIX_RADIUS', system, nodeIds, skipPreview: true });
      applied.radius = true;
    }
  }
  if (applyA11y && before?.accessibilityIssues?.length) {
    const fixable = before.accessibilityIssues.filter(i => AUTOFIXABLE_A11Y.has(i.issueType));
    for (const i of fixable) {
      await sendRequest(target, { type: 'FIX_ACCESSIBILITY', nodeId: i.nodeId, issueType: i.issueType, skipPreview: true });
    }
    if (fixable.length) applied.a11y = true;
  }
  return applied;
}

// ─── MCP stdio server ─────────────────────────────────────────────────────────

async function main() {
  startHub();

  const server = new Server(
    {
      name: 'nice-designer-mcp',
      version: '0.5.0',
    },
    {
      capabilities: { tools: {} },
      instructions: [
        'This server bridges Claude to the NiCE Designer plugin running inside Figma (desktop plugin) and/or Chrome (extension).',
        '',
        'Workflow:',
        "1. Start with `list_targets` to see which clients are connected ('figma', 'chrome', or both). Every other tool accepts target='auto' and will pick the lone connected target for you. If it returns empty or tools fail with 'No target connected', call `get_diagnostics` — it shows whether the hub is up, whether you are on the primary or a proxy process, and what's likely wrong.",
        '2. Use audit_* / run_full_audit / lyra_compliance_report to read the current state before changing anything. They return an inline gauge summary plus the raw AuditReport.',
        '3. For mutations, every tool defaults to dryRun=true. Set dryRun=false only when the user has approved the change.',
        "4. Chrome-only page polish: polish_page toggles dark mode / scrollbars / positional hover overlays. a11y_overlay toggles tap-target highlighting, non-token color flagging, and colorblind simulation. Both work on any page the user has loaded — no need for the extension popup to be open.",
        '5. To migrate a whole Chrome page to Lyra use `convert_page_to_lyra`; for Figma frames use `migrate_to_lyra`. Both return a before/after delta with visual gauges. BEFORE running either, load the `lyra-visual-patterns` skill (skills/lyra-visual-patterns/SKILL.md) and ask the user whether they want a tokens-only pass (precision, keeps layout — best for demos and finished designs) or a full attempted conversion (broader — also normalizes layout/components — best for early mockups).',
        '6. Surgical fixes: apply_single_{color,text,spacing,radius} target a single node/property. Good for iterative cleanup after an audit. Each one captures a snapshot, so revert_single_{color,text,spacing,radius} undoes that one row cleanly.',
        '7. Live-edit lane: every apply_single_* tool also accepts a custom* field (customHex for color, customFontSize for text, customValue for spacing/radius) that bypasses the token palette and writes the raw value, unbinding any prior variable. The row will surface as off-token afterwards. Use this when the user wants to try a non-token value or asks for a specific px/hex.',
        '8. Token introspection: `export_design_tokens` returns every color/text/spacing/radius token in SOL or Lyra — use it to propose concrete values.',
        '9. Audit data shape: AuditReport now carries totalColorPaints / totalTextNodes / totalComponentNodes / totalVariableProps so you can show "X/Y" compliance ratios. Cross-system detection is authoritative (library variable key match), not just naming.',
        '',
        'Defaults: target=auto, system=lyra for compliance work. When unsure which target, always call list_targets first.',
        '',
        '─── Common user phrases (phrase routing) ───────────────────────────────────',
        "These are canonical flows the user expects. When a user's message matches (or paraphrases) one of these phrases, follow the numbered recipe exactly. Do not skip the AskUserQuestion step — the user relies on seeing those options before mutations run.",
        '',
        '• "Convert this page to Lyra" / "Make this Lyra" / "Lyra-ify this"',
        '  1. Call `run_full_audit` (target=auto, system=lyra). If the user has a specific element selected/inspected, audit that; otherwise audit the whole page.',
        '  2. Read the returned AuditReport `filters` field and call out which issue types are currently ignored by the user\'s toggles (e.g. mobile a11y issues hidden, contrast checks hidden). State this plainly so the user knows what the gauge does and does not cover.',
        '  3. Surface the audit to the user: post the inline gauge summary + a short prose read of the largest deltas.',
        '  4. AskUserQuestion: "How would you like to convert?" with options:',
        '       1. Just tokens (precision — best for demos and finished designs)',
        '       2. Full Lyra conversion (broader — best for early mockups and initial designs)',
        '  5. Run the audit page\'s Apply All path (call `convert_page_to_lyra` for Chrome or `migrate_to_lyra` for Figma) with dryRun=false once the user has answered.',
        "  6. If the user picked option 2, ALSO load the `lyra-visual-patterns` skill and attempt the remaining non-token conversions (layout, components, visual patterns) using its guidance — don't invent Lyra patterns from memory.",
        '',
        '• "Check this page for accessibility" / "Run a11y audit" / "Is this accessible?"',
        '  1. Call `audit_accessibility` (target=auto). If the user has a specific element selected/inspected, audit that; otherwise audit the whole page.',
        '  2. Report which filters are active (mobile-issue ignore, contrast-check hide) so the user can tell what was excluded from the score.',
        '  3. Surface the audit to the user inline.',
        '  4. AskUserQuestion: "Would you like to fix these issues?" with options:',
        '       1. Fix automatic issues (one-click fixes only)',
        '       2. Attempt all fixes including manual ones',
        '       3. No',
        '  5. If 3: stop. If 1 or 2: run the audit page\'s Apply All path (`fix_accessibility` with dryRun=false).',
        "  6. If the user picked option 2, after Apply All completes load the `lyra-visual-patterns` skill and use Lyra's a11y guidance to attempt fixes for issues that couldn't be auto-resolved (manual-judgement items like contrast trade-offs, copy rewrites, landmark structure).",
        '',
        '• "CSS for this Figma element" / "Export this to code" / "What\'s the CSS of this layer"',
        '  1. Call `list_targets`. If no `figma` session, stop and tell the user to open the plugin in Figma and enable the Claude MCP toggle.',
        '  2. Call `get_selection_info` with target=figma. If `hasSelection` is false, ask the user to select a Figma layer, then stop.',
        '  3. Load the `figma-element-css` skill (skills/figma-element-css/SKILL.md) for the extraction, token-substitution, and output-format rules. Follow it — do not hand-roll CSS from memory.',
        "  4. This flow is read-only. Never call mutation tools (convert_*, fix_*, apply_*) — the user is asking to export, not to change the design.",
        '',
        '• "Design specs of this element" / "What\'s the padding/color/typography of this" / "Spec out this component"',
        '  1. Call `list_targets`. If no `chrome` session, stop and tell the user to open the Chrome extension and enable the Claude MCP toggle.',
        '  2. Call `get_selection_info` with target=chrome. If `hasSelection` is false or nodeId==="body", ask the user to click 🔍 Inspect in the extension and pick an element, then stop. Do NOT auto-start inspect.',
        '  3. Load the `browser-element-specs` skill (skills/browser-element-specs/SKILL.md) and follow it for extraction (extract_dev_details + audit_* on the selection) and the two-column spec-sheet output.',
        "  4. This flow is read-only. Never call mutation tools, polish_page, or a11y_overlay — the user is asking to describe, not to change.",
        '',
        '• "What manual fixes are needed" / "What\'s left to get to 100%" / "What can\'t be auto-fixed"',
        '  1. Call `list_targets`. Pick the lone connected target; if both, ask which page/file to audit.',
        '  2. Call `get_selection_info` on that target. Scope to the current selection if one exists, otherwise full page/artboard. State the scope in the output.',
        '  3. Load the `manual-fixes-checklist` skill (skills/manual-fixes-checklist/SKILL.md) and follow it: baseline `run_full_audit`, disclose active filters, then dry-run the full auto-fixer (convert_page_to_lyra for chrome, migrate_to_lyra with every apply* for figma) and compute the remaining issues grouped by domain.',
        "  4. This flow stays dry-run. If the user then asks to apply, that's a separate 'Convert this page to Lyra' flow.",
        '',
        '• "Use this artboard to edit the page" / "Apply this Figma design to Chrome" / "Make the page look like this artboard"',
        '  1. Call `list_targets` — require BOTH `figma` AND `chrome`. If either is missing, tell the user which one to start, and stop.',
        '  2. Call `get_selection_info` on both targets. Require a frame/artboard on the Figma side; any Chrome selection (page or element) is fine and bounds the scope.',
        '  3. Load the `artboard-to-page` skill (skills/artboard-to-page/SKILL.md) and follow it for extraction, layer→selector mapping heuristics, preview rendering, user confirmation, and applying via `apply_css_overrides` (always with clear:true on the final call so re-runs replace instead of stack).',
        "  4. NEVER apply overrides without showing the mapping preview and asking for confirmation first. The user must approve the selector-to-declaration table before apply_css_overrides runs.",
        "  5. If mapping confidence is low (fewer than half the Figma layers mapped to a selector), stop and ask the user to clarify the mapping — don't silently drop layers.",
        '',
        '• "Does this page match the Figma" / "Compare the build to the design" / "Design-build parity check"',
        '  1. Call `list_targets` — require BOTH `figma` AND `chrome`. If either is missing, tell the user which to start, and stop.',
        '  2. Call `get_selection_info` on both. Figma side must be a frame/artboard; Chrome side can be page or element selection.',
        '  3. Load the `figma-chrome-parity` skill (skills/figma-chrome-parity/SKILL.md) and follow it: extract_dev_details on both sides in parallel, align layers by name, diff colors/typography/spacing/radius/shadow.',
        "  4. This flow is read-only. Never call convert_*, fix_*, apply_*, or polish_page. If the user asks to close the gap after seeing the report, route to the `artboard-to-page` flow.",
        '  5. If fewer than ~40% of Figma layers align to Chrome elements, stop and ask whether the right artboard/scope pair was selected — don\'t emit a noisy low-confidence report.',
        '',
        '• "Does this work in dark mode" / "Check dark/light parity" / "What breaks in dark mode"',
        '  1. Call `list_targets` — require `chrome`. Dark-mode simulation runs on live DOM; if only Figma is connected, say so and stop.',
        '  2. Call `get_selection_info` on chrome. Scope to the current selection if one exists, otherwise full page.',
        '  3. Load the `dark-mode-parity` skill (skills/dark-mode-parity/SKILL.md) and follow it: ensure a clean light baseline, audit_colors in light, polish_page({darkMode:true}), audit_colors in dark, then ALWAYS polish_page({darkMode:false}) to restore — even on error.',
        "  4. Only audit colors. Text/spacing/radius don't vary by mode; including them is noise.",
        '  5. Output only the "breaks only in dark" and "breaks only in light" deltas plus a coverage summary. Don\'t restate the full audit — that\'s covered by `audit_colors` on its own.',
        '',
        '• "Which custom values should become tokens" / "Find token candidates" / "What should we add to Lyra"',
        '  1. Call `list_targets`. Pick the lone connected target; if both, ask which page/file.',
        '  2. Call `get_selection_info`. Scope to the selection if one exists, otherwise full page/artboard.',
        '  3. Load the `token-candidates` skill (skills/token-candidates/SKILL.md) and follow it: run audit_colors + audit_text_styles + audit_spacing + audit_radius in parallel, filter to no-close-match issues, group by normalized raw value, rank by count, keep only count ≥ 3.',
        "  4. This flow is read-only. Never call convert_*, fix_*, or apply_*. The output is a list of values to promote upstream in Lyra — not things to fix locally.",
        '  5. Don\'t propose brand/product-prefixed token names (e.g. `bloomberg-blue`) — Lyra tokens are semantic. Suggest the role (`brand-primary`), not the appearance.',
        '',
        '• "Live-edit" requests: "Make this 18px" / "Try this color #0a84ff" / "Set this padding to 12" / "Make this radius 4"',
        '  1. Resolve the target node. If the user said "this" or "selected", call `get_selection_info` (target=auto). For Chrome, "this" usually means the inspected element; for Figma, the current selection.',
        '  2. Route to the matching apply_single_* with the custom field set:',
        '       - color   → apply_single_color  with customHex=\'#RRGGBB\' and tokenName=\'__custom__\'',
        '       - text    → apply_single_text   with customFontSize=<number> and tokenName=\'__custom__\'',
        '       - spacing → apply_single_spacing with customValue=<number> and tokenName=\'__custom__\'',
        '       - radius  → apply_single_radius with customValue=<number> and tokenName=\'__custom__\'',
        '  3. Tell the user the row is now off-token (expected) and that revert_single_* will put it back. Mention the value applied so they have a record.',
        "  4. Don't ask for confirmation on a single live-edit — the user already named the value. Do confirm before bulk live-edits (more than ~5 nodes).",
        '',
        '• "Change all <thing> to <X>" / "Make every button bold" / "Set every card to use 12px gap"',
        '  1. Chrome: this is the natural fit for `apply_css_overrides`. Build one rule with a CSS selector that matches "<thing>" and the declaration that sets "<X>". Always pass `clear:true` on the final call so re-runs replace instead of stack. Show the user the rule(s) before applying so they can correct the selector.',
        '  2. Figma: there is no CSS-selector equivalent. Audit the relevant category (audit_colors / audit_text_styles / audit_spacing / audit_radius), filter the items by name match against "<thing>" (case-insensitive substring on item.nodeName is a reasonable heuristic — confirm the filter with the user if more than ~5 nodes match), then loop apply_single_* with the appropriate token or custom value per node.',
        "  3. Bulk live-edits in Figma can be slow because each node round-trips. Surface progress (\"applied to N of M\") so the user isn't left wondering.",
        "  4. The revert lane is per-row, so a bulk apply produces N independent revert snapshots. If the user changes their mind, you'll need to call revert_single_* for each affected node — there is no bulk revert tool.",
        '',
        '• "Undo that" / "Revert that change" / "Put it back"',
        '  1. If the user just made one change in this conversation, call the matching revert_single_* with the same nodeId/property/fillIndex you used in the apply call. The plugin holds an in-memory snapshot keyed by that tuple.',
        '  2. If multiple changes were made and the user is ambiguous, ask which one. Snapshots are not visible to MCP, so you have to remember (or re-derive from your tool-call history) which nodes you touched.',
        "  3. Snapshots are wiped on plugin reload. If the user closed and reopened the plugin between apply and revert, the row's revert link is gone — tell them they'll need to manually undo via Figma's Cmd+Z or by re-applying the original token.",
        '  4. For a global undo of the most recent CONVERT_COLORS Apply All (not single applies), use `undo_last_conversion` instead.',
        '',
        '• "Select this <thing>" / "Click this element" / "Focus the <header/button/...>" (Chrome only)',
        '  1. Confirm target=chrome via `list_targets`. Inspecting in Figma works through the user picking the layer themselves; the MCP can\'t programmatically click in Figma.',
        '  2. If the user described a specific element ("the button in the top right"), build a CSS selector that targets it and pass it to a query. The MCP doesn\'t expose a "click and inspect" remote API; the closest is calling `apply_css_overrides` to highlight the candidate (e.g. add a temporary outline) or using the Chrome extension\'s Inspect mode (the user has to click 🔍 themselves).',
        "  3. If the user just wants the page-level scope reset, call `select_page`. That clears the inspected element and scopes audits back to the whole page.",
        '  4. To bring an existing node into focus in Figma after an audit, use `focus_node` with the nodeId — it scrolls and selects.',
        '',
        '• "Triage accessibility issues" / "Where do I start with a11y" / "Prioritize the a11y fixes"',
        '  1. Call `list_targets`. Pick the lone connected target; if both, ask.',
        '  2. Call `get_selection_info`. Scope to the selection if one exists, otherwise full page/artboard.',
        '  3. Load the `a11y-triage` skill (skills/a11y-triage/SKILL.md) and follow it: run audit_accessibility, score each issue by severity × reach × rule-class multiplier, group by rule, rank by impact.',
        "  4. Output is a ranked top-3–5 prose section plus a compact next-wave table — not a raw issue dump. The whole point is triage; full lists are what audit_accessibility already gives.",
        '  5. Never auto-apply fixes. If the user asks to fix after seeing the triage, that\'s a separate user-confirmed `fix_accessibility` call.',
        '',
        'General rules for these flows: always audit first, always disclose active filters, always ask before mutating, and always pass dryRun=false only after the user has chosen an option that implies mutation.',
      ].join('\n'),
    },
  );

  server.setRequestHandler(ListToolsRequestSchema, async () => ({
    tools: TOOLS.map(t => ({ name: t.name, description: t.description, inputSchema: t.inputSchema })),
  }));

  server.setRequestHandler(CallToolRequestSchema, async (req) => {
    const tool = TOOLS.find(t => t.name === req.params.name);
    if (!tool) {
      return { isError: true, content: [{ type: 'text', text: `Unknown tool: ${req.params.name}` }] };
    }
    try {
      const out = await tool.handler(req.params.arguments || {});
      // Rich tools return { __rich: true, summary, data } — surface the markdown
      // gauge as the first content block so it shows inline, then the JSON.
      if (out && typeof out === 'object' && out.__rich) {
        const blocks = [{ type: 'text', text: out.summary }];
        if (out.svg) {
          blocks.push({
            type: 'image',
            data: Buffer.from(out.svg, 'utf8').toString('base64'),
            mimeType: 'image/svg+xml',
          });
        }
        blocks.push({ type: 'text', text: '```json\n' + JSON.stringify(out.data, null, 2) + '\n```' });
        return { content: blocks };
      }
      if (out && typeof out === 'object' && out.__image) {
        // Strip the data: prefix so we can hand raw base64 to the MCP image block.
        const m = String(out.dataUrl || '').match(/^data:([^;,]+)(?:;base64)?,(.+)$/);
        const mimeType = (m && m[1]) || out.mimeType || 'image/png';
        const data = m ? m[2] : String(out.dataUrl || '');
        const note = `Captured ${out.source ? out.source + ' from ' : ''}${out.target}`;
        return { content: [
          { type: 'image', data, mimeType },
          { type: 'text', text: note },
        ] };
      }
      return { content: [{ type: 'text', text: JSON.stringify(out, null, 2) }] };
    } catch (e) {
      return { isError: true, content: [{ type: 'text', text: String(e && e.message || e) }] };
    }
  });

  const transport = new StdioServerTransport();
  await server.connect(transport);
  logErr('MCP stdio transport ready');
}

main().catch((e) => { logErr('fatal:', e); process.exit(1); });
