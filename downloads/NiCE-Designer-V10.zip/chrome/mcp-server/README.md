# nice-designer-mcp

Local MCP server that lets Claude drive the [NiCE Designer plugin](../..) — Figma + Chrome — to audit and convert pages against the SOL and Lyra design systems.

## Architecture

```
Claude (stdio MCP client)
        ↓
nice-designer-mcp   (this package, Node, stdio)
        ↓  ws://127.0.0.1:7331
Figma plugin UI    /    Chrome extension background SW
```

The MCP server hosts a local WebSocket hub. When the Figma plugin or the Chrome extension is loaded, it connects out to the hub and registers itself as a `figma` or `chrome` target. Tool calls are correlated via a server-generated request id; the plugin buffers all `PluginMessage` replies emitted in response and returns them in one envelope.

## Install & run

```bash
cd packages/mcp-server
npm install
npm start        # runs the stdio MCP server + ws hub on 127.0.0.1:7331
```

## Claude Code / Claude Desktop config

Add this to your MCP config (e.g. `~/.claude.json` or Claude Desktop's `claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "nice-designer": {
      "command": "node",
      "args": ["/absolute/path/to/nice-designer-plugin/packages/mcp-server/src/index.js"]
    }
  }
}
```

## Tool surface (summary)

Audit (read-only): `run_full_audit`, `audit_colors`, `audit_text_styles`, `audit_spacing`, `audit_radius`, `audit_components`, `audit_accessibility`.

Conversion (dry-run by default): `convert_colors`, `convert_text_styles`, `fix_spacing`, `fix_radius`, `convert_component`, `fix_accessibility`, `convert_mode`, `undo_last_conversion`.

Cross-system: `generate_multi_system` (SOL↔Lyra duplicate + convert).

Dev handoff: `extract_dev_details`, `extract_all_css`.

Introspection: `list_targets`, `get_selection_info`, `check_libraries`, `export_design_tokens`.

Composites: `lyra_compliance_report`, `migrate_to_lyra`.

Escape hatch: `call_plugin` — sends any raw `UIMessage` (see `src/types.ts`) to the plugin.

## Environment

- `NICE_MCP_WS_PORT` — override the WebSocket hub port (default `7331`).
