@echo off
REM Windows: double-click this file.
cd /d "%~dp0"
node install.js
echo.
pause
