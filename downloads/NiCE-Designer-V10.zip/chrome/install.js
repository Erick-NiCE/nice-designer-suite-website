#!/usr/bin/env node
'use strict';

// NiCE Designer — Chrome bundle installer
// Cross-platform: macOS, Windows, Linux. Any Chromium-based browser.
// Runs from inside the chrome/ folder it ships with:
//   chrome/
//     install.js     ← you are here
//     extension/
//     mcp-server/
//     skills/

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync, spawn } = require('child_process');

const ROOT = __dirname;
const MCP_DIR = path.join(ROOT, 'mcp-server');
const EXT_DIR = path.join(ROOT, 'extension');
const MCP_ENTRY = path.join(MCP_DIR, 'src', 'index.js');
const SERVER_NAME = 'nice-designer';

const ok = (...a) => console.log('  ✓', ...a);
const warn = (...a) => console.log('  ⚠', ...a);
const err = (...a) => console.error('  ✗', ...a);
function header(text) { console.log('\n' + text); console.log('─'.repeat(Math.max(text.length, 4))); }

// ─── Pre-flight ───────────────────────────────────────────────────────────────

function checkNode() {
  const major = parseInt(process.versions.node.split('.')[0], 10);
  if (major < 18) {
    err(`Node ${process.versions.node} detected — need Node 18 or newer.`);
    console.log('     Download: https://nodejs.org/');
    process.exit(1);
  }
  ok(`Node ${process.versions.node}`);
}

// ─── MCP deps ────────────────────────────────────────────────────────────────

function installMcpDeps() {
  header('Installing MCP server dependencies');
  if (!fs.existsSync(MCP_DIR)) {
    err(`mcp-server/ not found next to this script (${MCP_DIR})`);
    process.exit(1);
  }
  try {
    execSync('npm install --omit=dev --no-audit --no-fund', { cwd: MCP_DIR, stdio: 'inherit' });
    ok('Installed');
  } catch {
    err('npm install failed. Is Node/npm on your PATH?');
    process.exit(1);
  }
}

// ─── Claude config ───────────────────────────────────────────────────────────

function claudeDesktopConfigPath() {
  if (process.platform === 'darwin') {
    return path.join(os.homedir(), 'Library', 'Application Support', 'Claude', 'claude_desktop_config.json');
  }
  if (process.platform === 'win32') {
    const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
    return path.join(appData, 'Claude', 'claude_desktop_config.json');
  }
  const xdg = process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config');
  return path.join(xdg, 'Claude', 'claude_desktop_config.json');
}

function claudeCodeConfigPath() {
  return path.join(os.homedir(), '.claude.json');
}

function mergeClaudeConfig(label, configPath) {
  const entry = { command: 'node', args: [MCP_ENTRY] };
  const parentDir = path.dirname(configPath);
  if (!fs.existsSync(parentDir)) {
    warn(`${label}: ${parentDir} doesn't exist — skipping (client not installed)`);
    return;
  }

  let config = {};
  const existed = fs.existsSync(configPath);
  if (existed) {
    try {
      config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    } catch {
      err(`${label}: existing config isn't valid JSON. Skipped to avoid clobbering.`);
      console.log(`     Path: ${configPath}`);
      return;
    }
    const backup = `${configPath}.bak-${Date.now()}`;
    fs.copyFileSync(configPath, backup);
    console.log(`     Backup → ${path.basename(backup)}`);
  }

  if (!config.mcpServers || typeof config.mcpServers !== 'object') {
    config.mcpServers = {};
  }
  config.mcpServers[SERVER_NAME] = entry;

  fs.writeFileSync(configPath, JSON.stringify(config, null, 2) + '\n');
  ok(`${label}: ${existed ? 'updated' : 'created'} ${configPath}`);
}

function configureClaude() {
  header('Configuring Claude clients');
  mergeClaudeConfig('Claude Desktop', claudeDesktopConfigPath());
  mergeClaudeConfig('Claude Code', claudeCodeConfigPath());
}

// ─── Browser detection ───────────────────────────────────────────────────────

function detectBrowser() {
  if (process.platform === 'darwin') {
    const apps = [
      { name: 'Google Chrome',  app: 'Google Chrome',  url: 'chrome://extensions/' },
      { name: 'Arc',            app: 'Arc',            url: 'chrome://extensions/' },
      { name: 'Brave',          app: 'Brave Browser',  url: 'brave://extensions/' },
      { name: 'Microsoft Edge', app: 'Microsoft Edge', url: 'edge://extensions/' },
      { name: 'Vivaldi',        app: 'Vivaldi',        url: 'vivaldi://extensions/' },
      { name: 'Opera',          app: 'Opera',          url: 'opera://extensions/' },
    ];
    for (const b of apps) if (fs.existsSync(`/Applications/${b.app}.app`)) return b;
    return null;
  }
  if (process.platform === 'win32') {
    const pf = process.env['ProgramFiles'] || 'C:\\Program Files';
    const pf86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
    const local = process.env.LOCALAPPDATA || '';
    const candidates = [
      { name: 'Google Chrome',  exe: path.join(pf,   'Google', 'Chrome', 'Application', 'chrome.exe'),         url: 'chrome://extensions/' },
      { name: 'Google Chrome',  exe: path.join(pf86, 'Google', 'Chrome', 'Application', 'chrome.exe'),         url: 'chrome://extensions/' },
      { name: 'Microsoft Edge', exe: path.join(pf86, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),        url: 'edge://extensions/' },
      { name: 'Microsoft Edge', exe: path.join(pf,   'Microsoft', 'Edge', 'Application', 'msedge.exe'),        url: 'edge://extensions/' },
      { name: 'Brave',          exe: path.join(pf,   'BraveSoftware', 'Brave-Browser', 'Application', 'brave.exe'), url: 'brave://extensions/' },
      { name: 'Vivaldi',        exe: path.join(local,'Vivaldi', 'Application', 'vivaldi.exe'),                 url: 'vivaldi://extensions/' },
      { name: 'Opera',          exe: path.join(local,'Programs', 'Opera', 'opera.exe'),                        url: 'opera://extensions/' },
    ];
    for (const c of candidates) if (c.exe && fs.existsSync(c.exe)) return c;
    return null;
  }
  // linux
  const cmds = [
    { name: 'Google Chrome',  cmd: 'google-chrome',     url: 'chrome://extensions/' },
    { name: 'Chromium',       cmd: 'chromium',          url: 'chrome://extensions/' },
    { name: 'Chromium',       cmd: 'chromium-browser',  url: 'chrome://extensions/' },
    { name: 'Brave',          cmd: 'brave-browser',     url: 'brave://extensions/' },
    { name: 'Microsoft Edge', cmd: 'microsoft-edge',    url: 'edge://extensions/' },
    { name: 'Vivaldi',        cmd: 'vivaldi',           url: 'vivaldi://extensions/' },
  ];
  for (const c of cmds) {
    try { execSync(`command -v ${c.cmd}`, { stdio: 'ignore' }); return c; } catch { /* not found */ }
  }
  return null;
}

function openBrowser(browser) {
  try {
    if (process.platform === 'darwin') {
      spawn('open', ['-a', browser.app, browser.url], { stdio: 'ignore', detached: true }).unref();
    } else if (process.platform === 'win32') {
      spawn(browser.exe, [browser.url], { stdio: 'ignore', detached: true }).unref();
    } else {
      spawn(browser.cmd, [browser.url], { stdio: 'ignore', detached: true }).unref();
    }
    return true;
  } catch { return false; }
}

// ─── Clipboard (best-effort) ─────────────────────────────────────────────────

function copyToClipboard(text) {
  const tryCmd = (cmd, args = []) => {
    try {
      const p = spawn(cmd, args, { stdio: ['pipe', 'ignore', 'ignore'] });
      p.stdin.end(text);
      return true;
    } catch { return false; }
  };
  if (process.platform === 'darwin') return tryCmd('pbcopy');
  if (process.platform === 'win32') return tryCmd('clip');
  return tryCmd('xclip', ['-selection', 'clipboard']) || tryCmd('wl-copy');
}

// ─── Main ────────────────────────────────────────────────────────────────────

function main() {
  console.log('\n NiCE Designer — Chrome bundle installer');
  console.log('════════════════════════════════════════');

  checkNode();
  installMcpDeps();
  configureClaude();

  header('Loading the Chrome extension');
  if (!fs.existsSync(EXT_DIR)) {
    err(`extension/ not found next to this script (${EXT_DIR})`);
    process.exit(1);
  }

  console.log(`     Extension path:\n     ${EXT_DIR}`);
  if (copyToClipboard(EXT_DIR)) console.log('     (copied to clipboard)');

  const browser = detectBrowser();
  if (browser) {
    console.log(`     Detected browser: ${browser.name}`);
    if (openBrowser(browser)) {
      ok(`Opened ${browser.url}`);
      console.log('     In the page that just opened:');
      console.log('       1. Enable "Developer mode" (top right)');
      console.log('       2. Click "Load unpacked"');
      console.log('       3. Paste the path above and confirm');
    } else {
      warn(`Couldn't launch ${browser.name}. Open it and visit ${browser.url} manually.`);
    }
  } else {
    warn('No Chromium browser detected. Open Chrome / Edge / Brave / etc. and visit chrome://extensions/');
  }

  console.log('\n Done. Two things left:');
  console.log('   • Restart Claude Desktop / Claude Code so it picks up the new MCP server');
  console.log('   • Open the extension popup → Settings → toggle "Connect to Claude MCP" on\n');
}

main();
