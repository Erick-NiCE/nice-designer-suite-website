#!/bin/sh
# Linux: run from terminal — `./install.sh`
cd "$(dirname "$0")"
node install.js
