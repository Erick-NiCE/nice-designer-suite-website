#!/usr/bin/env node
// ─── nice-designer-mcp ────────────────────────────────────────────────────────
// Local MCP server that fronts the NiCE Designer Suite plugin over a WebSocket hub.
// Claude connects via stdio (standard MCP transport); the Figma UI and/or the
// Chrome extension background service worker connect out to ws://127.0.0.1:7331
// and register as 'figma' or 'chrome' targets.  Tool calls are correlated by
// a server-generated request id and a response envelope.
//
// See packages/mcp-server/README.md for setup.

'use strict';

const path = require('path');
const fs = require('fs');
const os = require('os');
const { execFileSync } = require('child_process');
const { WebSocketServer } = require('ws');
const analytics = require('./analytics');
const { randomUUID } = require('crypto');

// Two layouts are supported:
//   dev:  .../nice-designer-plugin/packages/mcp-server/src/index.js → REPO_ROOT = nice-designer-plugin/
//   dist: .../chrome/mcp-server/src/index.js                        → REPO_ROOT = chrome/
const REPO_ROOT = path.basename(path.resolve(__dirname, '..', '..')) === 'packages'
  ? path.resolve(__dirname, '..', '..', '..')
  : path.resolve(__dirname, '..', '..');

// ─── Self-update (git-based) ───────────────────────────────────────────────────
// Only a dev-layout checkout (REPO_ROOT has a .git) can self-update — a
// packaged/zipped dist build has no git history to pull from and no
// self-update path today. Never force-pushes, never resets: a fast-forward
// merge only, and it refuses outright if the working tree is dirty, so a
// developer's in-progress edits are never silently discarded.
const IS_GIT_CHECKOUT = fs.existsSync(path.join(REPO_ROOT, '.git'));
let updateInProgress = false;

// This server's OWN version — sent in hello_ack so the Figma/Chrome UI can
// tell whether the .mcpb a person has installed is the one this build of
// the plugin actually ships with, without needing a git checkout or any
// update-check machinery. Read straight from package.json rather than
// duplicating the string, since the release checklist already keeps this
// file's version in sync with the plugin build in the same commit.
let MCP_SERVER_VERSION = null;
try { MCP_SERVER_VERSION = require('../package.json').version || null; } catch { /* leave null */ }

// A copy of the installable .mcpb only exists next to a RUNNING server in
// two layouts — both are a person running this server themselves, straight
// off disk, rather than through Claude Desktop's own extension manager:
//   dev:  git checkout, built by `npm run build:mcpb`          → packages/mcp-server/Click to install Claude Connector.mcpb
//   dist: the unpacked "NiCE Designer Chrome" folder            → <that folder>/Click to install Claude Connector.mcpb
// A server Desktop actually installed and is spawning itself runs from
// Desktop's own extension-storage directory, which has neither file next to
// it — findReinstallableMcpb() correctly returns null there, since there is
// genuinely nothing on disk for this process to relaunch.
function findReinstallableMcpb() {
  const candidates = [
    path.join(REPO_ROOT, 'packages', 'mcp-server', 'Click to install Claude Connector.mcpb'),
    path.join(REPO_ROOT, 'Click to install Claude Connector.mcpb'),
  ];
  return candidates.find(p => fs.existsSync(p)) || null;
}

// Best-effort "double-click this file" via the OS's own default-app handler
// — the same action a person takes manually, just without having to go find
// the file themselves. This does NOT install anything by itself: opening a
// .mcpb this way hands off to Claude Desktop, which still shows its own
// install/update confirmation dialog that only the person can accept.
function openWithOsHandler(filePath) {
  if (process.platform === 'darwin') execFileSync('open', [filePath]);
  else if (process.platform === 'win32') execFileSync('cmd', ['/c', 'start', '', filePath]);
  else execFileSync('xdg-open', [filePath]);
}

function runGit(args) {
  return execFileSync('git', args, { cwd: REPO_ROOT, encoding: 'utf8', timeout: 30_000 }).trim();
}

function readJsonVersion(relPath, ref) {
  try {
    const text = ref ? runGit(['show', `${ref}:${relPath}`]) : fs.readFileSync(path.join(REPO_ROOT, relPath), 'utf8');
    return JSON.parse(text).version || null;
  } catch { return null; }
}

// Read-only status check shared by both check_for_updates and install_update
// (the latter re-checks immediately before acting so a stale dry-run can
// never be blindly trusted for the real thing).
function getUpdateStatus() {
  if (!IS_GIT_CHECKOUT) {
    return {
      updateCheckSupported: false,
      reason: 'This install is not a git checkout (looks like a packaged/dist build) — self-update is only available when running the MCP server from a git clone of the repo.',
    };
  }
  const branch = runGit(['rev-parse', '--abbrev-ref', 'HEAD']);
  runGit(['fetch', 'origin', '--quiet']);
  const localSha = runGit(['rev-parse', 'HEAD']);
  let remoteSha;
  try { remoteSha = runGit(['rev-parse', `origin/${branch}`]); }
  catch { return { updateCheckSupported: false, reason: `No origin/${branch} to compare against.` }; }
  const hasLocalChanges = runGit(['status', '--porcelain']).length > 0;
  const updateAvailable = localSha !== remoteSha;
  const commitsBehind = updateAvailable
    ? Number(runGit(['rev-list', '--count', `${localSha}..${remoteSha}`]))
    : 0;
  const commitSummaries = updateAvailable
    ? runGit(['log', '--oneline', `${localSha}..${remoteSha}`]).split('\n').filter(Boolean).slice(0, 20)
    : [];
  return {
    updateCheckSupported: true,
    branch,
    updateAvailable,
    hasLocalChanges,
    commitsBehind,
    commitSummaries,
    currentCommit: localSha.slice(0, 10),
    remoteCommit: remoteSha.slice(0, 10),
    currentVersion: readJsonVersion('packages/mcp-server/package.json'),
    remoteVersion: readJsonVersion('packages/mcp-server/package.json', `origin/${branch}`),
  };
}

// ─── Skills ─────────────────────────────────────────────────────────────────
// `get_skill` ships real skill content over MCP so a connected Claude session
// never needs its own filesystem access to this repo — Supercharge is meant
// to work the moment the toggle is on, with nothing extra to install. Three
// layouts can hold the real files; check in priority order:
//   1. packages/mcp-server/skills — copied in at build time (`npm run
//      sync:skills`, wired into build:mcpb) so the shipped .mcpb is
//      fully self-contained.
//   2. REPO_ROOT/skills — a dev git checkout (`npm start` without ever
//      running sync:skills), or the dist Chrome bundle where skills/ and
//      mcp-server/ land as siblings under builds/NiCE Designer Chrome/.
const SKILLS_DIR_CANDIDATES = [
  path.join(__dirname, '..', 'skills'),
  path.join(REPO_ROOT, 'skills'),
];
const SKILLS_DIR = SKILLS_DIR_CANDIDATES.find(d => fs.existsSync(d)) || SKILLS_DIR_CANDIDATES[0];

// The bundled Lynn design-system package, same lookup order as skills: copied
// next to the server at build time, else the repo's vendor/ folder, else the
// Chrome build's sibling folder.
const LYNN_DIR_CANDIDATES = [
  path.join(__dirname, '..', 'lynn-ui'),
  path.join(REPO_ROOT, 'vendor', 'lynn-ui'),
  path.join(REPO_ROOT, 'lynn-ui'),
];

function skillDir(id) {
  return path.join(SKILLS_DIR, id);
}

// Every file in a skill's folder besides SKILL.md itself — reference docs a
// skill can tell Claude to fetch on demand (e.g. nice-product-knowledge's
// per-product write-ups) without dumping all of them into one response.
function listSkillExtraFiles(id) {
  const out = [];
  function walk(rel) {
    let entries;
    try { entries = fs.readdirSync(path.join(skillDir(id), rel), { withFileTypes: true }); }
    catch { return; }
    for (const entry of entries) {
      if (entry.name.startsWith('.')) continue;
      const relPath = rel ? `${rel}/${entry.name}` : entry.name;
      if (entry.isDirectory()) walk(relPath);
      else if (relPath !== 'SKILL.md') out.push(relPath);
    }
  }
  walk('');
  return out;
}

// A skill id has to double as both a URL path segment and a filesystem path
// segment below — restrict it to the same slug shape every skill directory
// already uses, so it can never be used for traversal (`..`, absolute paths).
const SKILL_ID_RE = /^[a-z0-9][a-z0-9-]*$/;

// Skills refresh over the network on every call, ahead of the copy bundled
// in this server — the whole point is that editing or adding a skill (see
// scripts/publish-skills.mjs) reaches every already-installed connector with
// no reinstall. The bundled copy is the offline/unreachable fallback, and a
// short timeout keeps a dead network from ever stalling a tool call.
const SKILLS_REMOTE_BASE = 'https://erick-nice.github.io/nice-designer-suite-website/skills';
const SKILLS_REMOTE_TIMEOUT_MS = 3000;
// Trust note: this server executes whatever markdown skill files say to do —
// remote-first means push access to that site is equivalent to shipping
// code to every connected Claude session. Treat it accordingly.

async function fetchRemoteText(url) {
  if (typeof fetch !== 'function') return null; // ancient Node with no global fetch
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), SKILLS_REMOTE_TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    return res.ok ? await res.text() : null;
  } catch {
    return null; // offline, DNS failure, timeout, 404 — all just "fall back"
  } finally {
    clearTimeout(timer);
  }
}

async function fetchRemoteJson(url) {
  const text = await fetchRemoteText(url);
  if (text == null) return null;
  try { return JSON.parse(text); } catch { return null; }
}

// The hosted copy only wins when it is NEWER than the skills bundled in this
// connector. Without that check an old hosted copy shadowed freshly bundled
// skills (a release's updated lyra-prototyping lost to last month's text).
// A dev checkout has no bundle stamp, so its working tree always wins.
let remoteFreshCache = null; // { at, value }
async function remoteIsFresher() {
  const now = Date.now();
  if (remoteFreshCache && now - remoteFreshCache.at < SKILLS_CATALOG_CACHE_MS) return remoteFreshCache.value;
  let value = false;
  try {
    const local = JSON.parse(fs.readFileSync(path.join(SKILLS_DIR, 'bundle-stamp.json'), 'utf8'));
    const remote = await fetchRemoteJson(`${SKILLS_REMOTE_BASE}/bundle-stamp.json`);
    value = !!(remote && typeof remote.builtAt === 'number' && remote.builtAt > local.builtAt);
  } catch { value = false; }
  remoteFreshCache = { at: now, value };
  return value;
}

// Short in-process cache so a skill flow that calls get_skill a few times in
// a row (e.g. ux-eval loading itself, then north-star-fox) doesn't re-fetch
// catalog.json on every single call.
let skillsCatalogCache = null; // { at, value }
const SKILLS_CATALOG_CACHE_MS = 60_000;

async function getSkillsCatalog() {
  const now = Date.now();
  if (skillsCatalogCache && (now - skillsCatalogCache.at) < SKILLS_CATALOG_CACHE_MS) {
    return skillsCatalogCache.value;
  }
  const remote = (await remoteIsFresher()) ? await fetchRemoteJson(`${SKILLS_REMOTE_BASE}/catalog.json`) : null;
  const value = Array.isArray(remote) && remote.every(s => s && typeof s.id === 'string')
    ? { skills: remote, source: 'live' }
    : {
      skills: CATALOG.SKILLS.map(s => ({
        id: s.id,
        title: s.title,
        question: s.question,
        what: s.what,
        benefit: s.benefit,
        clients: s.clients,
        tools: s.tools,
        author: s.author || CATALOG.DEFAULT_AUTHOR,
        thirdParty: !!s.thirdParty,
        files: listSkillExtraFiles(s.id),
      })),
      source: 'bundled',
    };
  skillsCatalogCache = { at: now, value };
  return value;
}

// Keyword scoring shared by find_capability's tool-side and skill-side
// searches. Whole-phrase substring hits count double a term-by-term hit so
// "dark mode" ranks "Dark-mode parity" above something that only matches on
// "mode" alone. Weighted per field so a title/name hit outranks a mention
// buried in a benefit line.
function scoreCatalogMatch(query, weightedFields) {
  const q = String(query || '').toLowerCase().trim();
  if (!q) return 0;
  const terms = q.split(/\s+/).filter(Boolean);
  let score = 0;
  for (const [text, weight] of weightedFields) {
    if (!text) continue;
    const lower = String(text).toLowerCase();
    if (lower.includes(q)) score += weight * 2;
    for (const term of terms) {
      if (lower.includes(term)) score += weight;
    }
  }
  return score;
}

const { Server } = require('@modelcontextprotocol/sdk/server/index.js');
const { StdioServerTransport } = require('@modelcontextprotocol/sdk/server/stdio.js');
const {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} = require('@modelcontextprotocol/sdk/types.js');
// Presentation layer for the tool surface: human titles, groups, the benefit
// line, and the clarifying question to ask before mutating. See catalog.js.
const CATALOG = require('./catalog.js');
const designReview = require('./design-review.js');

// ─── Config ───────────────────────────────────────────────────────────────────

const WS_PORT = Number(process.env.NICE_MCP_WS_PORT) || 7331;
const REQUEST_TIMEOUT_MS = 30_000;
const HEARTBEAT_MS = 15_000;
const SESSION_STALE_MS = 45_000; // 3 missed heartbeats
const PROXY_REQUEST_TIMEOUT_MS = 35_000;
const { WebSocket } = require('ws');

// ─── Mode: primary hub vs proxy client ────────────────────────────────────────
// Only one nice-designer-mcp process can bind port 7331. That one is "primary"
// and owns the WebSocket hub the plugin connects to. Any additional
// nice-designer-mcp processes (Claude Desktop often spawns several — one per
// window / project) become "proxy" processes: they open a WS client to the
// primary and forward every tool call over it. Without this, only one Claude
// process sees sessions and the others silently return "No targets".

const MODE = { kind: 'starting', startedAt: Date.now(), pid: process.pid };
let proxyWs = null;                              // set when MODE.kind === 'proxy'
let proxyReconnectTimer = null;
const proxyPending = new Map();                  // reqId → {resolve, reject, timer}
let cachedProxySessions = [];                    // last-known targets from primary
let cachedProxyHubInfo = null;                   // {pid, port, startedAt, isPrimary:true}

// ─── WebSocket hub ────────────────────────────────────────────────────────────
// Each connecting plugin registers via `{kind:'hello', target, label}`. We keep
// at most one active session per target. Heartbeats drop stale sessions so
// list_targets never reports a ghost.

/** @type {Map<string, {ws: import('ws').WebSocket, target: 'figma'|'chrome', label: string, connectedAt: number, lastSeen: number}>} */
const sessions = new Map();
/** @type {Map<string, {resolve: (msgs: any[]) => void, reject: (e: Error) => void, timer: NodeJS.Timeout}>} */
const pending = new Map();
/** @type {Set<import('ws').WebSocket>} */
const proxyClients = new Set();                  // other MCP processes talking to us
const recentDisconnects = [];                    // last 10 drop events

function logErr(...args) { console.error('[nice-designer-mcp]', ...args); }

function recordDisconnect(entry) {
  recentDisconnects.push({ ...entry, at: Date.now() });
  if (recentDisconnects.length > 10) recentDisconnects.shift();
}

// Newest connection wins. Two instances of the same client can be connected at
// once (a second Chrome profile, or an old unpacked copy of the extension that
// was never reloaded). Taking the first one in insertion order routed every
// request to the OLDEST instance, so a freshly reloaded extension was ignored
// and results came from stale code.
function pickSession(target) {
  let best = null;
  for (const s of sessions.values()) {
    if (s.target !== target) continue;
    if (!best || (s.connectedAt ?? 0) >= (best.connectedAt ?? 0)) best = s;
  }
  return best;
}

function listLocalSessions() {
  const out = [];
  for (const [id, s] of sessions.entries()) {
    out.push({
      sessionId: id, target: s.target, label: s.label,
      connectedAt: s.connectedAt, lastSeen: s.lastSeen,
    });
  }
  return out;
}

function hubInfo() {
  return {
    pid: process.pid,
    port: WS_PORT,
    startedAt: MODE.startedAt,
    isPrimary: MODE.kind === 'primary',
    mode: MODE.kind,
    version: MCP_SERVER_VERSION,
  };
}

// Resolve target for tool calls. In primary mode, uses local sessions. In proxy
// mode, uses the last list pushed by the primary.
function resolveTarget(target) {
  if (target && target !== 'auto') return target;
  const pool = MODE.kind === 'primary'
    ? Array.from(new Set(Array.from(sessions.values()).map(s => s.target)))
    : Array.from(new Set(cachedProxySessions.map(s => s.target)));
  if (pool.length === 1) return pool[0];
  if (pool.length === 0) throw new Error("No plugin is connected. Install the Figma plugin or Chrome extension, turn the 'Connect to Claude MCP' toggle on, make sure Claude Desktop is running, and retry. Call get_diagnostics for details.");
  throw new Error("Multiple targets connected (figma + chrome). Pass target explicitly, or call list_targets first.");
}

// ─── sendRequest: primary = direct, proxy = forwarded ─────────────────────────

function sendRequestPrimary(target, message) {
  const session = pickSession(target);
  if (!session) {
    return Promise.reject(new Error(
      `No '${target}' plugin is connected. Open the NiCE Designer Suite ${target === 'figma' ? 'Figma plugin' : 'Chrome extension'} and retry. get_diagnostics shows who is currently connected.`
    ));
  }
  const id = randomUUID();
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(new Error(`Request ${id} (${message.type}) timed out after ${REQUEST_TIMEOUT_MS} ms`));
    }, REQUEST_TIMEOUT_MS);
    // Track the session id so we can reject this request immediately when the
    // plugin disconnects mid-flight, rather than making Claude wait the full
    // 30s timeout.
    pending.set(id, { resolve, reject, timer, sessionId: session.sid });
    try {
      session.ws.send(JSON.stringify({ kind: 'request', id, message }));
    } catch (e) {
      clearTimeout(timer);
      pending.delete(id);
      reject(e);
    }
  });
}

function sendRequestProxy(target, message) {
  if (!proxyWs || proxyWs.readyState !== 1) {
    return Promise.reject(new Error('Proxy MCP process cannot reach the primary hub. Try restarting Claude, or confirm no stale nice-designer-mcp processes are running.'));
  }
  const reqId = randomUUID();
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      proxyPending.delete(reqId);
      reject(new Error(`Proxy request ${reqId} (${message.type}) timed out after ${PROXY_REQUEST_TIMEOUT_MS} ms`));
    }, PROXY_REQUEST_TIMEOUT_MS);
    proxyPending.set(reqId, { resolve, reject, timer });
    try {
      proxyWs.send(JSON.stringify({ kind: 'proxy_request', reqId, target, message }));
    } catch (e) {
      clearTimeout(timer);
      proxyPending.delete(reqId);
      reject(e);
    }
  });
}

function sendRequest(target, message) {
  target = resolveTarget(target);
  if (target === 'figma' && message && message.system === 'lynn') {
    throw new Error("Lynn is a Chrome-only audit target (it is a React package styled by CSS variables, so a Figma file has no Lynn library to bind to). Use target 'chrome' against a page built with lynn-ui, or pick 'sol' or 'lyra' for Figma.");
  }
  if (MODE.kind === 'proxy') return sendRequestProxy(target, message);
  return sendRequestPrimary(target, message);
}

// ─── Primary hub ──────────────────────────────────────────────────────────────

function broadcastSessionsToProxies() {
  if (proxyClients.size === 0) return;
  const payload = JSON.stringify({
    kind: 'proxy_sessions',
    sessions: listLocalSessions(),
    hub: hubInfo(),
  });
  for (const pc of proxyClients) {
    try { pc.send(payload); } catch { /* proxy gone */ }
  }
}

function sweepStaleSessions() {
  const now = Date.now();
  let changed = false;
  for (const [sid, s] of sessions.entries()) {
    if (now - s.lastSeen > SESSION_STALE_MS) {
      logErr(`session ${sid.slice(0, 8)} (${s.target}) stale — dropping`);
      recordDisconnect({ sessionId: sid, target: s.target, reason: 'stale' });
      try { s.ws.close(); } catch { /* noop */ }
      sessions.delete(sid);
      changed = true;
    }
  }
  if (changed) broadcastSessionsToProxies();
}

function startPrimaryHub(wss) {
  MODE.kind = 'primary';
  logErr(`WebSocket hub listening on ws://127.0.0.1:${WS_PORT} (primary, pid=${process.pid})`);
  setInterval(sweepStaleSessions, 5_000).unref();

  wss.on('connection', (ws) => {
    const sid = randomUUID();
    let isProxy = false;

    ws.on('message', (raw) => {
      let data;
      try { data = JSON.parse(String(raw)); } catch { return; }
      if (!data || typeof data !== 'object') return;

      // Plugin hello
      if (data.kind === 'hello' && (data.target === 'figma' || data.target === 'chrome')) {
        sessions.set(sid, {
          sid,
          ws,
          target: data.target,
          label: String(data.label || ''),
          connectedAt: Date.now(),
          lastSeen: Date.now(),
        });
        logErr(`session ${sid.slice(0, 8)} registered as '${data.target}'${data.label ? ` (${data.label})` : ''}`);
        try {
          ws.send(JSON.stringify({ kind: 'hello_ack', repoRoot: REPO_ROOT, platform: process.platform, heartbeatMs: HEARTBEAT_MS, version: MCP_SERVER_VERSION }));
        } catch { /* socket closed mid-ack */ }
        broadcastSessionsToProxies();
        return;
      }

      // Proxy (other MCP process) hello
      if (data.kind === 'hello_proxy') {
        isProxy = true;
        proxyClients.add(ws);
        logErr(`proxy client attached (now ${proxyClients.size})`);
        try {
          ws.send(JSON.stringify({
            kind: 'proxy_sessions',
            sessions: listLocalSessions(),
            hub: hubInfo(),
          }));
        } catch { /* noop */ }
        return;
      }

      // Plugin telemetry relay (fire-and-forget, no ack).
      // Needs its own frame kind rather than riding the UIMessage channel:
      // that channel is strictly hub-driven request/response, and mcpClient
      // deliberately drops any unsolicited message arriving while no request
      // is in flight, so telemetry sent that way would vanish silently.
      if (data.kind === 'telemetry' && Array.isArray(data.batch)) {
        const s = sessions.get(sid);
        if (s) s.lastSeen = Date.now();
        const target = (s && s.target) || (data.target === 'figma' || data.target === 'chrome' ? data.target : undefined);
        const n = analytics.ingest(data.batch, target);
        // Acked so the client knows the batch is on disk and can drop it. A
        // client that never sees this keeps the batch and retries.
        try { ws.send(JSON.stringify({ kind: 'telemetry_ack', n, id: data.id || null })); } catch { /* noop */ }
        return;
      }

      // Plugin context push (fire-and-forget, no ack) — lets the Chrome
      // session tell the hub what it's actually looking at (e.g. "active tab
      // is figma.com") so resolveTarget('auto') can make a better call than
      // erroring on ambiguity when both figma + chrome are connected.
      if (data.kind === 'context' && data.ctx && typeof data.ctx === 'object') {
        const s = sessions.get(sid);
        if (s) { s.ctx = data.ctx; s.lastSeen = Date.now(); }
        return;
      }

      // Plugin heartbeat
      if (data.kind === 'ping') {
        const s = sessions.get(sid);
        if (s) s.lastSeen = Date.now();
        try { ws.send(JSON.stringify({ kind: 'pong', t: Date.now() })); } catch { /* noop */ }
        return;
      }

      // Plugin response to request
      if (data.kind === 'response' && typeof data.id === 'string') {
        const s = sessions.get(sid);
        if (s) s.lastSeen = Date.now();
        // Primary's own pending
        const p = pending.get(data.id);
        if (p) {
          clearTimeout(p.timer);
          pending.delete(data.id);
          p.resolve(Array.isArray(data.messages) ? data.messages : []);
          return;
        }
        // Response to a proxy_request we forwarded on behalf of a proxy
        const proxyReq = proxyResponseRouter.get(data.id);
        if (proxyReq) {
          proxyResponseRouter.delete(data.id);
          try {
            proxyReq.proxy.send(JSON.stringify({
              kind: 'proxy_response',
              reqId: proxyReq.reqId,
              ok: true,
              messages: Array.isArray(data.messages) ? data.messages : [],
            }));
          } catch { /* proxy gone */ }
        }
        return;
      }

      // Proxy forwarding a Claude tool call
      if (data.kind === 'proxy_request' && typeof data.reqId === 'string' && data.message) {
        const target = data.target;
        const session = pickSession(target);
        if (!session) {
          try {
            ws.send(JSON.stringify({
              kind: 'proxy_response', reqId: data.reqId, ok: false,
              error: `No '${target}' plugin is connected on primary hub.`,
            }));
          } catch { /* noop */ }
          return;
        }
        const id = randomUUID();
        proxyResponseRouter.set(id, { proxy: ws, reqId: data.reqId });
        // Safety timeout so router doesn't leak if plugin never replies
        setTimeout(() => {
          if (proxyResponseRouter.has(id)) {
            proxyResponseRouter.delete(id);
            try {
              ws.send(JSON.stringify({
                kind: 'proxy_response', reqId: data.reqId, ok: false,
                error: 'Upstream plugin response timed out on primary hub.',
              }));
            } catch { /* noop */ }
          }
        }, REQUEST_TIMEOUT_MS + 5_000).unref();
        try {
          session.ws.send(JSON.stringify({ kind: 'request', id, message: data.message }));
        } catch (e) {
          proxyResponseRouter.delete(id);
          try {
            ws.send(JSON.stringify({
              kind: 'proxy_response', reqId: data.reqId, ok: false,
              error: `Primary hub failed to forward to plugin: ${e.message}`,
            }));
          } catch { /* noop */ }
        }
        return;
      }

      // Proxy asking for a fresh sessions dump
      if (data.kind === 'proxy_list_sessions') {
        try {
          ws.send(JSON.stringify({
            kind: 'proxy_sessions',
            sessions: listLocalSessions(),
            hub: hubInfo(),
          }));
        } catch { /* noop */ }
        return;
      }
    });

    ws.on('close', () => {
      if (sessions.has(sid)) {
        const s = sessions.get(sid);
        logErr(`session ${sid.slice(0, 8)} (${s.target}) disconnected`);
        recordDisconnect({ sessionId: sid, target: s.target, reason: 'close' });
        sessions.delete(sid);
        // Reject any in-flight requests that were routed to this session so
        // the caller (Claude) gets an immediate error instead of waiting for
        // the 30s request timeout. Without this, every plugin crash freezes
        // the active tool call for the full timeout window.
        for (const [id, p] of pending.entries()) {
          if (p.sessionId === sid) {
            clearTimeout(p.timer);
            pending.delete(id);
            try { p.reject(new Error(`Plugin (${s.target}) disconnected before responding.`)); } catch { /* noop */ }
          }
        }
        broadcastSessionsToProxies();
      }
      if (isProxy) {
        proxyClients.delete(ws);
        logErr(`proxy client detached (now ${proxyClients.size})`);
      }
    });
    ws.on('error', (e) => logErr(`ws error on ${sid.slice(0, 8)}:`, e.message));
  });
  wss.on('error', (e) => logErr('hub error:', e.message));
}

// Maps the plugin-side request id (generated when primary forwards a
// proxy_request) back to the proxy ws and proxy-side reqId so responses can be
// routed home.
const proxyResponseRouter = new Map();

// ─── Proxy mode: connect to an already-running primary ───────────────────────

function connectProxy() {
  if (MODE.kind === 'starting') MODE.kind = 'proxy';
  try {
    proxyWs = new WebSocket(`ws://127.0.0.1:${WS_PORT}`);
  } catch (e) {
    logErr('proxy WebSocket construct failed:', e.message);
    scheduleProxyReconnect();
    return;
  }
  proxyWs.on('open', () => {
    logErr(`proxy connected to primary hub on :${WS_PORT}`);
    try { proxyWs.send(JSON.stringify({ kind: 'hello_proxy', pid: process.pid })); } catch { /* noop */ }
  });
  proxyWs.on('message', (raw) => {
    let data;
    try { data = JSON.parse(String(raw)); } catch { return; }
    if (!data || typeof data !== 'object') return;

    if (data.kind === 'proxy_sessions') {
      cachedProxySessions = Array.isArray(data.sessions) ? data.sessions : [];
      cachedProxyHubInfo = data.hub || null;
      return;
    }
    if (data.kind === 'proxy_response' && typeof data.reqId === 'string') {
      const p = proxyPending.get(data.reqId);
      if (!p) return;
      clearTimeout(p.timer);
      proxyPending.delete(data.reqId);
      if (data.ok) p.resolve(Array.isArray(data.messages) ? data.messages : []);
      else p.reject(new Error(String(data.error || 'proxy_response: primary reported failure')));
      return;
    }
  });
  proxyWs.on('close', () => {
    logErr('proxy WebSocket closed — will retry');
    proxyWs = null;
    // Fail any pending requests immediately with a clear error so Claude can retry
    for (const [, p] of proxyPending) {
      clearTimeout(p.timer);
      try { p.reject(new Error('Primary hub connection lost before response.')); } catch { /* noop */ }
    }
    proxyPending.clear();
    scheduleProxyReconnect();
  });
  proxyWs.on('error', (e) => logErr('proxy ws error:', e.message));
}

function scheduleProxyReconnect() {
  if (proxyReconnectTimer) return;
  proxyReconnectTimer = setTimeout(() => {
    proxyReconnectTimer = null;
    // Before reconnecting as proxy, try to re-bind in case primary died.
    tryBindOrProxy();
  }, 2_000).unref();
}

// ─── Startup: try to bind, fall back to proxy ────────────────────────────────

function tryBindOrProxy() {
  const wss = new WebSocketServer({ host: '127.0.0.1', port: WS_PORT });
  let decided = false;
  wss.on('listening', () => {
    decided = true;
    startPrimaryHub(wss);
  });
  wss.on('error', (err) => {
    if (decided) { logErr('hub error post-listen:', err.message); return; }
    decided = true;
    if (err && err.code === 'EADDRINUSE') {
      logErr(`port ${WS_PORT} already in use — starting in proxy mode`);
      connectProxy();
    } else {
      logErr('failed to bind hub:', err && err.message);
      // Retry shortly — might be a transient bind race
      setTimeout(tryBindOrProxy, 2_000).unref();
    }
  });
}

function startHub() { tryBindOrProxy(); }

// ─── Tool surface ─────────────────────────────────────────────────────────────
// Most tools pass a typed payload straight through as a UIMessage.  We also
// expose `call_plugin` as an escape hatch for the full ~35-operation surface
// without having to enumerate each one here, and two orchestration tools
// (`lyra_compliance_report`, `migrate_to_lyra`) that compose several calls.

const TARGET_ENUM = { type: 'string', enum: ['figma', 'chrome', 'auto'], description: "'auto' picks the single connected target — use list_targets first if both are connected." };
// 'lynn' is the Suite's own design system (lynn-ui). It has no Figma library to
// bind variables to, so it is honoured on target 'chrome' only; sendRequest
// turns a figma + lynn request into a plain explanation instead of a
// validation failure deep inside the plugin.
const SYSTEM_ENUM = { type: 'string', enum: ['sol', 'lyra', 'lynn'], description: "Design system to audit against. 'lynn' (the Suite's own lynn-ui system) works on target 'chrome' only and needs Beta features enabled in the extension's Settings." };

// ─── Helpers for inline summaries / gauges ────────────────────────────────────
// Mutation tools call an audit before+after and return a compact markdown gauge
// so Claude can surface the delta inline. Plain text works across every MCP
// client; no base64 images needed.

function resolveTarget(target) {
  if (target && target !== 'auto') return target;
  const targets = Array.from(new Set(Array.from(sessions.values()).map(s => s.target)));
  if (targets.length === 1) return targets[0];
  if (targets.length === 0) throw new Error("No plugin is connected. Install the Figma plugin or Chrome extension, turn the 'Connect to Claude MCP' toggle on, and retry.");
  // Both connected. If Chrome's active tab is a figma.com file, prefer the
  // real Figma plugin session — it has actual node/artboard data, while
  // Chrome on figma.com only sees the web app's own UI DOM, not the design
  // (which is why the panel blocks that domain outright).
  const chromeSession = Array.from(sessions.values()).find(s => s.target === 'chrome');
  if (chromeSession?.ctx?.isFigmaComActive) return 'figma';
  throw new Error("Multiple targets connected (figma + chrome). Pass target explicitly, or call list_targets first.");
}

function extractAuditReport(msgs) {
  if (!Array.isArray(msgs)) return null;
  const hit = msgs.find(m => m && m.type === 'AUDIT_REPORT' && m.report);
  return hit ? hit.report : null;
}

function gauge(score, width = 20) {
  const s = Math.max(0, Math.min(100, Math.round(Number(score) || 0)));
  const filled = Math.round((s / 100) * width);
  return `[${'█'.repeat(filled)}${'░'.repeat(width - filled)}] ${s}%`;
}

// Domains differ by target: Chrome DOM has no reusable components, so the
// Components row is hidden there.  Accessibility is only shown when the
// report actually contains a11y data.
function domainRows(report, target) {
  const rows = [
    ['Colors',      report.colorIssues?.length],
    ['Text styles', report.textIssues?.length],
    ['Spacing',     report.spacingIssues?.length],
  ];
  if (target !== 'chrome') {
    rows.push(['Components', report.componentIssues?.length]);
  }
  if (Array.isArray(report.accessibilityIssues)) {
    rows.push(['Accessibility', report.accessibilityIssues.length]);
  }
  return rows;
}

function summarizeAudit(report, system, target) {
  if (!report) return `No audit data returned from ${target}.`;
  const lines = [];
  lines.push(`### ${String(system || '').toUpperCase()} compliance — ${target}`);
  lines.push('');
  lines.push(`Overall  ${gauge(report.score)}`);
  if (Array.isArray(report.accessibilityIssues)) {
    lines.push(`A11y     ${gauge(report.accessibilityScore)}`);
  }
  lines.push('');
  lines.push(`| Domain | Issues |`);
  lines.push(`| --- | --- |`);
  for (const [name, count] of domainRows(report, target)) {
    lines.push(`| ${name} | ${count ?? 0} |`);
  }
  lines.push(`| Nodes scanned | ${report.totalNodes ?? 0} |`);
  // A token score is not a verdict on the design. Say what it does not cover,
  // every time, so a page that is hand-drawn or badly laid out cannot read as
  // "passed" just because its colors and spacing land on tokens.
  // The header decides whether a prototype looks presentable to the whole company. Say so first.
  const shell = report.appShell;
  if (shell) {
    lines.push('');
    if (!shell.header) lines.push('⚠ NO APP HEADER. Every Lyra prototype starts with the Lyra suite shell header (get_component_kit({ patterns: ["app-shell"] })). Without it the page reads as unfinished, whatever else scores well. Not done.');
    else lines.push(`App header: present${shell.fromPattern ? ' (NiCE Designer app-shell pattern)' : ' (not the NiCE Designer pattern: check it against the Lyra suite shell)'}${shell.leftNav ? ', navigation present' : ', no left navigation'}.`);
  }
  const cc = report.componentCoverage;
  if (cc) {
    lines.push('');
    const kinds = Object.entries(cc.handBuiltByKind || {}).slice(0, 5).map(([k, n]) => `${n} ${k}`).join(', ');
    if (!cc.verifiable) lines.push(`Components: ${cc.note}`);
    else {
      lines.push(`Components: ${cc.realUnits ?? cc.realComponents} REAL (NiCE Designer kit) · ${cc.fallbackUnits ?? cc.fallback ?? 0} fallback · ${cc.handBuiltUnits ?? cc.handBuilt} hand-built, labeled${kinds ? ` (unlabeled controls: ${kinds})` : ''}.`);
      if ((cc.realUnits ?? cc.realComponents) === 0 && cc.handBuilt > 0) lines.push(`⚠ NO real components found. This is not a ${String(system).toUpperCase()} build, whatever the score says. Rebuild it from get_component_kit.`);
      if (cc.unlabeledHandBuilt) lines.push(`⚠ ${cc.unlabeledHandBuilt} hand-built control(s) carry no data-nds-source label. Every element that is not a real component must be labeled data-nds-source="fallback" or "hand-built" so the user is told.`);
    }
  }
  const lh = report.layoutHealth;
  if (lh) {
    const bits = [];
    if (lh.truncatedText?.count) bits.push(`${lh.truncatedText.count} truncated text`);
    if (lh.tinyText?.count) bits.push(`${lh.tinyText.count} text under 11px`);
    if (lh.overlappingControls?.count) bits.push(`${lh.overlappingControls.count} overlapping controls`);
    if (lh.crampedText?.count) bits.push(`${lh.crampedText.count} cramped text (short labels wrapped onto 3+ lines)`);
    if (lh.placeholderText?.count) bits.push(`${lh.placeholderText.count} placeholder or sample text (lorem ipsum, Sample ...)`);
    if (lh.horizontalOverflow) bits.push('horizontal overflow');
    lines.push(lh.problems ? `⚠ Layout health: ${bits.join(', ')}.` : 'Layout health: no truncation, overlap or overflow found.');
  }
  lines.push('');
  lines.push('_The score covers colors, type, spacing, radius and accessibility only. It does not judge layout, hierarchy or whether real components are used. Look at the screenshot before calling anything passed._');
  return lines.join('\n');
}

// Collect currently-connected clients plus their current selection, so the
// audit output leads with "which target(s) am I looking at?".
async function buildClientsHeader() {
  const pool = MODE.kind === 'primary'
    ? listLocalSessions()
    : cachedProxySessions;
  const seen = new Set();
  const entries = [];
  for (const s of pool) {
    if (seen.has(s.target)) continue;
    seen.add(s.target);
    const label = await selectionLabel(s.target);
    const display = s.target === 'chrome' ? 'Chrome' : s.target === 'figma' ? 'Figma' : s.target;
    entries.push(`${display} "${label}"`);
  }
  if (entries.length === 0) return null;
  return `**Clients:** ${entries.join(', ')}`;
}

async function selectionLabel(target) {
  try {
    const msgs = await sendRequest(target, { type: 'GET_SELECTION_INFO' });
    const hit = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'SELECTION_INFO' && m.info) : null;
    if (hit?.info?.nodeName) return hit.info.nodeName;
  } catch { /* ignore — fall through to defaults */ }
  return target === 'chrome' ? 'Selected Page' : 'Selected Artboard';
}

function summarizeDelta(before, after, system, target) {
  if (!before || !after) return summarizeAudit(after || before, system, target);
  const d = (a, b) => `${a} → ${b} (${b - a >= 0 ? '+' : ''}${b - a})`;
  const lines = [];
  lines.push(`### ${String(system || '').toUpperCase()} delta — ${target}`);
  lines.push('');
  lines.push(`Overall  ${gauge(before.score)}  →  ${gauge(after.score)}`);
  lines.push(`A11y     ${gauge(before.accessibilityScore)}  →  ${gauge(after.accessibilityScore)}`);
  lines.push('');
  lines.push(`| Domain | Before → After |`);
  lines.push(`| --- | --- |`);
  lines.push(`| Colors | ${d(before.colorIssues?.length ?? 0, after.colorIssues?.length ?? 0)} |`);
  lines.push(`| Text styles | ${d(before.textIssues?.length ?? 0, after.textIssues?.length ?? 0)} |`);
  lines.push(`| Spacing | ${d(before.spacingIssues?.length ?? 0, after.spacingIssues?.length ?? 0)} |`);
  if (target !== 'chrome') {
    lines.push(`| Components | ${d(before.componentIssues?.length ?? 0, after.componentIssues?.length ?? 0)} |`);
  }
  if (Array.isArray(before.accessibilityIssues) || Array.isArray(after.accessibilityIssues)) {
    lines.push(`| A11y | ${d(before.accessibilityIssues?.length ?? 0, after.accessibilityIssues?.length ?? 0)} |`);
  }
  return lines.join('\n');
}

// Wrap a handler result so it returns both a markdown summary (for inline
// display) and the raw JSON (for Claude to reason over).  Optional `svg` is
// surfaced as an inline image content block — clients that render image/svg+xml
// (Claude Desktop) show the gauge visually; others fall back to the markdown.
// ─── Result size cap ──────────────────────────────────────────────────────────
// A whole-design audit can carry thousands of issue rows (one run produced a
// 3.5 MB payload), which overflows the client's tool-result limit and returns
// NOTHING usable. Every JSON result is compacted before it leaves the server:
//   • arrays longer than MAX_ITEMS keep their first MAX_ITEMS (default 40) entries, and the
//     parent gains `_omitted: { <key>: <how many were dropped> }` so a cut list
//     is never mistaken for a complete one;
//   • bulky palette/Storybook messages that ride along with replies are dropped;
//   • `raw` message echoes (a duplicate of the structured fields) are dropped.
// Scores and totals are computed upstream from the full data, so capping never
// changes a number. NICE_MCP_MAX_ITEMS overrides the limit (0 = no cap).
const MAX_ITEMS = (() => {
  const n = Number(process.env.NICE_MCP_MAX_ITEMS);
  return Number.isFinite(n) && n >= 0 && process.env.NICE_MCP_MAX_ITEMS !== undefined ? n : 40;
})();
const NOISY_MESSAGE_TYPES = new Set([
  'TOKEN_PALETTE', 'TEXT_TOKEN_PALETTE', 'SPACING_PALETTE', 'RADIUS_PALETTE',
  'STORYBOOK_COMPONENTS_RESULT', 'SYNC_STORYBOOK_DONE', 'SYNC_STORYBOOK_PROGRESS', 'STORYBOOK_SEED_EXPORT',
]);

function compactForClient(value, max = MAX_ITEMS, depth = 0) {
  if (!max || depth > 12 || value === null || typeof value !== 'object') return value;
  if (Array.isArray(value)) {
    const kept = value
      .filter(v => !(v && typeof v === 'object' && NOISY_MESSAGE_TYPES.has(v.type)))
      .map(v => compactForClient(v, max, depth + 1));
    return kept;
  }
  const out = {};
  const omitted = {};
  for (const [k, v] of Object.entries(value)) {
    if (k === 'raw') continue;
    if (Array.isArray(v)) {
      const clean = v.filter(x => !(x && typeof x === 'object' && NOISY_MESSAGE_TYPES.has(x.type)));
      if (clean.length > max) {
        omitted[k] = clean.length - max;
        out[k] = clean.slice(0, max).map(x => compactForClient(x, max, depth + 1));
        continue;
      }
    }
    out[k] = compactForClient(v, max, depth + 1);
  }
  if (Object.keys(omitted).length) out._omitted = omitted;
  return out;
}

function pageActionResult(msgs, action) {
  const err = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'ERROR') : null;
  if (err) throw new Error(err.message);
  const ok = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'SUCCESS') : null;
  if (!ok) throw new Error(`No ${action} result came back. The page may not be reachable: call list_tabs, then switch_tab, then retry.`);
  try { return JSON.parse(ok.message); } catch { return { message: ok.message }; }
}

// ─── Component kit CSS pruning ────────────────────────────────────────────────
// The kit's base.css carries every token (about 70 KB). A prototype built from
// a few components needs a fraction, so get_component_kit keeps only the custom
// properties the chosen CSS actually reaches, following var() chains through
// both the :root and the Lyra theme blocks.
function kitSplitRules(css) {
  const rules = [];
  let depth = 0, start = 0;
  for (let i = 0; i < css.length; i++) {
    if (css[i] === '{') depth++;
    else if (css[i] === '}') { depth--; if (depth === 0) { rules.push(css.slice(start, i + 1).trim()); start = i + 1; } }
  }
  return rules;
}
function kitDecls(body) {
  const out = [];
  let depth = 0, cur = '';
  for (const ch of body) {
    if (ch === '(') depth++;
    if (ch === ')') depth--;
    if (ch === ';' && depth === 0) { if (cur.trim()) out.push(cur.trim()); cur = ''; } else cur += ch;
  }
  if (cur.trim()) out.push(cur.trim());
  return out.map(d => { const i = d.indexOf(':'); return [d.slice(0, i).trim(), d.slice(i + 1).trim()]; }).filter(([k]) => k.startsWith('--'));
}
function kitMin(t) { return String(t).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\s*([{};,])\s*/g, '$1').replace(/:\s+/g, ':').replace(/\s+/g, ' ').trim(); }
// NiCE Designer's own page reset (not from the Storybook, which sets these on its
// own preview page): the Lyra face on the page and form controls inheriting it,
// so native inputs do not fall back to the browser's 13px Arial.
const KIT_RESET = 'html{font-family:"Lyra Sans",Inter,system-ui,sans-serif;-webkit-font-smoothing:antialiased}body{margin:0;color:var(--sol-color-text-default);background:var(--sol-color-background-surface-canvas)}button,input,select,textarea{font:inherit}';
function kitBuildCss(dir, needs, markup, extraCss = '') {
  const read = (rel) => { try { return fs.readFileSync(path.join(dir, rel), 'utf8').replace(/\/\*[\s\S]*?\*\//g, ''); } catch { return ''; } };
  const rootDecls = new Map(), themeDecls = new Map(), plain = [];
  for (const r of kitSplitRules(read('base.css'))) {
    const sel = r.slice(0, r.indexOf('{')).trim();
    const body = r.slice(r.indexOf('{') + 1, r.lastIndexOf('}'));
    if (sel === ':root') for (const [k, v] of kitDecls(body)) rootDecls.set(k, v);
    else if (sel === '[data-theme="lyra"]') for (const [k, v] of kitDecls(body)) themeDecls.set(k, v);
    else plain.push({ sel, r });
  }
  const used = new Set((markup.match(/(?:sol|heading|body)-[\w-]+/g) || []).concat(['sol-component', 'sol-screenreader-only']));
  const keptPlain = plain.filter(p => p.sel === '@font-face' || /^\.(heading|body)-/.test(p.sel) || (p.sel.match(/\.(?:sol|heading|body)-[\w-]+/g) || []).some(c => used.has(c.slice(1))));
  const componentCss = needs.map(n => read(`css/${n}.css`));
  const pool = KIT_RESET + '\n' + extraCss + '\n' + componentCss.join('\n') + '\n' + keptPlain.map(p => p.r).join('\n');
  const need = new Set();
  const queue = [...(pool.match(/--[\w-]+/g) || [])];
  while (queue.length) {
    const v = queue.pop();
    if (need.has(v)) continue;
    need.add(v);
    for (const d of [rootDecls.get(v), themeDecls.get(v)]) if (d) queue.push(...(d.match(/--[\w-]+/g) || []));
  }
  const root = [...rootDecls].filter(([k]) => need.has(k)).map(([k, v]) => `${k}:${v}`).join(';');
  const theme = [...themeDecls].filter(([k]) => need.has(k)).map(([k, v]) => `${k}:${v}`).join(';');
  return { tokens: kitMin(`:root{${root}}[data-theme="lyra"]{${theme}}${KIT_RESET}`), shared: kitMin(keptPlain.map(p => p.r).join('\n')), components: needs.map((n, i) => ({ name: n, css: kitMin(componentCss[i]) })).concat(extraCss ? [{ name: 'NiCE Designer fallback patterns', css: kitMin(extraCss) }] : []) };
}

function richResult(summary, data, svg) {
  return { __rich: true, summary, data, svg: svg || null };
}

// ─── Per-domain scoring ───────────────────────────────────────────────────────
// The full audit carries its own 0-100 score. The single-domain audits return a
// flat issue list, and inventing a denominator for them would be dishonest — we
// don't know how many *compliant* paints/nodes exist in scope. So instead of
// faking a compliance %, these report the one ratio we can compute exactly:
// how much of the pile is one click from being fixed.
//
//   auto-fixable  = an exact token match exists, or the value is bound to the
//                   other system's equivalent token (a mechanical re-bind)
//   needs a call  = only a near match exists — someone has to approve the shift
//   no match      = genuinely custom; a token-candidate, not a fix
const DOMAIN_SPECS = {
  colors:     { msg: 'COLOR_PREVIEW',           label: 'Colors',        unit: 'paints' },
  text:       { msg: 'TEXT_STYLE_PREVIEW',      label: 'Text styles',   unit: 'text nodes' },
  spacing:    { msg: 'SPACING_PREVIEW',         label: 'Spacing',       unit: 'properties' },
  radius:     { msg: 'RADIUS_PREVIEW',          label: 'Corner radius', unit: 'corners' },
  components: { msg: 'COMPONENT_AUDIT_RESULT',  label: 'Components',    unit: 'instances' },
  a11y:       { msg: 'ACCESSIBILITY_RESULT',    label: 'Accessibility', unit: 'issues' },
};

function extractItems(msgs, msgType) {
  if (!Array.isArray(msgs)) return [];
  // Progressive audits stream partial batches; the last one wins.
  const hits = msgs.filter(m => m && m.type === msgType && Array.isArray(m.items));
  if (!hits.length) return [];
  return hits[hits.length - 1].items;
}

// The buckets are a strict partition — every item lands in exactly one, so the
// counts always sum to `total`. Priority runs wrongSystem → exact → near →
// noMatch: a row bound to the other system's token is a mechanical re-bind
// whatever its raw value looks like, so that classification wins.
function classifyDomain(domain, items) {
  const out = { total: items.length, exact: 0, near: 0, wrongSystem: 0, noMatch: 0, errors: 0, warnings: 0 };
  for (const it of items) {
    if (domain === 'a11y') {
      if (it.severity === 'error') out.errors++; else out.warnings++;
      continue;
    }
    if (domain === 'components') {
      if (it.wrongLibrary) out.wrongSystem++;
      else if (it.suggestedReplacement) out.exact++;
      else out.noMatch++;
      continue;
    }
    // A suggestion exists when the audit named a token to move to. Colors carry
    // it as suggestedToken; spacing/radius as nearestToken.
    const hasSuggestion = domain === 'colors' ? !!it.suggestedToken : !!it.nearestToken;
    if (it.wrongSystem) out.wrongSystem++;
    else if (it.isExact) out.exact++;
    else if (hasSuggestion) out.near++;
    else out.noMatch++;
  }
  out.autoFixable = domain === 'a11y'
    ? items.filter(i => AUTOFIXABLE_A11Y.has(i.issueType)).length
    // Exact matches and wrong-system bindings are mechanical. Near matches move
    // the pixel value, so they need a human to approve the shift.
    : out.exact + out.wrongSystem;
  out.fixableScore = out.total === 0 ? 100 : Math.round((out.autoFixable / out.total) * 100);
  return out;
}

// Inline summary for a single-domain audit: the headline count, the
// one-click-fixable gauge, and the breakdown that explains it.
function summarizeDomain(domain, items, system, target, scopeLabel) {
  const spec = DOMAIN_SPECS[domain];
  const c = classifyDomain(domain, items);
  const lines = [];
  const sysLabel = domain === 'a11y' ? 'Accessibility' : `${String(system || '').toUpperCase()} ${spec.label.toLowerCase()}`;
  lines.push(`### ${sysLabel} — ${target}${scopeLabel ? ` · ${scopeLabel}` : ''}`);
  lines.push('');
  if (c.total === 0) {
    lines.push(`**No issues found.** Nothing in scope needs attention in this domain.`);
    return lines.join('\n');
  }
  lines.push(`**${c.total}** ${spec.unit} need attention.`);
  lines.push('');
  lines.push(`One-click fixable  ${gauge(c.fixableScore)}  (${c.autoFixable} of ${c.total})`);
  lines.push('');
  lines.push('| Bucket | Count | What it means |');
  lines.push('| --- | --- | --- |');
  if (domain === 'a11y') {
    lines.push(`| Errors | ${c.errors} | Genuine blockers — fix these first |`);
    lines.push(`| Warnings | ${c.warnings} | Polish, or needs a judgement call |`);
    lines.push(`| Auto-fixable | ${c.autoFixable} | The tool can remediate these outright |`);
    lines.push(`| Needs a human | ${c.total - c.autoFixable} | Contrast trade-offs, copy, structure |`);
  } else if (domain === 'components') {
    lines.push(`| Replacement known | ${c.exact} | A 1:1 system component exists |`);
    lines.push(`| Wrong library | ${c.wrongSystem} | From the other design system |`);
    lines.push(`| No match | ${c.noMatch} | Custom or detached — needs a design decision |`);
  } else {
    lines.push(`| Exact match | ${c.exact} | A token already holds this value — just bind it |`);
    lines.push(`| Wrong system | ${c.wrongSystem} | Bound to the other system's token — mechanical re-bind |`);
    lines.push(`| Near match | ${c.near} | Value would shift slightly; worth a look before applying |`);
    lines.push(`| No match | ${c.noMatch} | Genuinely custom — a token candidate, not a fix |`);
  }
  lines.push('');
  lines.push(c.autoFixable === c.total
    ? '_Every row here is mechanical — safe to apply in bulk._'
    : c.autoFixable === 0
      ? '_Nothing here is mechanical. Each row needs a decision, so go row by row._'
      : `_Applying in bulk clears ${c.autoFixable}; the remaining ${c.total - c.autoFixable} need a decision each._`);
  return lines.join('\n');
}

// Shared handler for the six single-domain audits: run the plugin's preview,
// then wrap it in a scored summary instead of returning a raw message array.
async function runDomainAudit(domain, target, system, request) {
  const spec = DOMAIN_SPECS[domain];
  const t = resolveTarget(target);
  const msgs = await sendRequest(t, request);
  const items = extractItems(msgs, spec.msg);
  const scope = await selectionLabel(t);
  return richResult(
    summarizeDomain(domain, items, system, t, scope),
    { target: t, system: system || null, domain, scope, stats: classifyDomain(domain, items), items, raw: msgs },
  );
}

// After a mutation lands, re-run the same domain audit and report how much of
// the original pile it actually cleared. Costs one extra preview and turns
// "done" into a number the user can check.
async function summarizeDomainFix(domain, target, system, previewMsg, apply) {
  const spec = DOMAIN_SPECS[domain];
  const t = resolveTarget(target);
  const beforeItems = extractItems(await sendRequest(t, previewMsg), spec.msg);
  const applyResult = await apply(t);
  const afterItems = extractItems(await sendRequest(t, previewMsg), spec.msg);
  const b = beforeItems.length;
  const a = afterItems.length;
  const resolved = Math.max(0, b - a);
  const pct = b === 0 ? 100 : Math.round((resolved / b) * 100);
  const lines = [];
  lines.push(`### ${spec.label} fixed — ${t}`);
  lines.push('');
  lines.push(`Resolved  ${gauge(pct)}  (${resolved} of ${b})`);
  lines.push('');
  lines.push(`| | Issues |`);
  lines.push(`| --- | --- |`);
  lines.push(`| Before | ${b} |`);
  lines.push(`| After | ${a} |`);
  if (a > 0) {
    const rest = classifyDomain(domain, afterItems);
    lines.push('');
    lines.push(`_${a} left: ${rest.autoFixable} still mechanical, ${a - rest.autoFixable} need a decision. ` +
      `Re-run the audit for the detail, or fix them one at a time._`);
  }
  return richResult(lines.join('\n'), {
    target: t, system: system || null, domain,
    before: b, after: a, resolved, resolvedPct: pct,
    remaining: afterItems, applyResult,
  });
}

// ─── UX Eval: 10-question prioritization framework ────────────────────────────
// This tool never computes the verdict itself — it only assembles the audit
// data, link/context inputs, and this framework, so Claude (guided by the
// `ux-eval` skill) can reason over it and state a pass/fail recommendation.
const UX_EVAL_QUESTIONS = [
  { n: 1, question: 'Who feels this pain, and how many of them are there?', prompt: 'Is this a problem for one loud stakeholder, a small segment, or a large swath of users? A brilliant solution to a tiny problem rarely moves the business.' },
  { n: 2, question: 'How painful is it, really, versus how painful does it look?', prompt: 'A confusing screen that costs someone 10 seconds is different from one that causes people to abandon a task or call support. Separate annoyance from actual cost.' },
  { n: 3, question: 'What is the cost of doing nothing?', prompt: 'If this problem sat untouched for another year, what would happen? Sometimes the answer is "nothing much," which tells you a lot.' },
  { n: 4, question: 'Does this connect to a metric leadership already cares about?', prompt: 'Conversion, retention, support volume, time to complete a task, NPS. If you can\'t draw a line from the problem to something the business tracks, it will be much harder to get support and resources.' },
  { n: 5, question: 'How confident are you that the proposed direction would actually fix it?', prompt: 'Some problems are well understood with an obvious fix. Others are murky and might need research before anyone commits real effort. That uncertainty is itself a factor in prioritization.' },
  { n: 6, question: 'What would it take to solve, roughly?', prompt: 'Not a full estimate, just a gut check. Is this a small design tweak, a few sprints of engineering work, or a multi-quarter initiative touching several teams?' },
  { n: 7, question: 'Is this problem a symptom of something bigger?', prompt: 'Sometimes what looks like ten small issues are actually one root cause. Fixing the root is often higher value than fixing the symptoms one at a time.' },
  { n: 8, question: 'Who else has to say yes for this to happen?', prompt: 'Engineering, product, compliance, other design teams. A great idea that requires five approvals moves slower than a good idea that requires one.' },
  { n: 9, question: "What's the opportunity cost?", prompt: 'What else could you or the team be working on instead? Value is relative, so the real question isn\'t "is this good" but "is this better than the next best thing on the list."' },
  { n: 10, question: 'If you could only defend one sentence to a skeptical VP, what would it be?', prompt: "This forces clarity. If you can't state the value crisply, the opportunity probably isn't well understood yet, regardless of how real it feels." },
];

function formatUxEvalFramework() {
  return UX_EVAL_QUESTIONS.map(q => `${q.n}. **${q.question}**\n   ${q.prompt}`).join('\n');
}

// ─── SVG gauge rendering ──────────────────────────────────────────────────────
// Plain SVG (no <foreignObject>, no JS) so any client that accepts an image
// content block can rasterize it.

function escapeXml(s) {
  return String(s).replace(/[<>&"']/g, c =>
    ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c])
  );
}

function gaugeColor(score) {
  const s = Math.max(0, Math.min(100, Number(score) || 0));
  if (s >= 80) return '#16a34a';
  if (s >= 60) return '#ca8a04';
  return '#dc2626';
}

function svgGaugeRow({ label, score, y, width, labelW = 120 }) {
  const s = Math.max(0, Math.min(100, Math.round(Number(score) || 0)));
  const trackX = labelW + 16;
  const trackW = width - trackX - 56;
  const fillW = Math.max(2, Math.round(trackW * s / 100));
  const color = gaugeColor(s);
  return [
    `<text x="20" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="13" font-weight="500" fill="#0f172a">${escapeXml(label)}</text>`,
    `<rect x="${trackX}" y="${y}" width="${trackW}" height="18" rx="9" fill="#e2e8f0" />`,
    `<rect x="${trackX}" y="${y}" width="${fillW}" height="18" rx="9" fill="${color}" />`,
    `<text x="${trackX + trackW + 8}" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="12" font-weight="700" fill="#334155">${s}%</text>`,
  ].join('');
}

function gaugeSvg(report, system, target) {
  if (!report) return null;
  const W = 580;
  const parts = [];
  let y = 50;
  const title = `${String(system || '').toUpperCase()} compliance — ${target}`;
  parts.push(`<text x="20" y="28" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="15" font-weight="700" fill="#0f172a">${escapeXml(title)}</text>`);
  parts.push(svgGaugeRow({ label: 'Overall', score: report.score, y, width: W }));
  y += 32;
  if (Array.isArray(report.accessibilityIssues)) {
    parts.push(svgGaugeRow({ label: 'Accessibility', score: report.accessibilityScore, y, width: W }));
    y += 32;
  }
  y += 8;
  parts.push(`<line x1="20" x2="${W - 20}" y1="${y - 4}" y2="${y - 4}" stroke="#e2e8f0" stroke-width="1"/>`);
  for (const [name, count] of domainRows(report, target)) {
    const c = count || 0;
    parts.push(`<text x="20" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="12" fill="#334155">${escapeXml(name)}</text>`);
    parts.push(`<text x="${W - 20}" y="${y + 14}" text-anchor="end" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="12" font-weight="600" fill="${c > 0 ? '#dc2626' : '#16a34a'}">${c} ${c === 1 ? 'issue' : 'issues'}</text>`);
    y += 22;
  }
  parts.push(`<text x="20" y="${y + 16}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="11" fill="#64748b">Nodes scanned: ${report.totalNodes || 0}</text>`);
  y += 30;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${y}" viewBox="0 0 ${W} ${y}"><rect width="100%" height="100%" fill="#ffffff"/>${parts.join('')}</svg>`;
}

function gaugeDeltaSvg(before, after, system, target) {
  if (!after) return gaugeSvg(before, system, target);
  if (!before) return gaugeSvg(after, system, target);
  const W = 640;
  const parts = [];
  let y = 50;
  const title = `${String(system || '').toUpperCase()} delta — ${target}`;
  parts.push(`<text x="20" y="28" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="15" font-weight="700" fill="#0f172a">${escapeXml(title)}</text>`);

  const rowDelta = (label, beforeScore, afterScore) => {
    const out = [];
    out.push(`<text x="20" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="13" font-weight="500" fill="#0f172a">${escapeXml(label)}</text>`);
    const bx = 140, gw = 200;
    const beforeFill = Math.round(gw * Math.max(0, Math.min(100, Number(beforeScore) || 0)) / 100);
    out.push(`<rect x="${bx}" y="${y}" width="${gw}" height="18" rx="9" fill="#e2e8f0"/>`);
    out.push(`<rect x="${bx}" y="${y}" width="${beforeFill}" height="18" rx="9" fill="${gaugeColor(beforeScore)}" opacity="0.55"/>`);
    out.push(`<text x="${bx + gw + 8}" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="11" fill="#64748b">${Math.round(beforeScore || 0)}%</text>`);
    out.push(`<text x="${bx + gw + 36}" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="13" fill="#64748b">→</text>`);
    const ax = bx + gw + 56;
    const afterFill = Math.round(gw * Math.max(0, Math.min(100, Number(afterScore) || 0)) / 100);
    out.push(`<rect x="${ax}" y="${y}" width="${gw}" height="18" rx="9" fill="#e2e8f0"/>`);
    out.push(`<rect x="${ax}" y="${y}" width="${afterFill}" height="18" rx="9" fill="${gaugeColor(afterScore)}"/>`);
    out.push(`<text x="${ax + gw + 8}" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="12" font-weight="700" fill="#334155">${Math.round(afterScore || 0)}%</text>`);
    return out.join('');
  };

  parts.push(rowDelta('Overall', before.score, after.score));
  y += 32;
  if (Array.isArray(before.accessibilityIssues) || Array.isArray(after.accessibilityIssues)) {
    parts.push(rowDelta('Accessibility', before.accessibilityScore, after.accessibilityScore));
    y += 32;
  }
  y += 8;
  parts.push(`<line x1="20" x2="${W - 20}" y1="${y - 4}" y2="${y - 4}" stroke="#e2e8f0" stroke-width="1"/>`);
  const rows = [
    ['Colors', before.colorIssues?.length ?? 0, after.colorIssues?.length ?? 0],
    ['Text styles', before.textIssues?.length ?? 0, after.textIssues?.length ?? 0],
    ['Spacing', before.spacingIssues?.length ?? 0, after.spacingIssues?.length ?? 0],
  ];
  if (target !== 'chrome') rows.push(['Components', before.componentIssues?.length ?? 0, after.componentIssues?.length ?? 0]);
  if (Array.isArray(before.accessibilityIssues) || Array.isArray(after.accessibilityIssues)) {
    rows.push(['A11y', before.accessibilityIssues?.length ?? 0, after.accessibilityIssues?.length ?? 0]);
  }
  for (const [name, b, a] of rows) {
    parts.push(`<text x="20" y="${y + 14}" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="12" fill="#334155">${escapeXml(name)}</text>`);
    const delta = a - b;
    const deltaStr = `${b} → ${a} (${delta >= 0 ? '+' : ''}${delta})`;
    const color = delta < 0 ? '#16a34a' : delta > 0 ? '#dc2626' : '#64748b';
    parts.push(`<text x="${W - 20}" y="${y + 14}" text-anchor="end" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="12" font-weight="600" fill="${color}">${deltaStr}</text>`);
    y += 22;
  }
  y += 8;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${y}" viewBox="0 0 ${W} ${y}"><rect width="100%" height="100%" fill="#ffffff"/>${parts.join('')}</svg>`;
}

// ─── Design review scorecard (score_design_review) ───────────────────────────
// Same plain-SVG gauge rows as the compliance audits, so an ADQR review reads
// like every other scored result in the chat: four pillar gauges, the verdict
// and confidence on top, flow risks underneath.

// One step darker than the gauge colors, so the white label on the verdict
// pill clears 4.5:1.
const VERDICT_COLOR = {
  ready_for_engineering: '#15803d',
  revise_before_engineering: '#a16207',
  ux_review_required: '#b91c1c',
  insufficient_evidence: '#475569',
};
const CONFIDENCE_LABEL = { high: 'High', medium: 'Medium', low: 'Low' };
const MODALITY_LABEL = { static: 'Static screens', semi_interactive: 'Semi-interactive', fully_interactive: 'Fully interactive' };
const FONT = 'font-family="Inter, system-ui, -apple-system, sans-serif"';

function designReviewSvg(r) {
  const W = 640;
  const parts = [];
  let y = 30;
  const title = r.title ? `Design review · ${r.title}` : 'Design review';
  parts.push(`<text x="20" y="${y}" ${FONT} font-size="15" font-weight="700" fill="#0f172a">${escapeXml(title.length > 70 ? title.slice(0, 69) + '…' : title)}</text>`);
  y += 16;

  // Verdict pill + confidence, the two things a reader needs first.
  const vColor = VERDICT_COLOR[r.verdict.decision];
  const vText = r.verdict.label;
  const pillW = Math.round(vText.length * 7.4) + 28;
  parts.push(`<rect x="20" y="${y}" width="${pillW}" height="26" rx="13" fill="${vColor}"/>`);
  parts.push(`<text x="${20 + pillW / 2}" y="${y + 17}" text-anchor="middle" ${FONT} font-size="13" font-weight="700" fill="#ffffff">${escapeXml(vText)}</text>`);
  const confColor = r.confidence === 'high' ? '#16a34a' : r.confidence === 'medium' ? '#ca8a04' : '#dc2626';
  parts.push(`<text x="${W - 20}" y="${y + 12}" text-anchor="end" ${FONT} font-size="12" fill="#334155">Confidence <tspan font-weight="700" fill="${confColor}">${CONFIDENCE_LABEL[r.confidence]}</tspan></text>`);
  parts.push(`<text x="${W - 20}" y="${y + 26}" text-anchor="end" ${FONT} font-size="11" fill="#64748b">${escapeXml(`${MODALITY_LABEL[r.modality]} · ${r.screenCount} ${r.screenCount === 1 ? 'screen' : 'screens'}`)}</text>`);
  y += 34;
  if (r.verdict.gatingPillar) {
    parts.push(`<text x="20" y="${y + 6}" ${FONT} font-size="11" fill="#64748b">${escapeXml(`Set by the weakest pillar: ${r.verdict.gatingPillar} (${r.verdict.gatingScore}%)`)}</text>`);
    y += 14;
  }

  // A review whose screens don't show the product still shows its scores,
  // but never quietly: ADQR requires a prominent warning, not a badge.
  if (r.sufficientContent === false) {
    y += 6;
    parts.push(`<rect x="20" y="${y}" width="${W - 40}" height="26" rx="6" fill="#fef2f2" stroke="#dc2626"/>`);
    parts.push(`<text x="32" y="${y + 17}" ${FONT} font-size="12" font-weight="600" fill="#b91c1c">The screens don't show enough real product UI to judge. Treat these scores as unreliable.</text>`);
    y += 30;
  }

  y += 14;
  for (const p of r.pillars) {
    if (p.score === null) {
      parts.push(`<text x="20" y="${y + 14}" ${FONT} font-size="13" font-weight="500" fill="#0f172a">${escapeXml(p.label)}</text>`);
      parts.push(`<rect x="176" y="${y}" width="${W - 176 - 56}" height="18" rx="9" fill="#f1f5f9"/>`);
      const why = `Not scored: ${p.nullReason}`;
      parts.push(`<text x="188" y="${y + 13}" ${FONT} font-size="11" fill="#64748b">${escapeXml(why.length > 62 ? why.slice(0, 61) + '…' : why)}</text>`);
      parts.push(`<text x="${W - 48}" y="${y + 14}" ${FONT} font-size="12" font-weight="700" fill="#94a3b8">N/A</text>`);
    } else {
      parts.push(svgGaugeRow({ label: p.label, score: p.score, y, width: W, labelW: 160 }));
    }
    parts.push(`<text x="176" y="${y + 31}" ${FONT} font-size="10" fill="#94a3b8">${p.scoredCount} of ${p.totalCount} checks scored</text>`);
    y += 42;
  }

  // Flow risks: present / missing per state, highlight only.
  y += 4;
  parts.push(`<line x1="20" x2="${W - 20}" y1="${y}" y2="${y}" stroke="#e2e8f0" stroke-width="1"/>`);
  y += 20;
  parts.push(`<text x="20" y="${y}" ${FONT} font-size="12" font-weight="700" fill="#0f172a">Flow states</text>`);
  if (!r.flowRisks.some((f) => f.applicable)) {
    parts.push(`<text x="110" y="${y}" ${FONT} font-size="11" fill="#64748b">Needs more than one screen to check.</text>`);
    y += 12;
  } else {
    y += 8;
    const colW = (W - 40) / 2;
    r.flowRisks.forEach((f, i) => {
      const cx = 20 + (i % 2) * colW;
      const cy = y + Math.floor(i / 2) * 20;
      const color = f.present ? '#16a34a' : '#dc2626';
      parts.push(`<circle cx="${cx + 5}" cy="${cy + 9}" r="5" fill="${color}"/>`);
      parts.push(`<text x="${cx + 16}" y="${cy + 13}" ${FONT} font-size="12" fill="#334155">${escapeXml(f.label)}<tspan fill="${color}" font-weight="600">${f.present ? '  shown' : '  not shown'}</tspan></text>`);
    });
    y += Math.ceil(r.flowRisks.length / 2) * 20;
  }

  y += 18;
  parts.push(`<text x="20" y="${y}" ${FONT} font-size="10" fill="#94a3b8">ADQR rubric by Prafull Mane · rules applied in code · not yet calibrated against human reviewers</text>`);
  y += 14;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${y}" viewBox="0 0 ${W} ${y}"><rect width="100%" height="100%" fill="#ffffff"/>${parts.join('')}</svg>`;
}

function designReviewSummary(r) {
  const L = [];
  const pct = (s) => (s === null ? 'N/A' : `${s}%`);
  L.push(`### Design review${r.title ? `: ${r.title}` : ''}`);
  L.push('');
  L.push(`**${r.verdict.label}**${r.verdict.gatingPillar ? `, set by the weakest pillar, ${r.verdict.gatingPillar} (${r.verdict.gatingScore}%)` : ''}. Confidence: **${CONFIDENCE_LABEL[r.confidence]}**.`);
  if (r.confidenceReasons.length) L.push(`Why: ${r.confidenceReasons.join(' ')}`);
  if (r.sufficientContent === false) L.push('', `> **Warning:** the screens don't show enough real product UI to judge. ${r.contentNote}`);
  L.push('', `What was reviewed: ${r.contentNote} (${MODALITY_LABEL[r.modality].toLowerCase()}, ${r.screenCount} ${r.screenCount === 1 ? 'screen' : 'screens'})`);
  L.push('', '| Pillar | Score | Checks scored |', '| --- | --- | --- |');
  for (const p of r.pillars) L.push(`| ${p.label} | ${pct(p.score)}${p.score === null ? `, ${p.nullReason}` : ''} | ${p.scoredCount} of ${p.totalCount} |`);

  if (r.requirementElements.length) {
    L.push('', '**Requirement, part by part**', '', '| | Part | Status | Evidence |', '| --- | --- | --- | --- |');
    for (const e of r.requirementElements) L.push(`| ${e.id} | ${e.text} | ${e.status.replace('_', ' ')} | ${e.evidence || ''} |`);
  }
  if (r.missingRequirements.length) L.push('', `**Not addressed:** ${r.missingRequirements.join('; ')}`);
  if (r.extraFeatures.length) L.push('', `**Not asked for:** ${r.extraFeatures.join('; ')}`);

  const weak = r.pillars.flatMap((p) => p.dimensions.filter((d) => d.applicable && d.appliedBand <= 4).map((d) => ({ ...d, pillar: p.label })));
  if (weak.length) {
    L.push('', '**Weakest checks** (band 4 or below)', '', '| Pillar | Check | Band | Finding | Basis |', '| --- | --- | --- | --- | --- |');
    for (const d of weak.sort((a, b) => a.appliedBand - b.appliedBand)) {
      L.push(`| ${d.pillar} | ${d.label} | ${d.appliedBand}/10${d.capped ? ` (capped from ${d.band})` : ''} | ${d.evidenceShort || d.evidence || ''} | ${d.evidenceTag || ''} |`);
    }
  }
  const flowShown = r.flowRisks.filter((f) => f.applicable);
  if (flowShown.length) {
    const missing = flowShown.filter((f) => !f.present).map((f) => f.label);
    L.push('', missing.length ? `**Flow states not shown:** ${missing.join(', ')}` : '**Flow states:** all seven shown.');
  }
  const counts = {};
  for (const d of r.excludedDimensions) counts[d.reason] = (counts[d.reason] || 0) + 1;
  const reasonText = { missing_field: 'missing context', insufficient_evidence: 'only one screen', insufficient_modality_evidence: 'needs an interactive version', out_of_scope: "doesn't apply" };
  if (r.excludedDimensions.length) L.push('', `Not scored: ${Object.entries(counts).map(([k, n]) => `${n} (${reasonText[k]})`).join(', ')}. Full per-check evidence is in the JSON below.`);
  L.push('', `_${r.rubric}_`);
  return L.join('\n');
}

// The last few tool failures, for report_problem. In memory only, never sent anywhere by itself.
const RECENT_ERRORS = [];
function noteToolError(tool, message) {
  RECENT_ERRORS.push({ tool, message: String(message).slice(0, 300), at: new Date().toISOString() });
  if (RECENT_ERRORS.length > 8) RECENT_ERRORS.shift();
}

const TOOLS = [
  {
    name: 'list_targets',
    description: 'List plugin sessions (figma / chrome) currently connected to the MCP hub. Always returns hub info so you can tell whether you are on the primary hub or a proxy.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: async () => {
      if (MODE.kind === 'proxy') {
        // Ask the primary for a fresh dump, but still return the cached list
        // immediately so Claude never blocks waiting for a sessions push.
        if (proxyWs && proxyWs.readyState === 1) {
          try { proxyWs.send(JSON.stringify({ kind: 'proxy_list_sessions' })); } catch { /* noop */ }
        }
        return {
          targets: cachedProxySessions,
          hub: cachedProxyHubInfo || { ...hubInfo(), primaryReachable: !!(proxyWs && proxyWs.readyState === 1) },
          thisProcess: hubInfo(),
        };
      }
      return { targets: listLocalSessions(), hub: hubInfo() };
    },
  },
  {
    name: 'report_problem',
    description: 'Package what is needed to fix a problem into one report for Erick Mathews, the owner of NiCE Designer, so the user never has to explain it: connector and hub versions, what is connected, the last tool errors, skill bundle freshness, and the user\'s own note. Writes the report to ~/.nice-designer/reports/ and returns it. Use it whenever something fails in a way the user cannot fix, then tell them in one line to send the report to Erick Mathews (or offer to put it in a Jira ticket if they give a project).',
    inputSchema: {
      type: 'object',
      properties: { note: { type: 'string', description: 'What the user was trying to do and what went wrong, in their words.' } },
      additionalProperties: false,
    },
    handler: async ({ note }) => {
      const sessionsNow = MODE.kind === 'primary' ? listLocalSessions() : cachedProxySessions;
      let bundle = 'none (dev checkout)';
      try { bundle = new Date(JSON.parse(fs.readFileSync(path.join(SKILLS_DIR, 'bundle-stamp.json'), 'utf8')).builtAt).toISOString(); } catch { /* dev checkout */ }
      const lines = [
        '# NiCE Designer problem report',
        '',
        `Created: ${new Date().toISOString()}`,
        `Connector version: ${MCP_SERVER_VERSION || 'unknown'}   Skills bundle built: ${bundle}`,
        `Process: pid ${process.pid}, mode ${MODE.kind}, platform ${process.platform}, node ${process.version}`,
        `Connected clients: ${sessionsNow.length ? sessionsNow.map(x => `${x.target} (since ${new Date(x.connectedAt).toISOString()})`).join(', ') : 'none'}`,
        `Tools registered: ${TOOLS.length}`,
        '',
        '## What the user said',
        note ? String(note) : '(no note given)',
        '',
        '## Recent tool errors',
        ...(RECENT_ERRORS.length ? RECENT_ERRORS.map(e => `- ${e.at} ${e.tool}: ${e.message}`) : ['(none this session)']),
        '',
        'Send this to Erick Mathews.',
      ];
      const text = lines.join('\n');
      let file = '';
      try {
        const dir = path.join(os.homedir(), '.nice-designer', 'reports');
        fs.mkdirSync(dir, { recursive: true });
        file = path.join(dir, `problem-${Date.now()}.md`);
        fs.writeFileSync(file, text + '\n');
      } catch { file = ''; }
      return { __text: true, text: (file ? `Saved to ${file}\n\n` : '') + text };
    },
  },
  {
    name: 'get_diagnostics',
    description: 'Return a full health report on the MCP bridge: this process, the hub, connected plugin sessions, and recent disconnects. Call this first if list_targets looks wrong.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: async () => {
      const now = Date.now();
      const base = {
        now,
        thisProcess: hubInfo(),
        heartbeatMs: HEARTBEAT_MS,
        sessionStaleMs: SESSION_STALE_MS,
      };
      if (MODE.kind === 'proxy') {
        return {
          ...base,
          primaryReachable: !!(proxyWs && proxyWs.readyState === 1),
          primaryHub: cachedProxyHubInfo,
          targetsFromPrimary: cachedProxySessions,
          pendingProxyRequests: proxyPending.size,
          advice: cachedProxySessions.length === 0
            ? 'Primary is reachable but reports no plugin sessions. Check the extension/plugin toggle and that the browser tab is open.'
            : 'Bridge is healthy.',
        };
      }
      return {
        ...base,
        hub: hubInfo(),
        sessions: listLocalSessions().map(s => ({ ...s, staleInMs: SESSION_STALE_MS - (now - s.lastSeen) })),
        proxyClients: proxyClients.size,
        pendingRequests: pending.size,
        recentDisconnects,
        advice: sessions.size === 0
          ? "Hub is up but no plugin has connected. Confirm the 'Connect to Claude MCP' toggle is on in the Chrome extension / Figma plugin and that it can reach ws://127.0.0.1:" + WS_PORT + '.'
          : 'Bridge is healthy.',
      };
    },
  },
  {
    name: 'analytics_summary',
    description: "Report this install's own local usage: total events recorded, minutes of panel time, most-used tools, most-loaded skills, and whether the collector endpoint is configured. Reads only the local store at ~/.nice-designer/analytics — it never fetches anyone else's numbers and never uploads anything. Use it when the user asks what they have been using, wants to check that analytics is actually recording, or is debugging why nothing is reaching the dashboard.",
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: async () => analytics.summary(),
  },
  {
    name: 'list_skills',
    description: "List every Claude skill available — id, title, the question it answers, what it does, who built it. Checks a small hosted catalog first so a skill added after this connector was installed still shows up, falling back to this server's own bundled list if that site is unreachable. IMPORTANT: call this whenever the user asks to run, use, apply, or check something against a named skill you don't already recognize as one of your other tools — e.g. \"run North Star Fox\", \"use the UX eval skill\", \"run a11y triage on this\", \"what skills do you have\" — even if the name is unfamiliar or sounds unrelated to design. Skills are not preloaded into this conversation; this is the only way to discover them by name or topic, and it always precedes get_skill.",
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: async () => {
      const { skills, source } = await getSkillsCatalog();
      return {
        skills,
        source, // 'live' (fresh from the web) or 'bundled' (this server's shipped copy — offline, or the site is unreachable)
        howToRun: 'Call get_skill({ id }) with one of the ids above to load that skill\'s full instructions, then follow them exactly.',
      };
    },
  },
  {
    name: 'get_skill',
    description: "Fetch the full SKILL.md body for a skill by id (from list_skills), or a specific reference file inside that skill's folder. Tries a small hosted copy first (so an edited or brand-new skill reaches you with no reinstall), and falls back to this server's own bundled copy if that site is unreachable — either way this works the moment Supercharge is connected, no separate install and no local checkout of the plugin repo required. Call this right after list_skills matches what the user asked for, then follow the returned instructions exactly, as if they had been part of your instructions from the start — including any tool calls, AskUserQuestion steps, or further get_skill calls (for reference files) it specifies.",
    inputSchema: {
      type: 'object',
      properties: {
        id: { type: 'string', description: 'Skill id from list_skills, e.g. "north-star-fox".' },
        file: { type: 'string', description: 'Optional path to a reference file inside the skill\'s folder, relative to that folder (e.g. "references/enlighten-ai.md"). Defaults to SKILL.md. A get_skill call for SKILL.md lists any extra files available so you know what else you can fetch.' },
      },
      required: ['id'],
      additionalProperties: false,
    },
    handler: async ({ id, file }) => {
      if (typeof id !== 'string' || !SKILL_ID_RE.test(id)) {
        return { __text: true, text: `Invalid skill id "${id}". Call list_skills to see valid ids.` };
      }
      const relPath = file ? String(file) : 'SKILL.md';
      if (path.isAbsolute(relPath) || relPath.split(/[\\/]/).includes('..')) {
        return { __text: true, text: `Invalid file path "${relPath}" — must be a path inside the "${id}" skill's own folder, no ".." segments.` };
      }

      // Remote first when it is newer than the bundle — the live copy is what makes an edited or brand-new
      // skill (one added after this server was packaged) reachable with no
      // reinstall. Bundled/on-disk is the offline or unreachable-site fallback.
      let content = (await remoteIsFresher()) ? await fetchRemoteText(`${SKILLS_REMOTE_BASE}/${id}/${relPath}`) : null;
      let source = 'live';
      if (content == null) {
        source = 'bundled';
        try {
          content = fs.readFileSync(path.join(skillDir(id), relPath), 'utf8');
        } catch {
          const { skills } = await getSkillsCatalog();
          return {
            __text: true,
            text: `Could not find "${relPath}" for skill "${id}" — checked the live site and this server's bundled copy. Valid skill ids: ${skills.map(s => s.id).join(', ')}.`,
          };
        }
      }
      if (relPath !== 'SKILL.md') return { __text: true, text: content };

      const { skills } = await getSkillsCatalog();
      const entry = skills.find(s => s.id === id) || {};
      const files = entry.files || [];
      // The connector has no auto-update. A skill (live or bundled) can name tools this
      // installed connector does not have, and then fails in confusing ways: say it plainly.
      const have = new Set(TOOLS.map(t => t.name));
      const missingTools = (entry.tools || []).filter(n => !have.has(n));
      const warn = missingTools.length
        ? `> **Connector out of date.** This skill uses tools the installed NiCE Designer connector does not have (${missingTools.join(', ')}). Tell the user, in one plain sentence, to reinstall the connector (the "Click to install Claude Connector" file from the NiCE Designer download), then carry on with what works.\n\n`
        : '';
      const note = files.length
        ? `\n\n---\nThis skill also ships reference files — fetch one with get_skill({ id: "${id}", file: "<path>" }): ${files.join(', ')}`
        : '';
      return { __text: true, text: warn + content + note };
    },
  },
  {
    name: 'get_lynn_ui',
    description: "Hands over the bundled `lynn-ui` React package (the Lynn design system) so a prototype can install it with no network access and no checkout of the plugin repo. Needed when the sandbox cannot reach the published copy (403) or cannot see this server's disk. Three modes: no arguments returns a manifest (version, file list, sizes); `destination` copies the whole package to `<destination>/lynn-ui` on the machine this connector runs on (use a project folder the session has connected, then `npm install --install-links ./lynn-ui react react-dom`); `files` returns the text of specific files (capped per call) for when no writable folder is shared, so you can write them out yourself.",
    inputSchema: {
      type: 'object',
      properties: {
        destination: { type: 'string', description: 'Absolute path of an existing folder on the connector\'s machine, usually the project folder. The package is copied to <destination>/lynn-ui.' },
        files: { type: 'array', items: { type: 'string' }, description: 'Paths relative to the package root (e.g. "package.json", "dist/index.js", "dist/lynn-ui.css"). Returns their text, up to about 120 KB per call; the rest are listed as deferred.' },
      },
      additionalProperties: false,
    },
    handler: async ({ destination, files }) => {
      const lynnDir = LYNN_DIR_CANDIDATES.find(d => fs.existsSync(path.join(d, 'package.json')));
      if (!lynnDir) {
        return { __text: true, text: `The bundled lynn-ui package was not found (looked in ${LYNN_DIR_CANDIDATES.join(', ')}). Reinstall the connector, or run \`npm run sync:skills\` in a checkout.` };
      }
      const all = [];
      (function walk(dir) {
        for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
          const full = path.join(dir, e.name);
          if (e.isDirectory()) walk(full);
          else all.push({ rel: path.relative(lynnDir, full).split(path.sep).join('/'), bytes: fs.statSync(full).size });
        }
      })(lynnDir);
      const version = JSON.parse(fs.readFileSync(path.join(lynnDir, 'package.json'), 'utf8')).version;

      if (destination != null) {
        if (typeof destination !== 'string' || !path.isAbsolute(destination) || destination.split(/[\\/]/).includes('..')) {
          return { __text: true, text: `"destination" must be an absolute path with no ".." segments, got "${destination}".` };
        }
        if (!fs.existsSync(destination) || !fs.statSync(destination).isDirectory()) {
          return { __text: true, text: `"${destination}" is not an existing folder on the machine this connector runs on. Pass the project folder's real path, or use the "files" mode instead.` };
        }
        const target = path.join(destination, 'lynn-ui');
        if (fs.existsSync(target)) {
          let name = null;
          try { name = JSON.parse(fs.readFileSync(path.join(target, 'package.json'), 'utf8')).name; } catch { /* not a package */ }
          if (name !== 'lynn-ui') {
            return { __text: true, text: `"${target}" already exists and is not a lynn-ui package, so it was left alone. Pick another destination.` };
          }
          fs.rmSync(target, { recursive: true, force: true });
        }
        try {
          fs.cpSync(lynnDir, target, { recursive: true });
        } catch (err) {
          return { __text: true, text: `Could not write to "${target}": ${err.message}. If this folder is read-only from the connector's side, use the "files" mode.` };
        }
        return { __text: true, text: `Copied lynn-ui ${version} (${all.length} files) to ${target}.\nNext, from the project: npm install --install-links ./lynn-ui react react-dom\nIf that path is not visible from your shell, the folder is mounted under a different name there. Look for lynn-ui beside the project root.` };
      }

      if (Array.isArray(files) && files.length) {
        const CAP = 120 * 1024;
        let used = 0;
        const out = [];
        const deferred = [];
        for (const raw of files) {
          const rel = String(raw);
          if (path.isAbsolute(rel) || rel.split(/[\\/]/).includes('..') || !all.some(f => f.rel === rel)) {
            out.push(`=== ${rel} ===\n(not part of the package)`);
            continue;
          }
          const size = all.find(f => f.rel === rel).bytes;
          if (used > 0 && used + size > CAP) { deferred.push(rel); continue; }
          used += size;
          out.push(`=== ${rel} ===\n${fs.readFileSync(path.join(lynnDir, rel), 'utf8')}`);
        }
        const tail = deferred.length ? `\n\n--- Over the per-call cap, ask again for: ${deferred.join(', ')}` : '';
        return { __text: true, text: out.join('\n\n') + tail };
      }

      const total = all.reduce((n, f) => n + f.bytes, 0);
      return {
        __text: true,
        text: `lynn-ui ${version}: ${all.length} files, ${Math.round(total / 1024)} KB.\n`
          + `Preferred: get_lynn_ui({ destination: "<project folder>" }) copies it in one step.\n`
          + `No writable folder: fetch files with get_lynn_ui({ files: [...] }) in batches and write each to the same relative path under ./lynn-ui/. Start with package.json, dist/index.js, dist/lynn-ui.css, dist/index.d.ts; dist/components/**, dist/hooks/**, dist/theme/**, dist/tokens/**, dist/icons/** are imported by index.js, so it needs every .js file.\n\n`
          + all.map(f => `${f.rel}  ${f.bytes}`).join('\n'),
      };
    },
  },
  {
    name: 'find_capability',
    description: "Keyword search across EVERY tool and skill this server offers — all ~58 tools and 40+ skills (including third-party/marketplace ones) in one pass. The single entry point for \"is there something in NiCE Designer for this?\" when the exact tool/skill name isn't already obvious, or the request is vague (\"something about contrast\", \"help with tokens\", \"anything for dark mode\"). Returns ranked matches with exactly how to invoke each one — a tool result is called directly by name, a skill result needs get_skill({id}) first. This tool never runs anything itself, it only finds. Call this BEFORE doing the equivalent work manually (writing your own contrast checker, hand-auditing colors, etc.) whenever the request plausibly overlaps design-system, audit, accessibility, token, component, Figma, or Chrome-page work — that's the whole point of checking first.",
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Free-text keyword or short phrase, e.g. "contrast", "dark mode", "convert to lyra", "storybook components", "accessibility triage".' },
        limit: { type: 'number', description: 'Max results to return (default 8, max 20).' },
      },
      required: ['query'],
      additionalProperties: false,
    },
    handler: async ({ query, limit }) => {
      const max = Math.max(1, Math.min(20, limit || 8));

      const toolMatches = TOOLS.map(t => {
        const meta = CATALOG.TOOLS_BY_NAME[t.name];
        if (!meta) return null;
        const score = scoreCatalogMatch(query, [[meta.title, 3], [t.name, 3], [meta.what, 2], [meta.benefit, 1]]);
        if (score <= 0) return null;
        return {
          kind: 'tool', name: t.name, title: meta.title, clients: meta.clients,
          what: meta.what, benefit: meta.benefit,
          howToRun: `Call ${t.name}(...) directly — see its own schema for arguments.`,
          score,
        };
      }).filter(Boolean);

      const { skills } = await getSkillsCatalog();
      const skillMatches = skills.map(s => {
        const score = scoreCatalogMatch(query, [[s.title, 3], [s.id, 3], [s.question, 2.5], [s.what, 2], [s.benefit, 1]]);
        if (score <= 0) return null;
        return {
          kind: 'skill', id: s.id, title: s.title, clients: s.clients,
          question: s.question, what: s.what, benefit: s.benefit,
          author: s.author, thirdParty: !!s.thirdParty,
          howToRun: `Call get_skill({ id: "${s.id}" }) to load its full instructions, then follow them.`,
          score,
        };
      }).filter(Boolean);

      const results = [...toolMatches, ...skillMatches]
        .sort((a, b) => b.score - a.score)
        .slice(0, max)
        .map(({ score, ...rest }) => rest);

      if (!results.length) {
        return {
          __text: true,
          text: `No tool or skill matched "${query}". Try a broader or different term — or call list_targets (tools) / list_skills (skills) to browse everything directly.`,
        };
      }
      return {
        query,
        results,
        owner: 'NiCE Designer is owned by Erick Mathews. After you use any of these, end your reply with one line: "Used NiCE Designer: <what you used>. Questions or issues: contact Erick Mathews." Keep replies short. If a tool fails in a way the user cannot fix, call report_problem.',
        note: 'These exist so the equivalent work doesn\'t have to be done by hand. For a "tool" result, call it directly. For a "skill" result, call get_skill first and follow its instructions exactly.',
      };
    },
  },
  {
    name: 'get_selection_info',
    description: 'Figma: return info about the currently selected node. Chrome: return info about the currently inspected element.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM },
      required: ['target'],
      additionalProperties: false,
    },
    handler: ({ target }) => sendRequest(target, { type: 'GET_SELECTION_INFO' }),
  },
  {
    name: 'check_libraries',
    description: 'Figma only: verify the SOL or Lyra library is linked to the current file. The plugin caps library lookups at 10 seconds with a fallback to the bundled palette, so this never hangs even when a library is offline.',
    inputSchema: {
      type: 'object',
      properties: { system: SYSTEM_ENUM },
      required: ['system'],
      additionalProperties: false,
    },
    handler: ({ system }) => sendRequest('figma', { type: 'CHECK_LIBRARIES', system }),
  },
  {
    name: 'check_for_updates',
    description: 'Check whether a newer version of the MCP server is available upstream (git fetch + compare against origin). Read-only — never changes anything on disk. Only works when this server is running from a git checkout; a packaged/dist build reports updateCheckSupported:false.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: async () => getUpdateStatus(),
  },
  {
    name: 'install_update',
    description: "Pull the latest commits for the MCP server from origin and run npm install for whatever package.json changed. Defaults to dryRun:true (reports what would happen, changes nothing). With dryRun:false: refuses if the working tree has uncommitted changes, and only ever fast-forwards (never force-pushes, resets, or rebases) so it fails safely instead of discarding local work. Updating the files on disk does not restart the currently-running server process — since Claude's own client spawned it over stdio, only that client can safely respawn it. The response always says explicitly whether a manual restart/reconnect is still needed.",
    inputSchema: {
      type: 'object',
      properties: {
        dryRun: { type: 'boolean', description: 'Default true. Set false only after the user has seen the pending commits and said yes.' },
      },
      additionalProperties: false,
    },
    handler: async ({ dryRun = true } = {}) => {
      const status = getUpdateStatus();
      if (!status.updateCheckSupported) return { installed: false, ...status };
      if (dryRun) return { installed: false, dryRun: true, ...status };
      if (updateInProgress) return { installed: false, reason: 'Another install_update call is already in progress.' };
      if (status.hasLocalChanges) {
        return { installed: false, reason: 'Working tree has uncommitted changes — refusing to pull. Commit or stash them first, then retry.', ...status };
      }
      if (!status.updateAvailable) return { installed: false, reason: 'Already up to date.', ...status };
      updateInProgress = true;
      try {
        try {
          runGit(['merge', '--ff-only', `origin/${status.branch}`]);
        } catch (e) {
          return { installed: false, reason: `Fast-forward merge failed — local branch has diverged from origin/${status.branch}. Resolve manually with git.`, error: String(e.message || e), ...status };
        }
        const changedFiles = runGit(['diff', '--name-only', status.currentCommit, status.remoteCommit]).split('\n').filter(Boolean);
        const npmInstalls = [];
        const installIn = (dir, label) => {
          try {
            execFileSync('npm', ['install'], { cwd: path.join(REPO_ROOT, dir), stdio: 'ignore', timeout: 180_000 });
            npmInstalls.push({ dir: label, ok: true });
          } catch (e) {
            npmInstalls.push({ dir: label, ok: false, error: String(e.message || e) });
          }
        };
        if (changedFiles.some(f => f === 'package.json' || f === 'package-lock.json')) installIn('.', 'repo root');
        if (changedFiles.some(f => f.startsWith('packages/mcp-server/'))) installIn('packages/mcp-server', 'mcp-server');
        return {
          installed: true,
          fromCommit: status.currentCommit,
          toCommit: status.remoteCommit,
          fromVersion: status.currentVersion,
          toVersion: status.remoteVersion,
          npmInstalls,
          restartRequired: true,
          note: 'Code on disk is updated, but this running process is still executing the old code — restart/reconnect the MCP server (reload it in Claude Code, or restart Claude Desktop) to actually run the new version.',
        };
      } finally {
        updateInProgress = false;
      }
    },
  },
  {
    name: 'reinstall_connector',
    description: "Relaunch the \"Click to install Claude Connector.mcpb\" file via the OS's own file handler, the same action as a person double-clicking it themselves, so a person doesn't have to go find it. Use this when a version mismatch (compare the mcpServerVersion this server reports at connect time against the plugin build's own expected version) or a missing tool/skill means the installed .mcpb is behind what this codebase now ships. Only works when this server is running from a git checkout or the unpacked Chrome extension folder — i.e. NOT when Claude Desktop is already running it from its own installed-extension storage, since there's no local copy of the .mcpb to relaunch there. Defaults to dryRun:true (locates the file and reports it, changes nothing). This does not silently install anything either way: Claude Desktop still shows its own confirmation dialog that only the person can click through.",
    inputSchema: {
      type: 'object',
      properties: {
        dryRun: { type: 'boolean', description: 'Default true. Set false only after the user has said yes to relaunching the installer.' },
      },
      additionalProperties: false,
    },
    handler: ({ dryRun = true } = {}) => {
      const mcpbPath = findReinstallableMcpb();
      if (!mcpbPath) {
        return {
          opened: false,
          reason: 'No local copy of the .mcpb found next to this running server — this looks like it\'s running from Claude Desktop\'s own installed-extension storage, not from a git checkout or the unpacked Chrome folder.',
          manualSteps: [
            'In Claude Desktop: Settings → Extensions → find "NiCE Designer Suite" → remove it, then re-add it from the original .mcpb file.',
            'Or: locate the "Click to install Claude Connector.mcpb" file wherever it was originally downloaded/unpacked (often the Chrome extension\'s own root folder) and double-click it again.',
          ],
        };
      }
      if (dryRun) return { opened: false, dryRun: true, mcpbPath, note: 'Would relaunch this file via the OS default-app handler — Claude Desktop then shows its own install/update confirmation dialog.' };
      openWithOsHandler(mcpbPath);
      return {
        opened: true,
        mcpbPath,
        note: 'Opened the connector file — check Claude Desktop for an install/update confirmation dialog and accept it there to finish. This running server process still needs a restart/reconnect afterward to pick up the new version, same as install_update.',
      };
    },
  },
  {
    name: 'export_design_tokens',
    description: 'Return the color / text / spacing / radius token palettes for a design system.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        system: SYSTEM_ENUM,
        mode: { type: 'string', enum: ['light', 'dark'] },
      },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: async ({ target, system, mode }) => {
      const msgs = await sendRequest(target, { type: 'PREFETCH_TOKENS', system, mode });
      // The palettes arrive as separate messages for every system. Return the
      // requested system as one object, as text so the result cap (which exists
      // for issue lists) never cuts the very list this tool is for.
      const pick = (type) => {
        const m = Array.isArray(msgs) ? msgs.find(x => x && x.type === type && (!x.system || x.system === system)) : null;
        return m && Array.isArray(m.entries) ? m.entries : [];
      };
      const out = { system, colors: pick('TOKEN_PALETTE'), text: pick('TEXT_TOKEN_PALETTE'), spacing: pick('SPACING_PALETTE'), radius: pick('RADIUS_PALETTE') };
      if (!out.colors.length && !out.text.length) return msgs;
      return { __text: true, text: JSON.stringify(out) };
    },
  },
  {
    name: 'run_full_audit',
    description: 'Run the full audit (colors, text, components, spacing, accessibility) and return the combined AuditReport. The report now includes per-category totals (totalColorPaints, totalTextNodes, totalComponentNodes, totalVariableProps) so you can show "X/Y" compliance and compute a meaningful design score on moderately-bad files. Cross-system bindings (Lyra token applied in SOL mode and vice versa) are flagged authoritatively via library variable key membership, not just naming convention. Text issues match font family + size + weight, so an Inter row in SOL mode surfaces as wrong-system with sol/heading/* as the suggested target.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, system: SYSTEM_ENUM },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: async ({ target, system }) => {
      const t = resolveTarget(target);
      const msgs = await sendRequest(t, { type: 'RUN_AUDIT_REPORT', system });
      const report = extractAuditReport(msgs);
      const clients = await buildClientsHeader();
      const body = summarizeAudit(report, system, t);
      const summary = clients ? `${clients}\n\n${body}` : body;
      return richResult(summary, { target: t, system, report, raw: msgs }, gaugeSvg(report, system, t));
    },
  },
  {
    name: 'audit_colors',
    description: 'Scan the current selection / page for color fills and strokes. Each item is classified as on-token (bound to current-system variable), wrong-system (bound to the OTHER system\'s variable, detected via library variable key membership), or off-token (raw color, no binding). Items carry isExact / wrongSystem / boundTokenName fields you can use to triage.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        mode: { type: 'string', enum: ['light', 'dark'] },
      },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system, mode }) =>
      runDomainAudit('colors', target, system, { type: 'PREVIEW_COLORS', system, mode }),
  },
  {
    name: 'audit_text_styles',
    description: 'Scan text nodes for typography that does not match a token. Matching is family + size + weight aware: an Inter 16/500 node in SOL mode is now correctly flagged as wrong-system (since Lyra owns Inter) and the suggested token is the role-equivalent SOL token (e.g. lyra/heading/md → sol/heading/md). Items where the family is not in the current system at all are also flagged as wrong-system.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, system: SYSTEM_ENUM },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system }) =>
      runDomainAudit('text', target, system, { type: 'PREVIEW_TEXT_STYLES', system }),
  },
  {
    name: 'audit_spacing',
    description: 'Scan padding / gap / margin values for non-token spacing. Reports include items where the value matches a token but the property is NOT bound to a variable, AND items bound to the OTHER system\'s variable (cross-system, detected via library variable key membership). Mirrors what the Variables tab in the UI surfaces.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, system: SYSTEM_ENUM },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system }) =>
      runDomainAudit('spacing', target, system, { type: 'PREVIEW_SPACING', system }),
  },
  {
    name: 'audit_radius',
    description: 'Scan corner radius values for non-token radii. Same dual-detection as audit_spacing: matches that aren\'t bound, and bindings from the wrong system. For unified corner radius, the audit now correctly reads the binding from the topLeftRadius slot (Figma stores per-corner; the audit was previously looking at the unbindable cornerRadius slot).',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, system: SYSTEM_ENUM },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system }) =>
      runDomainAudit('radius', target, system, { type: 'PREVIEW_RADIUS', system }),
  },
  {
    name: 'audit_components',
    description: 'Find instances from the wrong design system and suggest 1:1 replacements.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, system: SYSTEM_ENUM },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system }) =>
      runDomainAudit('components', target, system, { type: 'RUN_COMPONENT_AUDIT', system }),
  },
  {
    name: 'audit_accessibility',
    description: 'Run the accessibility scan (contrast, touch targets, ARIA, alt text, heading hierarchy, etc).',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM },
      required: ['target'],
      additionalProperties: false,
    },
    handler: ({ target }) =>
      runDomainAudit('a11y', target, null, { type: 'RUN_ACCESSIBILITY_SCAN' }),
  },
  {
    name: 'convert_colors',
    description: 'Apply color tokens from the given overrides list to the selection. Respects dryRun (default true) which just re-runs the preview.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        system: SYSTEM_ENUM,
        mode: { type: 'string', enum: ['light', 'dark'] },
        overrides: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              nodeId: { type: 'string' },
              property: { type: 'string', enum: ['fill', 'stroke'] },
              fillIndex: { type: 'number' },
              tokenName: { type: 'string' },
            },
            required: ['nodeId', 'property', 'fillIndex', 'tokenName'],
            additionalProperties: false,
          },
        },
        dryRun: { type: 'boolean', default: true },
      },
      required: ['target', 'system', 'overrides'],
      additionalProperties: false,
    },
    handler: ({ target, system, mode, overrides, dryRun = true }) => {
      if (dryRun) return runDomainAudit('colors', target, system, { type: 'PREVIEW_COLORS', system, mode });
      return summarizeDomainFix('colors', target, system, { type: 'PREVIEW_COLORS', system, mode },
        t => sendRequest(t, { type: 'CONVERT_COLORS', system, overrides, mode, skipPreview: true }));
    },
  },
  {
    name: 'convert_text_styles',
    description: 'Apply typography tokens to the given text nodes (or all eligible text nodes). Dry-run by default.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeIds: { type: 'array', items: { type: 'string' } },
        skipNodeIds: { type: 'array', items: { type: 'string' } },
        dryRun: { type: 'boolean', default: true },
      },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system, nodeIds, skipNodeIds, dryRun = true }) => {
      if (dryRun) return runDomainAudit('text', target, system, { type: 'PREVIEW_TEXT_STYLES', system });
      return summarizeDomainFix('text', target, system, { type: 'PREVIEW_TEXT_STYLES', system },
        t => sendRequest(t, { type: 'CONVERT_TEXT_STYLES', system, nodeIds, skipNodeIds, skipPreview: true }));
    },
  },
  {
    name: 'fix_spacing',
    description: 'Bind spacing tokens to non-token spacing values. Dry-run by default.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeIds: { type: 'array', items: { type: 'string' } },
        dryRun: { type: 'boolean', default: true },
      },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system, nodeIds, dryRun = true }) => {
      if (dryRun) return runDomainAudit('spacing', target, system, { type: 'PREVIEW_SPACING', system });
      return summarizeDomainFix('spacing', target, system, { type: 'PREVIEW_SPACING', system },
        t => sendRequest(t, { type: 'FIX_SPACING', system, nodeIds, skipPreview: true }));
    },
  },
  {
    name: 'fix_radius',
    description: 'Bind radius tokens to non-token corner radii. Dry-run by default.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeIds: { type: 'array', items: { type: 'string' } },
        dryRun: { type: 'boolean', default: true },
      },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system, nodeIds, dryRun = true }) => {
      if (dryRun) return runDomainAudit('radius', target, system, { type: 'PREVIEW_RADIUS', system });
      return summarizeDomainFix('radius', target, system, { type: 'PREVIEW_RADIUS', system },
        t => sendRequest(t, { type: 'FIX_RADIUS', system, nodeIds, skipPreview: true }));
    },
  },
  {
    name: 'convert_component',
    description: 'Swap a single component instance for its equivalent in the target design system.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeId: { type: 'string' },
        targetName: { type: 'string' },
      },
      required: ['target', 'system', 'nodeId', 'targetName'],
      additionalProperties: false,
    },
    handler: ({ target, system, nodeId, targetName }) =>
      sendRequest(target, { type: 'CONVERT_COMPONENT', nodeId, targetName, system }),
  },
  {
    name: 'fix_accessibility',
    description: 'Apply an automated fix for a specific accessibility issue on a node.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        nodeId: { type: 'string' },
        issueType: { type: 'string' },
        dryRun: { type: 'boolean', default: true },
      },
      required: ['target', 'nodeId', 'issueType'],
      additionalProperties: false,
    },
    handler: ({ target, nodeId, issueType, dryRun = true }) => {
      if (dryRun) return runDomainAudit('a11y', target, null, { type: 'RUN_ACCESSIBILITY_SCAN' });
      return summarizeDomainFix('a11y', target, null, { type: 'RUN_ACCESSIBILITY_SCAN' },
        t => sendRequest(t, { type: 'FIX_ACCESSIBILITY', nodeId, issueType, skipPreview: true }));
    },
  },
  {
    name: 'generate_multi_system',
    description: 'Figma: duplicate the current selection and convert the copy to the target design system. Returns the new frame id.',
    inputSchema: {
      type: 'object',
      properties: { targetSystem: SYSTEM_ENUM },
      required: ['targetSystem'],
      additionalProperties: false,
    },
    handler: ({ targetSystem }) =>
      sendRequest('figma', { type: 'GENERATE_MULTI_SYSTEM', targetSystem }),
  },
  {
    name: 'convert_mode',
    description: 'Convert the selection to light or dark mode of the given system.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        mode: { type: 'string', enum: ['light', 'dark'] },
      },
      required: ['target', 'system', 'mode'],
      additionalProperties: false,
    },
    handler: ({ target, system, mode }) =>
      sendRequest(target, { type: mode === 'dark' ? 'CONVERT_DARK_MODE' : 'CONVERT_LIGHT_MODE', system }),
  },
  {
    name: 'extract_dev_details',
    description: 'Return dev-handoff details (size, fills, strokes, typography, auto-layout, CSS) for the current selection.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM },
      required: ['target'],
      additionalProperties: false,
    },
    handler: ({ target }) => sendRequest(target, { type: 'GET_DEV_DETAILS' }),
  },
  {
    name: 'extract_all_css',
    description: 'Return CSS for every node in the current scope as a single document.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM },
      required: ['target'],
      additionalProperties: false,
    },
    handler: ({ target }) => sendRequest(target, { type: 'GET_ALL_CSS' }),
  },
  {
    name: 'extract_token_css',
    description: 'Return the active design system\'s tokens as a :root { --token: value } CSS block.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, system: SYSTEM_ENUM },
      required: ['target', 'system'],
      additionalProperties: false,
    },
    handler: ({ target, system }) => sendRequest(target, { type: 'GET_TOKEN_CSS', system }),
  },
  {
    name: 'undo_last_conversion',
    description: 'Undo the most recent color conversion (snapshot-based, plugin-local). Deprecated in favor of `revert_to_history_index` against the index returned by `get_conversion_history` — kept working for backward compatibility.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM },
      required: ['target'],
      additionalProperties: false,
    },
    handler: ({ target }) => sendRequest(target, { type: 'UNDO_COLORS' }),
  },
  {
    name: 'get_conversion_history',
    description: 'Figma: list the full multi-step conversion/fix history (colors, text styles, spacing, radius, components, accessibility, mode) as an ordered stack, newest last.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM },
      required: ['target'],
      additionalProperties: false,
    },
    handler: ({ target }) => sendRequest(target, { type: 'GET_HISTORY' }),
  },
  {
    name: 'revert_to_history_index',
    description: 'Figma: revert the history entry at `index` (from `get_conversion_history`) and everything applied after it, restoring each touched node to its pre-apply state and truncating the history stack to `index`.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, index: { type: 'integer', minimum: 0 } },
      required: ['target', 'index'],
      additionalProperties: false,
    },
    handler: ({ target, index }) => sendRequest(target, { type: 'REVERT_TO_INDEX', index }),
  },
  {
    name: 'focus_node',
    description: 'Scroll/zoom to a node (Figma) or highlight an element (Chrome) by id/selector.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM, nodeId: { type: 'string' } },
      required: ['nodeId'], additionalProperties: false,
    },
    handler: ({ target, nodeId }) => sendRequest(target, { type: 'FOCUS_NODE', nodeId }),
  },
  {
    name: 'scan_variables',
    description: 'Figma: list variables from the given design system library that are bound into the current file.',
    inputSchema: {
      type: 'object',
      properties: { system: SYSTEM_ENUM },
      required: ['system'], additionalProperties: false,
    },
    handler: ({ system }) => sendRequest('figma', { type: 'SCAN_VARIABLES', system }),
  },
  {
    name: 'start_inspect',
    description: 'Chrome only: enter element-picker mode so the next click on the page becomes the inspected target.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: () => sendRequest('chrome', { type: 'START_INSPECT' }),
  },
  {
    name: 'stop_inspect',
    description: 'Chrome only: exit element-picker mode.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: () => sendRequest('chrome', { type: 'STOP_INSPECT' }),
  },
  {
    name: 'list_tabs',
    description: 'Chrome only: list every open tab (id, title, URL, which one is active). Use before switch_tab to find the tab to work on.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: async () => {
      const msgs = await sendRequest('chrome', { type: 'LIST_TABS' });
      const hit = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'TABS_RESULT') : null;
      if (!hit) {
        const err = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'ERROR') : null;
        throw new Error(err?.message || 'No tab list returned by chrome.');
      }
      return { activeTabId: hit.activeTabId, tabs: hit.tabs };
    },
  },
  {
    name: 'switch_tab',
    description: 'Chrome only: make a different tab the active one so every audit, conversion and screenshot targets it. Pass tabId, urlContains (first tab whose URL contains the text), or url (activates a tab on that exact URL, or opens it in a new tab and waits for it to load). Works for Claude design links: audits then scope to the embedded design and leave out the Claude interface.',
    inputSchema: {
      type: 'object',
      properties: {
        tabId: { type: 'number', description: 'Tab id from list_tabs.' },
        urlContains: { type: 'string', description: 'Switch to the first tab whose URL contains this text.' },
        url: { type: 'string', description: 'http(s) URL. Activates a tab already on it, otherwise opens it.' },
      },
      additionalProperties: false,
    },
    handler: async ({ tabId, urlContains, url }) => {
      if (tabId === undefined && !urlContains && !url) throw new Error('Pass tabId, urlContains or url.');
      const msgs = await sendRequest('chrome', { type: 'SWITCH_TAB', tabId, urlContains, url });
      const hit = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'TABS_RESULT') : null;
      if (!hit) {
        const err = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'ERROR') : null;
        throw new Error(err?.message || 'Tab switch returned nothing.');
      }
      return { message: hit.message, activeTabId: hit.activeTabId, claudeDesignPage: !!hit.designFrame, tabs: hit.tabs };
    },
  },
  {
    name: 'get_component_api',
    description: 'The production API of real Lyra/SOL components, for writing code a developer can merge: the React component names (for example SOLButton), the live props with types, defaults and options as the Storybook documents them, the Angular selector, and real usage examples from the stories. Use it to write production-API code in a handoff, never to guess a prop. Call get_component_kit for the look (markup and CSS); call this for the code. The React package import path is not recorded in the Storybook, so the code uses a clearly marked placeholder import that the developer replaces.',
    inputSchema: {
      type: 'object',
      properties: {
        components: { type: 'array', items: { type: 'string' }, description: 'Component names, for example ["Button", "Tabs", "Text Input"].' },
        examples: { type: 'number', description: 'Usage examples per component (default 2).' },
      },
      required: ['components'],
      additionalProperties: false,
    },
    handler: async ({ components, examples }) => {
      const dir = path.join(skillDir('lyra-prototyping'), 'references', 'kit');
      let kit;
      try { kit = JSON.parse(fs.readFileSync(path.join(dir, 'kit.json'), 'utf8')); }
      catch { return { __text: true, text: 'The component kit is not in this connector build. Update the connector.' }; }
      const names = Object.keys(kit.components);
      const norm = (x) => String(x).toLowerCase().replace(/[^a-z0-9]/g, '');
      const refDir = path.join(skillDir('lyra-prototyping'), 'references', 'components');
      let pkg = { name: null, verified: false, guess: '@niceltd/sol-react' };
      try { pkg = { ...pkg, ...JSON.parse(fs.readFileSync(path.join(skillDir('lyra-prototyping'), 'references', 'react-package.json'), 'utf8')) }; } catch { /* use the default */ }
      const importLine = pkg.name && pkg.verified
        ? `Import: each component has its own subpath, e.g. \`import { SOLButton } from '${pkg.name}/button';\` and \`import { SOLRadioGroup, SOLRadioButton } from '${pkg.name}/radio-button';\` (kebab-case component name, verified from the Storybook API docs). Types come from \`${pkg.typesPackage || '@niceltd/sol-shared'}\`. Do not import from the bare package root.`
        : `Import: the React package path is not recorded in the Storybook and has not been verified. Write \`import { SOLButton } from '<SOL React package>';\` and mark it \`// CONFIRM:\`. The Storybook project is \`sol-react\`, so it is likely \`${pkg.guess}\`: unverified. The developer's repo has the real path.`;
      const out = ['# Production API for real Lyra/SOL components', '', importLine + ' Angular components import from `@niceltd/sol-angular/<component>`.', ''];
      const n = Number.isFinite(examples) ? examples : 2;
      for (const raw of components) {
        const hit = names.find(x => norm(x) === norm(raw)) || names.find(x => norm(x).startsWith(norm(raw)));
        if (!hit) { out.push(`## ${raw}`, '', 'Not in the kit: a gap. Say so in the gap log; do not invent an API.', ''); continue; }
        const c = kit.components[hit];
        out.push(`## ${hit}`, '', `React: ${c.reactNames && c.reactNames.length ? c.reactNames.map(x => '`' + x + '`').join(', ') : 'see the usage examples'}`);
        let selector = '';
        try {
          const ref = fs.readFileSync(path.join(refDir, `${hit.replace(/[^A-Za-z0-9]+/g, '-')}.md`), 'utf8');
          selector = (ref.match(/Angular \| [^\n]*selector `([^`]+)`/) || [])[1] || '';
        } catch { /* reference file missing */ }
        if (selector) out.push(`Angular selector: \`${selector}\``);
        out.push('');
        if (c.props && c.props.length) {
          out.push('| Prop | Type | Default | Description |', '| --- | --- | --- | --- |');
          for (const p of c.props) out.push(`| \`${p.name}\` | ${String(p.type || '').replace(/\|/g, '\\|')}${p.options && p.options.length ? ` (${p.options.join(', ')})` : ''} | ${p.default || ''} | ${String(p.description || '').replace(/\n/g, ' ').replace(/\|/g, '\\|')} |`);
          out.push('');
        } else out.push('No live prop table was captured for this component: use the usage examples and the reference file, and mark any prop you are unsure of for the developer to confirm.', '');
        // The bundled reference has the fuller React prop table for many components; it can be older than the live Storybook.
        try {
          const ref = fs.readFileSync(path.join(refDir, `${hit.replace(/[^A-Za-z0-9]+/g, '-')}.md`), 'utf8');
          const sec = ref.match(/## React props\n([\s\S]*?)(?=\n## )/);
          if (sec) out.push('Full React props from the bundled reference (may be older than the live list above; confirm anything you rely on):', '', sec[1].trim(), '');
        } catch { /* reference file missing */ }
        const withSource = c.stories.filter(st => st.source).slice(0, n);
        for (const st of withSource) out.push(`Example (${st.group ? st.group + ' / ' : ''}${st.name}):`, '```tsx', st.source.trim().replace(/^story\(([\s\S]*)\)$/, '$1'), '```', '');
      }
      return { __text: true, text: out.join('\n') };
    },
  },
  {
    name: 'check_acceptance',
    description: 'Check a running page against the handoff acceptance gates and say ACCEPTED or NOT ACCEPTED, gate by gate. A developer runs this on their implementation of a handoff; a PM runs it on a prototype. Gates: the Lyra app header is present, every element that is not a real component is labeled, at least one real component is used, the overall score meets the minimum, there are no accessibility errors, and the layout is clean. Read-only: it changes nothing on the page.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        minScore: { type: 'number', description: 'Minimum overall score (default 95).' },
        header: { type: 'boolean', description: 'Require the app header (default true). Set false for a component, dialog or embedded view that has no page header.' },
      },
      required: ['target'],
      additionalProperties: false,
    },
    handler: async ({ target, minScore, header }) => {
      const t = resolveTarget(target);
      const msgs = await sendRequest(t, { type: 'RUN_AUDIT_REPORT', system: 'lyra' });
      const report = extractAuditReport(msgs);
      if (!report) throw new Error('No audit data came back. Open the page with switch_tab first.');
      const min = Number.isFinite(minScore) ? minScore : 95;
      const cc = report.componentCoverage || {};
      const lh = report.layoutHealth || {};
      const sh = report.appShell || {};
      const a11yErrors = (report.accessibilityIssues || []).filter(i => i.severity === 'error').length;
      const gates = [
        ['App header present', header === false ? true : !!sh.header, header === false ? 'not required' : (sh.header ? 'present' : 'missing')],
        ['Every non-real element is labeled', (cc.unlabeledHandBuilt || 0) === 0, `${cc.unlabeledHandBuilt || 0} unlabeled`],
        ['Real components are used', (cc.realUnits ?? cc.realComponents ?? 0) > 0, `${cc.realUnits ?? cc.realComponents ?? 0} real, ${cc.fallbackUnits ?? 0} fallback, ${cc.handBuiltUnits ?? 0} labeled hand-built`],
        [`Overall score at least ${min}`, (report.score ?? 0) >= min, `${report.score}`],
        ['No accessibility errors', a11yErrors === 0, `${a11yErrors} errors, ${(report.accessibilityIssues || []).length} issues`],
        ['Layout is clean', (lh.problems || 0) === 0, `${lh.problems || 0} problems`],
      ];
      const ok = gates.every(g => g[1]);
      const lines = [`## ${ok ? 'ACCEPTED' : 'NOT ACCEPTED'}`, '', '| Gate | Result | Detail |', '| --- | --- | --- |', ...gates.map(g => `| ${g[0]} | ${g[1] ? 'PASS' : 'FAIL'} | ${g[2]} |`), '', `Categories: colors ${(report.colorIssues || []).length}, text ${(report.textIssues || []).length}, spacing ${(report.spacingIssues || []).length}, radius ${(report.radiusIssues || []).length} issues.`, '_Passing means the implementation matches the design system. It does not prove the behavior is right: that is the developer\'s review._'];
      return { __text: true, text: lines.join('\n') };
    },
  },
  {
    name: 'get_component_kit',
    description: 'The source of real Lyra components. Returns the REAL markup (class names and all), usage code and the exact CSS for the components you name, captured from the SOL/Lyra Storybook in the Lyra theme and shipped inside this connector. Nothing to install, no registry, no VPN, no repo. Build prototypes, Claude Design files and artifacts from it: put data-theme="lyra" on <html>, include the returned base CSS and component CSS, then use the markup unchanged. Call with no components to list what is available. Use the real class names exactly: the audit recognizes real components by their sol-* classes.',
    inputSchema: {
      type: 'object',
      properties: {
        components: { type: 'array', items: { type: 'string' }, description: 'Component names from the list, for example ["Button", "Tabs", "Text Input"]. Omit to list every component.' },
        stories: { type: 'number', description: 'How many example stories to include per component (default 4, 0 for all).' },
        patterns: { type: 'array', items: { type: 'string' }, description: 'NiCE Designer fallback patterns for what the Storybook has no component for: app-shell (the Lyra suite shell: header, left rail and page panel, which EVERY prototype starts with), app-switcher, filter-toolbar, kpi-strip, stat, status-pill, data-table, empty-state. Page templates (list, detail, form, dashboard, settings) are in get_skill({ id: "lyra-prototyping", file: "references/templates/<name>-page.md" }). Always label them data-nds-source="fallback" (they are not real components).' },
        story: { type: 'array', items: { type: 'string' }, description: 'Fetch specific stories by name (substring, case-insensitive), for example ["Warning", "Button States"], whatever their position. Every component response lists all its story names so you can ask for the one you need.' },
        css: { type: 'boolean', description: 'Include the CSS (default true). Set false when you only need markup and usage.' },
        outputDir: { type: 'string', description: 'Absolute folder to write lyra-kit.css into. Large stylesheets are written to a file automatically (default ~/.nice-designer/kit/) instead of being returned inline.' },
      },
      additionalProperties: false,
    },
    handler: async ({ components, stories, story, patterns, css, outputDir }) => {
      const dir = path.join(skillDir('lyra-prototyping'), 'references', 'kit');
      let kit;
      try { kit = JSON.parse(fs.readFileSync(path.join(dir, 'kit.json'), 'utf8')); }
      catch { return { __text: true, text: 'The component kit is not in this connector build. Update the connector (or run npm run gen:lyra-kit and rebuild if you are on a dev checkout).' }; }
      const names = Object.keys(kit.components);
      const patternDir = path.join(skillDir('lyra-prototyping'), 'references', 'patterns');
      const patternNames = ['app-shell', 'app-switcher', 'filter-toolbar', 'kpi-strip', 'stat', 'status-pill', 'data-table', 'empty-state'];
      const wantPatterns = Array.isArray(patterns) ? patterns.filter(x => patternNames.includes(x)) : [];
      if ((!Array.isArray(components) || components.length === 0) && !wantPatterns.length) {
        return { __text: true, text: `Lyra component kit, generated ${kit.generated}: ${names.length} components, ${kit.storyCount} stories.\n\n` + names.map(n => `- ${n} (${kit.components[n].stories.length} stories)`).join('\n') + '\n\nFallback patterns for what the Storybook lacks (NOT real components, label them data-nds-source="fallback"): app-shell (the Lyra suite shell: the header every prototype starts with), app-switcher, filter-toolbar, kpi-strip, stat, status-pill, data-table, empty-state. Ask with get_component_kit({ patterns: [...] }).\n\nCall get_component_kit({ components: [...] }) for markup, usage and CSS.' };
      }
      const byLower = new Map(names.map(n => [n.toLowerCase().replace(/[^a-z0-9]/g, ''), n]));
      const picked = [];
      const missing = [];
      for (const raw of (Array.isArray(components) ? components : [])) {
        const key = String(raw).toLowerCase().replace(/[^a-z0-9]/g, '');
        const hit = byLower.get(key) || names.find(n => n.toLowerCase().replace(/[^a-z0-9]/g, '').startsWith(key));
        if (hit) { if (!picked.includes(hit)) picked.push(hit); } else missing.push(raw);
      }
      if (!picked.length && !wantPatterns.length) return { __text: true, text: `No component matches ${(components || []).join(', ')}. Available: ${names.join(', ')}.\nA need with no match is a gap: name it, do not draw a look-alike and call it Lyra.` };
      const limit = stories === 0 ? Infinity : (Number.isFinite(stories) ? stories : 4);
      const needs = [...new Set(picked.flatMap(n => kit.components[n].needs))];
      const wanted = Array.isArray(story) ? story.map(x => String(x).toLowerCase()) : [];
      const chooseStories = (n) => {
        const all = kit.components[n].stories;
        if (wanted.length) return all.filter(st => wanted.some(w => `${st.group} ${st.name}`.toLowerCase().includes(w)));
        return all.slice(0, limit);
      };
      const shown = picked.flatMap(chooseStories);
      const out = [];
      out.push(`# Real Lyra components from the NiCE Designer kit (${kit.generated})`, '');
      out.push('Rules: put `data-theme="lyra"` on `<html>`. The Lyra font is bundled with the CSS. Include the CSS below (only the tokens and rules these components use), then use the markup UNCHANGED, with its class names. Wire behavior (open and close, selection) in your own code from the usage. Do not restyle a component and do not rename its `sol-*` classes: that is how the audit counts it as a real component.', '');
      if (missing.length) out.push(`Not in the kit (a gap, do not fake it): ${missing.join(', ')}.`, '');
      if (css !== false) {
        const readP = (f) => { try { return fs.readFileSync(path.join(patternDir, f), 'utf8'); } catch { return ''; } };
        const patternMarkup = wantPatterns.map(n => readP(`${n}.html`)).join('\n');
        const built = kitBuildCss(dir, needs, shown.map(x => x.html).join('\n') + '\n' + patternMarkup, wantPatterns.length ? readP('patterns.css') : '');
        const cssText = [built.tokens, built.shared, ...built.components.map(c => `/* ${c.name} */${c.css}`)].join('\n');
        // Big stylesheets go to a file, not into the conversation: a prototype or
        // artifact references the file (an artifact publishes it as a supporting
        // file) and Claude never has to paste 100 KB of CSS back out.
        if (outputDir || cssText.length > 45000) {
          const target = path.resolve(outputDir || path.join(os.homedir(), '.nice-designer', 'kit'));
          fs.mkdirSync(target, { recursive: true });
          const file = path.join(target, 'lyra-kit.css');
          try { fs.cpSync(path.join(dir, 'fonts'), path.join(target, 'fonts'), { recursive: true }); } catch { /* fonts are optional */ }
          fs.writeFileSync(file, `/* Lyra kit CSS for: ${picked.join(', ')}. NiCE Designer ${kit.generated}. Real component styles: do not edit. */\n${cssText}\n`);
          out.push('## CSS', '', `Written to \`${file}\` (${Math.round(cssText.length / 1024)} KB, tokens first, then each component; the Lyra font is in \`fonts/\` beside it). Link it as \`<link rel="stylesheet" href="lyra-kit.css">\` (for an artifact, publish it as a supporting file beside the page), or copy both beside your page (for an artifact, publish \`fonts/\` too). Do not paste it into the conversation.`, '');
        } else {
          out.push('## CSS (one block, in this order)', '', '```css', cssText, '```', '');
        }
      }
      const classesInCss = (sheetNames) => {
        const set = new Set();
        for (const sn of sheetNames) {
          try { for (const m of fs.readFileSync(path.join(dir, 'css', `${sn}.css`), 'utf8').matchAll(/\.(sol-[\w-]+)/g)) set.add(m[1]); } catch { /* sheet missing */ }
        }
        return set;
      };
      const body = [];
      const index = [];
      for (const n of picked) {
        const c = kit.components[n];
        const chosen = chooseStories(n);
        const inMarkup = new Set();
        for (const st of c.stories) for (const m of st.html.matchAll(/class="([^"]*)"/g)) for (const t of m[1].split(/\s+/)) if (t.startsWith('sol-')) inMarkup.add(t);
        const cssOnly = [...classesInCss(c.needs.filter(x => x !== 'Tooltip' && x !== 'Icon'))].filter(x => !inMarkup.has(x)).sort();
        const names = c.stories.map(st => `${st.group ? st.group + ' / ' : ''}${st.name}`);
        const head = [`## ${n}`, '', `Real classes: ${c.classes.slice(0, 24).map(x => '`' + x + '`').join(', ')}`, `All stories (${c.stories.length}): ${names.join(' | ')}`];
        if (cssOnly.length) head.push(`Also defined in the CSS but not shown in any story (variants and states you can reach by adding the class): ${cssOnly.slice(0, 30).map(x => '`' + x + '`').join(', ')}`);
        // A variant is usually a sibling of a class that IS in the markup (sol-inline-notification-info
        // vs -warning): say which one to swap, so the variant can be built from a real story's markup.
        const swaps = [];
        for (const x of cssOnly) {
          const stem = x.replace(/-[a-z0-9]+$/, '');
          const sib = [...inMarkup].find(m => m.replace(/-[a-z0-9]+$/, '') === stem && m !== x);
          const VARIANT_WORDS = /-(info|warning|error|success|critical|primary|secondary|tertiary|neutral|small|medium|large|sm|md|lg|xl|default|subtle|strong)$/;
          if (stem.includes('-') && sib && VARIANT_WORDS.test(x) && VARIANT_WORDS.test(sib)) swaps.push(`${'`' + sib + '`'} -> ${'`' + x + '`'}`);
        }
        if (swaps.length) head.push(`To build a variant no story shows, take the nearest story's real markup and swap the class: ${swaps.slice(0, 10).join(', ')}. This is still real component markup.`);
        // The attributes the CSS reacts to are how state is shown (active tab, open panel). The prototype's script sets them.
        const attrs = new Set();
        for (const sn of c.needs.filter(x => x !== 'Tooltip' && x !== 'Icon')) {
          try { for (const m of fs.readFileSync(path.join(dir, 'css', `${sn}.css`), 'utf8').matchAll(/\[((?:data|aria)-[\w-]+)(?:[~|^$*]?=["']?([^"'\]\s]+)["']?)?\]/g)) attrs.add(m[2] ? `${m[1]}="${m[2]}"` : m[1]); } catch { /* sheet missing */ }
        }
        if (attrs.size) head.push(`State attributes the CSS responds to (your script sets these, for example the active tab or an open panel): ${[...attrs].slice(0, 16).map(x => '`' + x + '`').join(', ')}`);
        head.push('');
        body.push(...head);
        index.push(...head);
        for (const st of chosen) {
          const block = [`### ${st.group ? st.group + ' / ' : ''}${st.name}`];
          if (st.source) block.push('Usage:', '```tsx', st.source.trim(), '```');
          block.push('Markup:', '```html', st.html, '```', '');
          body.push(...block);
        }
        if (!wanted.length && c.stories.length > chosen.length) body.push(`(${c.stories.length - chosen.length} more stories: pass story: ["<name>"] for a specific one, or stories: 0 for all)`, '');
      }
      if (wantPatterns.length) {
        body.push('## NiCE Designer fallback patterns', '', 'These are NOT Storybook components. They are NiCE Designer patterns built from Lyra tokens for things the Storybook lacks. Keep `data-nds-source="fallback"` on each; the audit counts them as fallback and the ledger must say so. Put real kit components inside them (Buttons, Icons, a Card).', '');
        for (const n of wantPatterns) { let m = ''; try { m = fs.readFileSync(path.join(patternDir, `${n}.html`), 'utf8'); } catch { /* missing */ } body.push(`### ${n}`, '```html', m.trim(), '```', ''); }
      }
      // Big answers go to a file, so asking for many components never overflows the
      // conversation. The reply keeps the story names and variant classes, and says where the markup is.
      const fullText = [...out, ...body].join('\n');
      if (fullText.length > 40000) {
        const target = path.resolve(outputDir || path.join(os.homedir(), '.nice-designer', 'kit'));
        fs.mkdirSync(target, { recursive: true });
        const file = path.join(target, 'lyra-kit-components.md');
        fs.writeFileSync(file, fullText);
        return { __text: true, text: [...out, '## Markup and usage', '', `Too large to return inline (${Math.round(fullText.length / 1024)} KB), so it is written to \`${file}\`. Read only the sections you need (each component is a \`## <Name>\` heading; \`grep -n '^## ' <file>\` lists them).`, '', ...index].join('\n') };
      }
      return { __text: true, text: fullText };
    },
  },
  {
    name: 'reload_tab',
    description: 'Chrome or Edge: reload a tab with the cache bypassed, so a changed script or stylesheet is really fetched, and wait for it to finish loading. Use it after you edit a prototype, instead of opening the same URL in another tab. Pass tabId, or urlContains for the first tab whose address contains that text. Audits target the active tab, so switch_tab to it afterwards if it is not already active.',
    inputSchema: {
      type: 'object',
      properties: { tabId: { type: 'number' }, urlContains: { type: 'string' } },
      additionalProperties: false,
    },
    handler: async ({ tabId, urlContains }) => {
      if (tabId === undefined && !urlContains) throw new Error('Pass tabId or urlContains.');
      const msgs = await sendRequest('chrome', { type: 'RELOAD_TAB', tabId, urlContains });
      const hit = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'TABS_RESULT') : null;
      if (!hit) { const err = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'ERROR') : null; throw new Error(err?.message || 'Reload returned nothing.'); }
      return { message: hit.message, activeTabId: hit.activeTabId };
    },
  },
  {
    name: 'close_tab',
    description: 'Chrome or Edge: close tabs. Pass tabId, or urlContains to close every tab whose address contains that text (refused if it matches more than five). Close only tabs you opened yourself, such as a prototype you served for an audit. Ask the user before closing any tab they opened.',
    inputSchema: {
      type: 'object',
      properties: { tabId: { type: 'number' }, urlContains: { type: 'string' } },
      additionalProperties: false,
    },
    handler: async ({ tabId, urlContains }) => {
      if (tabId === undefined && !urlContains) throw new Error('Pass tabId or urlContains.');
      const msgs = await sendRequest('chrome', { type: 'CLOSE_TAB', tabId, urlContains });
      const hit = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'TABS_RESULT') : null;
      if (!hit) { const err = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'ERROR') : null; throw new Error(err?.message || 'Close returned nothing.'); }
      return { message: hit.message, remainingTabs: (hit.tabs || []).length };
    },
  },
  {
    name: 'scroll_page',
    description: 'Chrome only: scroll the page. direction is up/down/left/right (by `amount` px, default 80% of the viewport) or top/bottom. Pass `selector` to bring one element into view instead. Finds the container that actually scrolls when the page itself does not (dashboards and design canvases). On a Claude design page it scrolls the embedded design; set inShell to scroll Claude\u2019s own interface. Returns the scroller and its position before/after.',
    inputSchema: {
      type: 'object',
      properties: {
        direction: { type: 'string', enum: ['up', 'down', 'left', 'right', 'top', 'bottom'] },
        amount: { type: 'number', description: 'Pixels. Default: 80% of the visible height/width.' },
        selector: { type: 'string', description: 'CSS selector to scroll into view (ignores direction).' },
        containerSelector: { type: 'string', description: 'Scroll this container instead of auto-detecting one.' },
        inShell: { type: 'boolean', description: 'Claude design pages: act on Claude\u2019s interface, not the design.' },
      },
      additionalProperties: false,
    },
    handler: async (args) => {
      const msgs = await sendRequest('chrome', { type: 'SCROLL_PAGE', ...args });
      return pageActionResult(msgs, 'scroll');
    },
  },
  {
    name: 'click_element',
    description: 'Chrome only: click an element, by CSS `selector` or by its visible `text` (or aria-label). `index` picks among several matches. Use dryRun:true first to see what would be clicked. It refuses labels that send, spend or delete (delete, submit, publish, pay, confirm...) unless allowDestructive is true, which you set only after the user said yes. On a Claude design page it clicks inside the embedded design; set inShell to click Claude\u2019s own interface (for example its artboard picker).',
    inputSchema: {
      type: 'object',
      properties: {
        selector: { type: 'string' },
        text: { type: 'string', description: 'Visible text or aria-label of the thing to click.' },
        index: { type: 'number', description: 'Which match to click when several match (0-based).' },
        dryRun: { type: 'boolean', description: 'Report what would be clicked without clicking.' },
        allowDestructive: { type: 'boolean' },
        inShell: { type: 'boolean' },
      },
      additionalProperties: false,
    },
    handler: async (args) => {
      if (!args.selector && !args.text) throw new Error('Pass a selector or the visible text to click.');
      const msgs = await sendRequest('chrome', { type: 'CLICK_ELEMENT', ...args });
      return pageActionResult(msgs, 'click');
    },
  },
  {
    name: 'restart_hub',
    description: 'Recover the bridge when tools say nothing is connected, answer from stale code, or two copies of a client are connected. mode "reset" (default, safe): drops every connected extension/plugin session so they reconnect fresh, and re-binds the hub; this connector keeps running. mode "reload": exits this connector process so Claude Desktop can start a new one with the latest code; Claude may need a moment, or a reconnect of the connector, before tools return. Run get_diagnostics afterwards.',
    inputSchema: {
      type: 'object',
      properties: { mode: { type: 'string', enum: ['reset', 'reload'], default: 'reset' } },
      additionalProperties: false,
    },
    handler: async ({ mode }) => {
      if (mode === 'reload') {
        setTimeout(() => { void analytics.stop().finally(() => process.exit(0)); }, 400).unref();
        return { restarting: 'reload', note: 'This connector process is exiting. Wait a few seconds, then call list_targets; if tools are gone, reconnect the connector in Claude Desktop.' };
      }
      let dropped = 0;
      for (const [sid, sess] of sessions.entries()) {
        try { sess.ws.close(); } catch { /* noop */ }
        sessions.delete(sid);
        dropped++;
      }
      for (const [, p] of pending) { clearTimeout(p.timer); try { p.reject(new Error('Hub was reset.')); } catch { /* noop */ } }
      pending.clear();
      if (MODE.kind === 'proxy' && proxyWs) { try { proxyWs.close(); } catch { /* noop */ } }
      return { restarting: 'reset', mode: MODE.kind, sessionsDropped: dropped, note: 'Clients reconnect on their own within a few seconds. Call list_targets to confirm.' };
    },
  },
  {
    name: 'select_page',
    description: 'Chrome only: set the scan scope to the whole page (<body>).',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: () => sendRequest('chrome', { type: 'SELECT_PAGE' }),
  },
  {
    name: 'polish_page',
    description: 'Chrome only: toggle page-level polish overlays (dark mode, scrollbars, positional hover).',
    inputSchema: {
      type: 'object',
      properties: {
        darkMode: { type: 'boolean' },
        scrollbars: { type: 'boolean' },
        positionalHover: { type: 'boolean' },
      },
      additionalProperties: false,
    },
    handler: async ({ darkMode, scrollbars, positionalHover }) => {
      const out = [];
      if (typeof darkMode === 'boolean') out.push(await sendRequest('chrome', { type: 'POLISH_DARK_MODE', enabled: darkMode }));
      if (typeof scrollbars === 'boolean') out.push(await sendRequest('chrome', { type: 'POLISH_SCROLLBARS', enabled: scrollbars }));
      if (typeof positionalHover === 'boolean') out.push(await sendRequest('chrome', { type: 'POLISH_POSITIONAL_HOVER', enabled: positionalHover }));
      return { applied: { darkMode, scrollbars, positionalHover }, responses: out };
    },
  },
  {
    name: 'a11y_overlay',
    description: 'Chrome only: toggle accessibility overlays (small tap targets, colorblind simulation).',
    inputSchema: {
      type: 'object',
      properties: {
        tapTargets: { type: 'boolean' },
        colorblind: { type: 'string', enum: ['none', 'protanopia', 'deuteranopia', 'tritanopia'] },
      },
      additionalProperties: false,
    },
    handler: async ({ tapTargets, colorblind }) => {
      const out = [];
      if (typeof tapTargets === 'boolean') out.push(await sendRequest('chrome', { type: 'A11Y_OVERLAY_TAP_TARGETS', enabled: tapTargets }));
      if (colorblind) out.push(await sendRequest('chrome', { type: 'A11Y_OVERLAY_COLORBLIND', mode: colorblind }));
      return { applied: { tapTargets, colorblind }, responses: out };
    },
  },
  {
    name: 'sync_storybook_components',
    description: "Chrome only: sync component props/variants + screenshots into the Components section. SOL and Lyra share the same Storybook (na1.dev.nice-incontact.com/sol) and story ids — Lyra is just SOL with &globals=theme:lyra applied — and every component now has both an Angular and a React reference implementation, synced and shown together rather than behind a framework toggle. Runs as a background job in the extension — a full sync of a hundred-plus components/variants can take several minutes, so this call only starts the job and returns immediately; poll get_storybook_sync_status for progress. Default (no `components` arg) fills in whatever's missing/incomplete rather than re-scraping everything, so it's safe to call repeatedly.",
    inputSchema: {
      type: 'object',
      properties: {
        components: {
          type: 'array',
          items: { type: 'string' },
          description: 'Optional: component names to force re-sync (e.g. ["Button", "Modal"]). Omit to sync everything not yet captured.',
        },
      },
      additionalProperties: false,
    },
    handler: async ({ components } = {}) => {
      await sendRequest('chrome', { type: 'SYNC_STORYBOOK_START', components });
      return { started: true, note: 'Sync runs in the background — poll get_storybook_sync_status for progress.' };
    },
  },
  {
    name: 'get_storybook_sync_status',
    description: 'Chrome only: poll the status of a sync_storybook_components job (running/done/total/current), plus every component synced so far.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: async () => {
      const responses = await sendRequest('chrome', { type: 'GET_STORYBOOK_COMPONENTS' });
      return { responses };
    },
  },
  {
    name: 'get_audit_filters',
    description: "Read the Audit view's currently persisted filters — which categories are toggled on (colors/text/components/spacing/radius/layout/a11y) and the status filter (all/issues only/on target only/snoozed only). Filters persist across sessions and are shared with the popup UI; works for both Figma and Chrome.",
    inputSchema: { type: 'object', properties: { target: TARGET_ENUM }, additionalProperties: false },
    handler: async ({ target = 'auto' } = {}) => {
      const responses = await sendRequest(target, { type: 'GET_AUDIT_FILTERS' });
      return { responses };
    },
  },
  {
    name: 'set_audit_filters',
    description: "Change the Audit view's persisted category/status filters. Only pass the fields you want to change — omit a field to leave it as-is. Categories omitted from `categories` are turned OFF (pass the full set you want enabled). The change is saved (survives closing/reopening the app) and reflected immediately in an already-open popup.",
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        categories: {
          type: 'array',
          items: { type: 'string', enum: ['colors', 'text', 'components', 'spacing', 'radius', 'layout', 'a11y'] },
          description: 'Full set of categories that should be enabled. Omit to leave categories unchanged.',
        },
        status: {
          type: 'string',
          enum: ['all', 'issues', 'onTarget', 'snoozed'],
          description: '"issues" = not snoozed and not already on-target; "onTarget" = already compliant (components only, today); "snoozed" = ignored items only.',
        },
      },
      additionalProperties: false,
    },
    handler: async ({ categories, status, target = 'auto' } = {}) => {
      const responses = await sendRequest(target, { type: 'SET_AUDIT_FILTERS', categories, status });
      return { responses };
    },
  },
  {
    name: 'apply_css_overrides',
    description: 'Chrome only: inject (or clear) a stylesheet of selector → declarations onto the current page. Used by the artboard-to-page skill to push Figma-derived styling onto a live DOM. Rules accumulate across calls; pass clear:true to wipe and start fresh.',
    inputSchema: {
      type: 'object',
      properties: {
        rules: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              selector: { type: 'string' },
              declarations: {
                type: 'object',
                additionalProperties: { type: 'string' },
              },
            },
            required: ['selector', 'declarations'],
            additionalProperties: false,
          },
          default: [],
        },
        clear: { type: 'boolean', default: false },
      },
      additionalProperties: false,
    },
    handler: ({ rules = [], clear = false }) =>
      sendRequest('chrome', { type: 'APPLY_CSS_OVERRIDES', rules, clear }),
  },
  {
    name: 'apply_lyra_theme',
    description: 'Chrome only: re-theme the live page to Lyra the way the design system itself does it. SOL and Lyra share one component set, and every SOL component reads its colors, radii and spacing from --sol-* custom properties; Lyra is the same properties remapped. This injects the Lyra base tokens plus that remapping (taken from the real Lyra theme in the NiCE Designer kit) onto the page, so every SOL-based component, and any hand-written CSS that uses the --sol-* variables, turns Lyra at once. Changes the LIVE PAGE IN THE BROWSER ONLY (lost on refresh), so it is never a deliverable or a default: use it only if the user specifically asks for a live preview, and save a change file. Reversible with clear_css_overrides. Dry run by default. Pages that hard-code colors instead of using the variables are not affected: run the audit and convert_page_to_lyra for those.',
    inputSchema: { type: 'object', properties: { dryRun: { type: 'boolean', default: true } }, additionalProperties: false },
    handler: async ({ dryRun }) => {
      const dir = path.join(skillDir('lyra-prototyping'), 'references', 'kit');
      let base;
      try { base = fs.readFileSync(path.join(dir, 'base.css'), 'utf8').replace(/\/\*[\s\S]*?\*\//g, ''); }
      catch { throw new Error('The Lyra kit is not in this connector build. Update the connector.'); }
      const rootDecls = new Map(), themeDecls = new Map();
      for (const r of kitSplitRules(base)) {
        const sel = r.slice(0, r.indexOf('{')).trim();
        const body = r.slice(r.indexOf('{') + 1, r.lastIndexOf('}'));
        if (sel === ':root') {
          for (const [k, v] of kitDecls(body)) if (k.startsWith('--lyra-')) rootDecls.set(k, v);
        } else if (sel === '[data-theme="lyra"]') {
          for (const [k, v] of kitDecls(body)) themeDecls.set(k, v);
        }
      }
      // Lyra base and semantic tokens, then the SOL semantic names pointed at them.
      const declarations = {};
      for (const [k, v] of rootDecls) declarations[k] = v;
      for (const [k, v] of themeDecls) declarations[k] = v;
      const rules = [{ selector: 'html:root', declarations }, { selector: 'body', declarations: Object.fromEntries([...themeDecls]) }];
      const summary = { lyraTokens: rootDecls.size, solVariablesRemapped: themeDecls.size, rules: rules.length, dryRun: dryRun !== false };
      if (dryRun !== false) return { ...summary, note: 'Dry run: nothing applied. Call again with dryRun false, then run_full_audit to see what is left. clear_css_overrides undoes it.' };
      const msgs = await sendRequest('chrome', { type: 'APPLY_CSS_OVERRIDES', rules });
      const err = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'ERROR') : null;
      if (err) throw new Error(err.message);
      return { ...summary, applied: true, note: 'Lyra theme applied to the live page. Run run_full_audit next. The page font is not changed by this (the Lyra font files are not on the page): list it as a handoff item.' };
    },
  },
  {
    name: 'clear_css_overrides',
    description: 'Chrome only: remove every rule previously injected by apply_css_overrides, leaving the page untouched by the skill.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    handler: () => sendRequest('chrome', { type: 'CLEAR_CSS_OVERRIDES' }),
  },
  {
    name: 'apply_single_color',
    description: 'Apply one color to one fill/stroke on one node. Two lanes: pass tokenName to bind a design-system token (preferred), OR pass customHex (e.g. "#0a84ff") to write a raw off-token color for live-editing. Either way the plugin captures a per-row snapshot, so revert_single_color undoes it cleanly. Surgical alternative to convert_colors.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeId: { type: 'string' },
        property: { type: 'string', enum: ['fill', 'stroke'] },
        fillIndex: { type: 'number', default: 0 },
        tokenName: { type: 'string', description: 'Design-system token name (e.g. "lyra/base/color/blue/500"). Use "__custom__" with customHex for off-token live edits.' },
        customHex: { type: 'string', description: 'Raw hex like "#0a84ff" (3- or 6-digit, "#" optional). When set, the plugin skips the palette and writes this color, unbinding any prior variable. The row will surface as off-token after apply.' },
      },
      required: ['system', 'nodeId', 'property', 'tokenName'], additionalProperties: false,
    },
    handler: ({ target, system, nodeId, property, fillIndex = 0, tokenName, customHex }) =>
      sendRequest(target, { type: 'APPLY_SINGLE_COLOR', nodeId, property, fillIndex, tokenName, system, ...(customHex ? { customHex } : {}) }),
  },
  {
    name: 'apply_single_text',
    description: 'Apply one text-style token to one node, OR live-edit just the font size with customFontSize. Family-aware token matching means the suggested token only matches when the family also matches. Snapshot captured for revert_single_text.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeId: { type: 'string' },
        tokenName: { type: 'string', description: 'Typography token name (e.g. "sol/heading/md"). Use "__custom__" with customFontSize for off-token size-only edits.' },
        customFontSize: { type: 'number', description: 'Raw font size in px. When set, the plugin writes only font-size and leaves family/weight/line-height/letter-spacing as-is. Useful for "make this 18px" without changing the typeface.' },
      },
      required: ['system', 'nodeId', 'tokenName'], additionalProperties: false,
    },
    handler: ({ target, system, nodeId, tokenName, customFontSize }) =>
      sendRequest(target, { type: 'APPLY_SINGLE_TEXT', nodeId, tokenName, system, ...(typeof customFontSize === 'number' ? { customFontSize } : {}) }),
  },
  {
    name: 'apply_single_spacing',
    description: 'Bind one spacing token to one property on one node, OR live-edit a raw px value with customValue. property is a Figma field name (paddingTop / paddingBottom / paddingLeft / paddingRight / itemSpacing) for figma target, or a hyphenated CSS property (padding-top / gap / margin-top) for chrome target. Snapshot captured for revert_single_spacing.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeId: { type: 'string' },
        property: { type: 'string' },
        tokenName: { type: 'string', description: 'Spacing token name (e.g. "SOL/size/spacing/md"). Use "__custom__" with customValue for off-token raw values.' },
        customValue: { type: 'number', description: 'Raw spacing value in px. When set, unbinds any prior variable and writes this number. Row surfaces as off-token afterwards.' },
      },
      required: ['system', 'nodeId', 'property', 'tokenName'], additionalProperties: false,
    },
    handler: ({ target, system, nodeId, property, tokenName, customValue }) =>
      sendRequest(target, { type: 'APPLY_SINGLE_SPACING', nodeId, property, tokenName, system, ...(typeof customValue === 'number' ? { customValue } : {}) }),
  },
  {
    name: 'apply_single_radius',
    description: 'Bind one radius token to one corner on one node, OR live-edit a raw px value with customValue. property is "all" for unified corner radius, or "topLeft"/"topRight"/"bottomLeft"/"bottomRight" for a specific corner. The Figma plugin binds all four corners to the same variable for "all" since Figma rejects cornerRadius itself as a bindable field. Snapshot captured for revert_single_radius.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM, system: SYSTEM_ENUM,
        nodeId: { type: 'string' },
        property: { type: 'string', description: '"all" or "topLeft"/"topRight"/"bottomLeft"/"bottomRight"' },
        tokenName: { type: 'string', description: 'Radius token name. Use "__custom__" with customValue for off-token raw values.' },
        customValue: { type: 'number', description: 'Raw corner radius in px. When set, unbinds any prior variable and writes this number.' },
      },
      required: ['system', 'nodeId', 'property', 'tokenName'], additionalProperties: false,
    },
    handler: ({ target, system, nodeId, property, tokenName, customValue }) =>
      sendRequest(target, { type: 'APPLY_SINGLE_RADIUS', nodeId, property, tokenName, system, ...(typeof customValue === 'number' ? { customValue } : {}) }),
  },
  {
    name: 'revert_single_color',
    description: 'Undo one apply_single_color (token or custom hex) on a specific node/fill. Restores the exact paint that was there before — including a prior variable binding if one existed. Snapshot is in-memory and lives until the plugin reloads.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        nodeId: { type: 'string' },
        property: { type: 'string', enum: ['fill', 'stroke'] },
        fillIndex: { type: 'number', default: 0 },
      },
      required: ['nodeId', 'property'], additionalProperties: false,
    },
    handler: ({ target, nodeId, property, fillIndex = 0 }) =>
      sendRequest(target, { type: 'REVERT_SINGLE_COLOR', nodeId, property, fillIndex }),
  },
  {
    name: 'revert_single_text',
    description: 'Undo one apply_single_text (token or custom size) on a specific text node. Restores the exact font name, size, line height, letter spacing, and any prior textStyleId. In-memory snapshot, lives until plugin reload.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        nodeId: { type: 'string' },
      },
      required: ['nodeId'], additionalProperties: false,
    },
    handler: ({ target, nodeId }) =>
      sendRequest(target, { type: 'REVERT_SINGLE_TEXT', nodeId }),
  },
  {
    name: 'revert_single_spacing',
    description: 'Undo one apply_single_spacing on a specific node/property. Restores the prior numeric value AND re-binds any prior variable.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        nodeId: { type: 'string' },
        property: { type: 'string' },
      },
      required: ['nodeId', 'property'], additionalProperties: false,
    },
    handler: ({ target, nodeId, property }) =>
      sendRequest(target, { type: 'REVERT_SINGLE_SPACING', nodeId, property }),
  },
  {
    name: 'revert_single_radius',
    description: 'Undo one apply_single_radius on a specific node/corner. For property="all" it restores all four individual corner values + their prior bindings.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        nodeId: { type: 'string' },
        property: { type: 'string' },
      },
      required: ['nodeId', 'property'], additionalProperties: false,
    },
    handler: ({ target, nodeId, property }) =>
      sendRequest(target, { type: 'REVERT_SINGLE_RADIUS', nodeId, property }),
  },
  {
    name: 'convert_page_to_lyra',
    description: 'Chrome composite: audit the current page, apply colors/text/spacing/radius fixes, then re-audit and return a before/after delta with visual gauges. WARNING: this changes the LIVE PAGE IN THE BROWSER ONLY and is lost on the next refresh, and the spacing pass can break layouts. It is NOT a deliverable and NOT a default: only use it when the user specifically asks to see a live preview, say that it vanishes on refresh, and save a change file. For "convert this page to Lyra" use the lyra-page-conversion skill, which rebuilds the page and hands it off.',
    inputSchema: {
      type: 'object',
      properties: {
        applyColors: { type: 'boolean', default: true },
        applyText: { type: 'boolean', default: true },
        applySpacing: { type: 'boolean', default: true },
        applyRadius: { type: 'boolean', default: true },
        applyA11y: { type: 'boolean', default: true },
        dryRun: { type: 'boolean', default: true },
      },
      additionalProperties: false,
    },
    handler: async (args) => {
      const t = 'chrome';
      const dryRun = args.dryRun !== false;
      const before = extractAuditReport(await sendRequest(t, { type: 'RUN_AUDIT_REPORT', system: 'lyra' }));
      if (dryRun) {
        return richResult(
          summarizeAudit(before, 'lyra', t) + '\n\n_(dry-run — nothing applied)_',
          { audit: before, applied: { colors: false, text: false, spacing: false, radius: false, a11y: false }, dryRun: true },
          gaugeSvg(before, 'lyra', t),
        );
      }
      const applied = await applyAuditFixes(t, before, 'lyra', {
        applyColors: args.applyColors !== false,
        applyText: args.applyText !== false,
        applySpacing: args.applySpacing !== false,
        applyRadius: args.applyRadius !== false,
        applyA11y: args.applyA11y !== false,
      });
      const after = extractAuditReport(await sendRequest(t, { type: 'RUN_AUDIT_REPORT', system: 'lyra' }));
      return richResult(summarizeDelta(before, after, 'lyra', t), { before, after, applied }, gaugeDeltaSvg(before, after, 'lyra', t));
    },
  },
  {
    name: 'call_plugin',
    description: 'Escape hatch: send any UIMessage directly to the plugin backend. Use this for operations not covered by a named tool.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        message: { type: 'object', description: 'A UIMessage object (see src/types.ts).', additionalProperties: true },
      },
      required: ['target', 'message'],
      additionalProperties: false,
    },
    handler: ({ target, message }) => sendRequest(target, message),
  },
  {
    name: 'lyra_compliance_report',
    description: 'Composite: run every audit against Lyra and return a single consolidated report.',
    inputSchema: {
      type: 'object',
      properties: { target: TARGET_ENUM },
      required: ['target'],
      additionalProperties: false,
    },
    handler: async ({ target }) => {
      const t = resolveTarget(target);
      const msgs = await sendRequest(t, { type: 'RUN_AUDIT_REPORT', system: 'lyra' });
      const a11y = await sendRequest(t, { type: 'RUN_ACCESSIBILITY_SCAN' });
      const report = extractAuditReport(msgs);
      const clients = await buildClientsHeader();
      const body = summarizeAudit(report, 'lyra', t);
      const summary = clients ? `${clients}\n\n${body}` : body;
      return richResult(summary, { system: 'lyra', target: t, report, accessibility: a11y }, gaugeSvg(report, 'lyra', t));
    },
  },
  {
    name: 'run_ux_eval',
    description: 'UX Eval: assembles everything needed for a "10 Question UX Eval" pass/fail design review. If a Figma or Chrome target is connected, runs a live compliance + accessibility audit against it. Always echoes back the design/browser link, Jira link, and free-text context supplied by the caller, plus the 10-question prioritization framework. This tool does NOT compute a verdict — it only gathers inputs. Claude applies the framework (guided by the `ux-eval` skill) and states the feedback and pass/fail recommendation itself. Jira is pass-through only: this server never calls Jira — if the Atlassian MCP connector is connected, fetch ticket details separately and fold them into context before judging.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        system: SYSTEM_ENUM,
        designLink: { type: 'string', description: 'URL to the Figma file/frame or live browser page being evaluated. Optional, informational only — this tool does not fetch the URL.' },
        jiraLink: { type: 'string', description: 'URL or key (e.g. PROJ-123) of the related Jira ticket. Optional, pass-through only.' },
        context: { type: 'string', description: 'Free-text description or extra context supplied about the problem being solved.' },
      },
      additionalProperties: false,
    },
    handler: async ({ target, system, designLink, jiraLink, context }) => {
      const sys = system || 'lyra';
      let resolvedTarget = null;
      let auditNote = null;
      try {
        resolvedTarget = resolveTarget(target || 'auto');
      } catch (e) {
        auditNote = e.message;
      }

      let auditBlock = null;
      if (resolvedTarget) {
        try {
          const msgs = await sendRequest(resolvedTarget, { type: 'RUN_AUDIT_REPORT', system: sys });
          const a11y = await sendRequest(resolvedTarget, { type: 'RUN_ACCESSIBILITY_SCAN' });
          const report = extractAuditReport(msgs);
          auditBlock = { target: resolvedTarget, system: sys, report, accessibility: a11y };
        } catch (e) {
          auditNote = `Audit failed against ${resolvedTarget}: ${e.message}`;
        }
      }

      const lines = [];
      lines.push('### UX Eval — inputs assembled');
      lines.push('');
      lines.push(`- Design/browser link: ${designLink || '_not provided_'}`);
      lines.push(`- Jira: ${jiraLink || '_not provided_'}`);
      lines.push(`- Context: ${context || '_not provided_'}`);
      lines.push('');
      if (auditBlock?.report) {
        lines.push(summarizeAudit(auditBlock.report, sys, resolvedTarget));
      } else {
        lines.push(auditNote ? `_No live audit: ${auditNote}_` : '_No design/browser target connected — evaluate from the link, Jira ticket, and context only._');
      }
      lines.push('');
      lines.push('### 10-question framework to apply');
      lines.push('');
      lines.push(formatUxEvalFramework());

      return richResult(lines.join('\n'), {
        inputs: { designLink: designLink || null, jiraLink: jiraLink || null, context: context || null },
        audit: auditBlock,
        auditNote,
        framework: UX_EVAL_QUESTIONS,
      }, auditBlock?.report ? gaugeSvg(auditBlock.report, sys, resolvedTarget) : null);
    },
  },
  {
    name: 'score_design_review',
    description: "ADQR design review, the scoring half. Call this only after loading the `adqr-design-review` skill and judging every dimension against its rubric (get_skill({ id: 'adqr-design-review' })). You supply one band per dimension (0/2/4/6/8/10, matched to that dimension's anchor sentence, with the evidence that earned it); this tool applies ADQR's fixed rules as code, never as judgement: modality caps and exclusions, missing-context and single-screen gating, the four pillar scores (Business Alignment, Requirement Coverage, UX Experience, AI Experience; never blended), a rule-based confidence level, and the ship verdict from the weakest pillar. Returns an inline scorecard plus the full per-check evidence. Pure computation: it needs no Figma or Chrome target and changes nothing. If the input is incomplete it returns every problem at once; fix them and call again. Never re-derive or override its verdict or confidence in your reply.",
    inputSchema: {
      type: 'object',
      properties: {
        title: { type: 'string', description: 'Short name for what was reviewed, e.g. "Schedule export settings".' },
        modality: { type: 'string', enum: designReview.MODALITIES, description: 'static: screenshots or Figma frames. semi_interactive: a clickable prototype with limited real behaviour. fully_interactive: a working build or live page you could actually operate.' },
        screenCount: { type: 'integer', minimum: 1, description: 'How many distinct screens or states were judged. Under 2 excludes Flow Completeness, Consistency and the flow-state checks.' },
        sufficientContent: { type: 'boolean', description: 'False if the screens are a loading page, a prototype cover or "click to view" splash, a blank state or an error page rather than the real product UI. Forces Low confidence.' },
        contentNote: { type: 'string', description: 'One sentence on what the screens actually show.' },
        aiPresent: { type: 'boolean', description: 'Is there any AI-driven interaction anywhere in the design (suggestions, drafting, an assistant, automated decisions)? False excludes every AI Experience check as out of scope.' },
        context: {
          type: 'object',
          description: 'The product context the design is judged against. Only presence matters to the rules: an empty field excludes the checks that need it. Never invent a value to fill a gap.',
          properties: Object.fromEntries(designReview.CONTEXT_FIELDS.map((f) => [f, { type: 'string' }])),
          additionalProperties: false,
        },
        dimensions: {
          type: 'array',
          description: 'One entry per dimension you judged. Dimensions the rules exclude for this input (missing context, one screen, static input, AI not present) may be left out.',
          items: {
            type: 'object',
            properties: {
              key: { type: 'string', description: 'Dimension key from the skill\'s rubric references, e.g. "clarity", "requirement_coverage", "human_control".' },
              evidence: { type: 'string', description: 'Written before the band: what you actually saw for this check, specific enough to point at.' },
              evidenceShort: { type: 'string', description: 'One plain clause, about 12 words.' },
              evidenceTag: { type: 'string', enum: designReview.EVIDENCE_TAGS, description: 'observed: you can point at it. inferred: a reasonable conclusion from what is shown. assumed: not grounded in the screens or context.' },
              band: { type: 'integer', enum: designReview.BANDS, description: 'The one anchor that matches what you observed. Never split the difference.' },
              impact: { type: 'string', description: 'One sentence on what this means for the user or business. Never a fix.' },
              outOfScope: { type: 'boolean', description: 'AI Experience only: true when this specific concern genuinely does not apply even though AI is present.' },
            },
            required: ['key'],
            additionalProperties: false,
          },
        },
        requirementElements: {
          type: 'array',
          description: 'The requirement split into individually checkable parts, each traced to the screens. A "conflict" forces Low confidence.',
          items: {
            type: 'object',
            properties: {
              id: { type: 'string' },
              text: { type: 'string' },
              status: { type: 'string', enum: designReview.ELEMENT_STATUSES },
              evidence: { type: 'string' },
            },
            required: ['text', 'status'],
            additionalProperties: false,
          },
        },
        missingRequirements: { type: 'array', items: { type: 'string' }, description: 'Stated requirements with no UI evidence, as short phrases. Evidence, not suggestions.' },
        extraFeatures: { type: 'array', items: { type: 'string' }, description: 'Prominent features not tied to the stated requirement, as short phrases.' },
        flowRisks: {
          type: 'array',
          description: 'Required when screenCount is 2 or more: for each of the seven flow states, whether it is shown anywhere across the screens.',
          items: {
            type: 'object',
            properties: {
              key: { type: 'string', enum: designReview.RUBRIC.FLOW_RISK_CHECKS.map((c) => c.key) },
              present: { type: 'boolean' },
              evidence: { type: 'string' },
            },
            required: ['key', 'present'],
            additionalProperties: false,
          },
        },
      },
      required: ['modality', 'screenCount', 'sufficientContent', 'contentNote', 'aiPresent', 'context', 'dimensions'],
      additionalProperties: false,
    },
    handler: async (args) => {
      const report = designReview.scoreDesignReview(args);
      return richResult(designReviewSummary(report), report, designReviewSvg(report));
    },
  },
  {
    name: 'migrate_to_lyra',
    description: 'Composite: audit in Lyra then optionally apply color / text / spacing fixes. Dry-run by default.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        applyColors: { type: 'boolean', default: false },
        applyText: { type: 'boolean', default: false },
        applySpacing: { type: 'boolean', default: false },
        applyRadius: { type: 'boolean', default: false },
        applyA11y: { type: 'boolean', default: false },
        dryRun: { type: 'boolean', default: true },
      },
      required: ['target'],
      additionalProperties: false,
    },
    handler: async ({ target, applyColors, applyText, applySpacing, applyRadius, applyA11y, dryRun = true }) => {
      const t = resolveTarget(target);
      const before = extractAuditReport(await sendRequest(t, { type: 'RUN_AUDIT_REPORT', system: 'lyra' }));
      const result = { target: t, before, applied: { colors: false, text: false, spacing: false, radius: false, a11y: false } };
      if (dryRun) {
        return richResult(summarizeAudit(before, 'lyra', t) + '\n\n_(dry-run — nothing applied)_', result, gaugeSvg(before, 'lyra', t));
      }
      result.applied = await applyAuditFixes(t, before, 'lyra', {
        applyColors: !!applyColors,
        applyText: !!applyText,
        applySpacing: !!applySpacing,
        applyRadius: !!applyRadius,
        applyA11y: !!applyA11y,
      });
      const after = extractAuditReport(await sendRequest(t, { type: 'RUN_AUDIT_REPORT', system: 'lyra' }));
      result.after = after;
      return richResult(summarizeDelta(before, after, 'lyra', t), result, gaugeDeltaSvg(before, after, 'lyra', t));
    },
  },
  {
    name: 'screenshot_page',
    description: 'Capture a visual of the current view. Chrome: screenshots the visible region of the active tab. Figma: exports the current selection as PNG (or the current page if nothing is selected). Returns an inline image so Claude can see what the user is looking at.',
    inputSchema: {
      type: 'object',
      properties: {
        target: TARGET_ENUM,
        format: { type: 'string', enum: ['png', 'jpeg'], default: 'png', description: 'Chrome only — Figma always returns PNG.' },
        maxWidth: { type: 'number', description: 'Figma only — caps the exported PNG width (default 1280).' },
      },
      required: ['target'],
      additionalProperties: false,
    },
    handler: async ({ target, format, maxWidth }) => {
      const t = resolveTarget(target);
      const msgs = await sendRequest(t, { type: 'CAPTURE_SCREENSHOT', format, maxWidth });
      const hit = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'SCREENSHOT_CAPTURED' && m.dataUrl) : null;
      if (!hit) {
        const err = Array.isArray(msgs) ? msgs.find(m => m && m.type === 'ERROR') : null;
        throw new Error(err?.message || `No screenshot returned by ${t}.`);
      }
      return { __image: true, dataUrl: hit.dataUrl, mimeType: hit.mimeType || 'image/png', target: t, source: hit.source };
    },
  },
];

function extractItems(responseMsgs, type) {
  if (!Array.isArray(responseMsgs)) return [];
  const hit = responseMsgs.find(m => m && m.type === type);
  return hit && Array.isArray(hit.items) ? hit.items : [];
}

// Mirror of src/ui/index.tsx handleAuditFixAll — keep parity so MCP and UI
// produce identical re-audit deltas.
const RADIUS_PROPS = new Set(['all', 'topLeft', 'topRight', 'bottomLeft', 'bottomRight']);
const AUTOFIXABLE_A11Y = new Set([
  'missing-aria-label', 'broken-aria-describedby', 'missing-alt',
  'missing-label', 'positive-tabindex', 'icon-button-no-title', 'focus-outline-removed',
]);

async function applyAuditFixes(target, before, system, opts) {
  const { applyColors, applyText, applySpacing, applyRadius, applyA11y } = opts;
  const applied = { colors: false, text: false, spacing: false, radius: false, a11y: false };

  if (applyColors && before?.colorIssues?.length) {
    const overrides = before.colorIssues
      .filter(i => i && i.suggestedToken)
      .map(i => ({ nodeId: i.nodeId, property: i.property, fillIndex: i.fillIndex, tokenName: i.suggestedToken }));
    if (overrides.length) {
      await sendRequest(target, { type: 'CONVERT_COLORS', system, overrides, skipPreview: true });
      applied.colors = true;
    }
  }
  if (applyText && before?.textIssues?.length) {
    const nodeIds = before.textIssues.map(i => i.nodeId);
    await sendRequest(target, { type: 'CONVERT_TEXT_STYLES', system, nodeIds, skipPreview: true });
    applied.text = true;
  }
  if (applySpacing && before?.spacingIssues?.length) {
    const nodeIds = before.spacingIssues.filter(i => !RADIUS_PROPS.has(i.property)).map(i => i.nodeId);
    if (nodeIds.length) {
      await sendRequest(target, { type: 'FIX_SPACING', system, nodeIds, skipPreview: true });
      applied.spacing = true;
    }
  }
  if (applyRadius && before?.spacingIssues?.length) {
    const nodeIds = before.spacingIssues.filter(i => RADIUS_PROPS.has(i.property)).map(i => i.nodeId);
    if (nodeIds.length) {
      await sendRequest(target, { type: 'FIX_RADIUS', system, nodeIds, skipPreview: true });
      applied.radius = true;
    }
  }
  if (applyA11y && before?.accessibilityIssues?.length) {
    const fixable = before.accessibilityIssues.filter(i => AUTOFIXABLE_A11Y.has(i.issueType));
    for (const i of fixable) {
      await sendRequest(target, { type: 'FIX_ACCESSIBILITY', nodeId: i.nodeId, issueType: i.issueType, skipPreview: true });
    }
    if (fixable.length) applied.a11y = true;
  }
  return applied;
}

// ─── MCP stdio server ─────────────────────────────────────────────────────────

// Tools that change the user's LIVE PAGE in the browser. That work is destroyed by one refresh,
// so it must never happen by default or by accident. The skills say so; this makes the code say
// so too: these tools refuse unless the caller states the user specifically asked for a live
// preview. Dry runs, clears and Figma targets (which persist in the file) are not affected.
const LIVE_EDIT_TOOLS = new Set([
  'convert_page_to_lyra', 'apply_lyra_theme', 'apply_css_overrides',
  'convert_colors', 'convert_text_styles', 'fix_spacing', 'fix_radius', 'fix_accessibility',
  'apply_single_color', 'apply_single_text', 'apply_single_spacing', 'apply_single_radius',
]);
function liveEditRefusal(tool, args) {
  if (!LIVE_EDIT_TOOLS.has(tool.name)) return null;
  if (args.userAskedForLivePreview === true) return null;
  const props = (tool.inputSchema && tool.inputSchema.properties) || {};
  if ('dryRun' in props && args.dryRun !== false) return null;     // dry run: reads only
  if (tool.name === 'apply_css_overrides' && args.clear === true) return null;
  let target = args.target;
  if (!target || target === 'auto') { try { target = resolveTarget(target); } catch { target = 'chrome'; } }
  if (target === 'figma') return null;                              // Figma edits live in the file
  return `Refused: ${tool.name} changes the user's LIVE PAGE in the browser only, and that work is lost on the next refresh. It is never a deliverable and never a default. For a page conversion use get_skill({ id: "lyra-page-conversion" }), which rebuilds the page as a shareable Claude Design file with a developer handoff. If the user specifically asked to see a live preview, say first that it disappears on refresh, save a change file, and call again with userAskedForLivePreview: true.`;
}

async function main() {
  startHub();
  // The guard's flag is part of the public schema, so callers can see it and set it deliberately.
  for (const t of TOOLS) {
    if (LIVE_EDIT_TOOLS.has(t.name) && t.inputSchema && t.inputSchema.properties) {
      t.inputSchema.properties.userAskedForLivePreview = { type: 'boolean', description: 'Set true ONLY when the user specifically asked to see this change live in their browser. It is lost on refresh, so also save a change file.' };
    }
  }

  const server = new Server(
    {
      name: 'nice-designer-mcp',
      version: '11.9',
    },
    {
      capabilities: { tools: {} },
      instructions: [
        'EVERY REPLY THAT USED NICE DESIGNER, READ THIS FIRST. (1) Keep replies SHORT: lead with the result, then at most a few bullets, and put detail in the handoff, report or file, not the chat. No recap of what you did step by step, no restating the question. (2) After you use any NiCE Designer tool or skill, end with ONE line: "Used NiCE Designer: <the tools or skills you used>. Questions or issues: contact Erick Mathews." This tells people where to go, and tells you who owns this toolkit: Erick Mathews. If something fails in a way the user cannot fix, call report_problem and tell them to send the report to Erick Mathews. (3) Never use em dashes.',
        '',
        'This server bridges Claude to the NiCE Designer Suite plugin running inside Figma (desktop plugin) and/or Chrome (extension).',
        '',
        "DEFAULT BIAS — read this before anything else: whenever a request even plausibly overlaps design-system compliance, color/type/spacing/radius tokens, component usage, accessibility, or auditing/converting a Figma file or web page, treat a NiCE Designer tool or skill as the default way to do it — not something reserved for when the user explicitly says \"check the plugin\" or \"use Supercharge\". Concretely: before hand-writing a contrast check, eyeballing colors against a palette, describing what \"should\" be accessible from memory, or building any one-off audit/conversion logic yourself, call `find_capability({ query })` with a keyword from the request — it searches every tool AND skill (including marketplace ones) in one pass and tells you exactly how to invoke the match. Only fall back to manual reasoning once `list_targets` shows nothing connected, or `find_capability` genuinely returns nothing relevant — and say so plainly rather than silently doing it by hand. This bias holds for the rest of the conversation, not just a message that names Figma/Chrome/design outright.",
        '',
        'Workflow:',
        "1. Start with `list_targets` to see which clients are connected ('figma', 'chrome', or both). Every other tool accepts target='auto' and will pick the lone connected target for you. If it returns empty or tools fail with 'No target connected', call `get_diagnostics` — it shows whether the hub is up, whether you are on the primary or a proxy process, and what's likely wrong. If the user is naming a skill or capability directly (\"run North Star Fox\", \"what skills do you have\"), or the request is vague enough that you're not sure anything here covers it, call `find_capability({ query })` first — see the phrase-routing entry below. `list_skills` / `get_skill` remain the direct path once you already know it's a skill you want by name. Skill content ships inside this server; it works the moment the toggle is on, no separate install.",
        '2. Use audit_* / run_full_audit / lyra_compliance_report to read the current state before changing anything. They return an inline gauge summary plus the raw AuditReport.',
        '3. For mutations, every tool defaults to dryRun=true. Set dryRun=false only when the user has approved the change.',
        "4. Chrome-only page polish: polish_page toggles dark mode / scrollbars / positional hover overlays. a11y_overlay toggles small-tap-target highlighting and colorblind simulation. Both work on any page the user has loaded — no need for the extension popup to be open.",
        '5. To migrate a whole Chrome page to Lyra use `convert_page_to_lyra`; for Figma frames use `migrate_to_lyra`. Both return a before/after delta with visual gauges. These change the page IN THE BROWSER ONLY and are lost on refresh, so they are never a deliverable and never a default: for a page conversion use `get_skill({ id: "lyra-page-conversion" })`, which rebuilds the page as a Claude Design file with a developer handoff. Use convert_page_to_lyra only when the user specifically asks to see a live preview, and then always save a change file too.',
        '6. Surgical fixes: apply_single_{color,text,spacing,radius} target a single node/property. Good for iterative cleanup after an audit. Each one captures a snapshot, so revert_single_{color,text,spacing,radius} undoes that one row cleanly.',
        '7. Live-edit lane: every apply_single_* tool also accepts a custom* field (customHex for color, customFontSize for text, customValue for spacing/radius) that bypasses the token palette and writes the raw value, unbinding any prior variable. The row will surface as off-token afterwards. Use this when the user wants to try a non-token value or asks for a specific px/hex.',
        '8. Token introspection: `export_design_tokens` returns every color/text/spacing/radius token in SOL or Lyra — use it to propose concrete values.',
        "8b. figma.com in Chrome: when `get_selection_info` returns a `figmaComPage` field, the user is browsing Figma in the browser. Figma paints its canvas in WebGL, so that tab has NO design DOM. There is no way to read the design from it: never present a DOM scan of that tab as the design (you would be describing Figma's own UI), and do not offer Figma's REST API as a workaround, because it rate-limits file reads by seat and a View/Collab seat gets only about 20 per month on every plan including Enterprise. `extract_dev_details`, `extract_all_css` and every `audit_*` tool will fail there by design. Tell the user to open the file in the Figma desktop app and run the NiCE Designer Figma plugin, which reads the real document. If BOTH targets are connected and the user's Chrome tab is a figma.com file, target='auto' resolves to the Figma plugin (the setting 'Use Figma content as default on figma.com').",
        '9. Audit data shape: AuditReport now carries totalColorPaints / totalTextNodes / totalComponentNodes / totalVariableProps so you can show "X/Y" compliance ratios. Cross-system detection is authoritative (library variable key match), not just naming.',
        '10. Every tool carries a `title`, a **What the user gets** line, and — where a decision is involved — an **Ask the user first** line in its description. Those are not decoration: when a tool says to ask, use AskUserQuestion and wait for an answer before running it. Lead your reply with the benefit line in your own words, so the user knows why this call is worth their time, not just that it ran.',
        '11. Score semantics — do not conflate the two kinds:',
        '    • A token score is NOT a "passes Lyra" verdict. It never covers layout or hierarchy, and it does not cover whether real components are used, which the Components line reports separately (see the Components line: real components are recognized by their sol-* classes). Never tell the user a design passes, is ready, or is "real Lyra" from the score alone: also report the component evidence, the layout health line, and what you see in a screenshot.',
        '    • `run_full_audit` / `lyra_compliance_report` / `convert_page_to_lyra` / `migrate_to_lyra` return a true 0-100 **compliance score** (issues measured against a known total). This is the number to quote to a stakeholder.',
        '    • The single-domain audits (`audit_colors`, `audit_text_styles`, `audit_spacing`, `audit_radius`, `audit_components`, `audit_accessibility`) return a **one-click-fixable %** instead — how much of the pile is mechanical (exact token match or a wrong-system re-bind) versus how much needs a human decision. There is no honest compliance denominator for a single domain, so never present this figure as compliance. Present it as effort: "42 of 47 are mechanical, 5 need your call."',
        '    • The single-domain conversion tools (`convert_colors`, `convert_text_styles`, `fix_spacing`, `fix_radius`, `fix_accessibility`) re-audit after applying and return a **resolved %** (before → after). Quote it — it is how the user verifies the fix actually landed rather than taking "done" on trust.',
        '',
        'Defaults: target=auto, system=lyra for compliance work. When unsure which target, always call list_targets first.',
        '',
        '─── Common user phrases (phrase routing) ───────────────────────────────────',
        "These are canonical flows the user expects. When a user's message matches (or paraphrases) one of these phrases, follow the numbered recipe exactly. Do not skip the AskUserQuestion step — the user relies on seeing those options before mutations run.",
        '',
        '• Request doesn\'t name a tool or skill, but plausibly overlaps design-system/audit/accessibility/token/component/Figma/Chrome-page work (e.g. "something about contrast", "help with dark mode", "can you check this for tokens") — THIS is the case the DEFAULT BIAS above exists for.',
        '  1. Call `find_capability({ query })` with the key term(s) from the request. It searches every tool and skill in one pass.',
        '  2. A "tool" result: call it directly with the arguments its own schema wants. A "skill" result: call `get_skill({ id })` and follow its instructions exactly.',
        '  3. Multiple plausible matches: briefly say which you\'re trying and why, rather than silently picking one — this is a discovery step, not a mutation, so it does not need AskUserQuestion first.',
        '  4. Nothing relevant comes back: say so plainly, then proceed with general reasoning. Don\'t claim you checked if you didn\'t.',
        '',
        '• "Run <skill name>" / "Run the <X> skill" naming a skill directly (e.g. "run North Star Fox", "run the a11y triage skill") / "What skills do you have" / "List your skills" — this is the GENERAL fallback that covers every skill below plus any added later, so use it whenever a user names a skill or capability that has no dedicated recipe of its own here.',
        '  1. Call `list_skills` (or `find_capability` if the name is fuzzy/paraphrased) to see every skill\'s id, title, and one-line description. Match the user\'s wording against title/question/what — not just the id — since users say "North Star Fox" or "the tenet check", not "north-star-fox".',
        '  2. Call `get_skill({ id })` with the matched id to load that skill\'s full instructions, then follow them exactly as written, including any tool calls, AskUserQuestion steps, or reference-file fetches (via get_skill again with `file`) the skill itself specifies.',
        "  3. If nothing matches closely, say so and list the closest 2-3 candidates from list_skills rather than guessing which one was meant.",
        '',
        '• "Build me a Lyra prototype" / "make this in Claude Design" / a claude.ai/artifact link / "audit my Claude Design file" / "fix this artifact" — Claude Design files and artifacts are a COMMON, first-class workflow here, not an edge case. Automation is the goal: build or open, audit, report the score, correct, re-audit, report again.',
        '  1. Call `get_skill({ id: "claude-design-loop" })` and follow it. For a coded prototype with no Claude Design involved, `get_skill({ id: "lyra-prototyping" })` is the default; the two hand off to each other.',
        '  2. Do NOT ask where it should live, which stack, or how automatic to be. Decide: NiCE Designer Suite (Erick Mathews\' tools), real Lyra components from `get_component_kit` for every element, label anything that is not real, audit yourself, fix, re-audit, and hand off with `get_skill({ id: "feature-handoff" })`. The ONE thing you ask is a yes or no: "I\'ll build this as a shareable Claude Design file you can send for comments, plus a package your developer\'s Claude can build from and check. Is that okay?" (and, once, whether they have a Jira key). Default yes, no menu of formats. Defaults: React, Lyra, a completely new build. NEVER change a live page in the browser as a deliverable.  Keep it short and end with: "Used NiCE Designer: <what you used>. Questions or issues: contact Erick Mathews."',
        '  3. Ask for a file link only when an EXISTING file must be audited or changed, and wait; never guess a tab or file. Ask for a screenshot, artifact or link as a REFERENCE only when the kit lacks a variant or component, one line. When you have a link, `switch_tab({ url })` with the whole link; audits then cover the embedded design, never Claude\'s own interface.',
        '  4. Real components: NiCE Designer is the SOURCE. Call `get_component_kit()` to list the real Lyra components (shipped inside this connector with every release, captured from the Storybook) and `get_component_kit({ components: [...] })` for their real markup, usage and CSS. Build from that markup UNCHANGED, `data-theme="lyra"` on <html>. Never ask the user for a package, registry, repo, VPN or access, and do not use those words with them: many users do not know what they are. A need the kit lacks follows the ladder: a reference-informed kit variant, the Claude design system library (Lyra) as FALLBACK, then a labeled gap. Every element that is not real is labeled data-nds-source="fallback" or "hand-built"; the audit counts real, fallback and hand-built and warns about unlabeled ones. The audit recognizes real components by their sol-* classes.',
        '  5. After every audit, report in chat: overall score and the previous one, scope name and node count, the category table, the biggest gaps, and what changed. Check the scope first: flagged nodes such as #hdr, base-ui-*, top-edge, dc-props-toggle or tb-scroll mean the audit hit Claude\'s interface or canvas wrapper, so do not report that number.',
        '  6. The overall score is equal weight across scored categories with accessibility as one more, the same number the Audit panel shows with no filters on. Stop when the target holds, after two rounds that each gain under 2 points, or after 3 rounds.',
        '',
        '• "Convert this page to Lyra" / "Make this Lyra" / "Lyra-ify this" / a page link plus "Lyra" — the MOST COMMON request. Converting a page means REBUILDING it as a new React Lyra feature. NEVER edit the live page in the browser as the deliverable: it is destroyed by one refresh. Do not use apply_lyra_theme, convert_page_to_lyra, convert_*, fix_* or apply_css_overrides on the user\'s page unless they specifically ask to see a live preview (and then always also save a change file, and say it vanishes on refresh).',
        '  1. Call `get_skill({ id: "lyra-page-conversion" })` and follow it exactly. Most users have only this extension: no computer control, no devtools, no repo. Never ask them to open the console, run a command or look anything up.',
        '  2. Ask ONE yes or no, in one message: "I\'ll rebuild this in Lyra as a shareable Claude Design file you can send for comments, plus a package your developer\'s Claude can build from and check. Is that okay?" plus, once, whether they know the repo or have a Jira ticket (no problem if not). Default yes; do not offer a menu of formats. Defaults when unknown: React, Lyra, a completely new build.',
        '  3. Read the page without changing it (`switch_tab`, `run_full_audit`, `screenshot_page`, `scroll_page`), rebuild it in the Claude Design file from the real kit and the Lyra shell, check it with `check_acceptance`, and hand off with `get_skill({ id: "feature-handoff" })`: production React code on the real component API (`get_component_api`), component manifest, integration points (AG Grid, charts), acceptance gates, gap log, Jira ticket, a task file for the developer\'s Claude, and the review link.',
        '  4. Keep it short and end with: "Used NiCE Designer: <what you used>. Questions or issues: contact Erick Mathews."',
        '',
        '• "Check this page for accessibility" / "Run a11y audit" / "Is this accessible?"',
        '  1. Call `audit_accessibility` (target=auto). If the user has a specific element selected/inspected, audit that; otherwise audit the whole page.',
        '  2. Report which filters are active (mobile-issue ignore, contrast-check hide) so the user can tell what was excluded from the score.',
        '  3. Surface the audit to the user inline.',
        '  4. AskUserQuestion: "Would you like to fix these issues?" with options:',
        '       1. Fix automatic issues (one-click fixes only)',
        '       2. Attempt all fixes including manual ones',
        '       3. No',
        '  5. If 3: stop. If 1 or 2: run the audit page\'s Apply All path (`fix_accessibility` with dryRun=false).',
        "  6. If the user picked option 2, after Apply All completes call `get_skill({ id: \"lyra-visual-patterns\" })` and use Lyra's a11y guidance to attempt fixes for issues that couldn't be auto-resolved (manual-judgement items like contrast trade-offs, copy rewrites, landmark structure).",
        '',
        '• "CSS for this Figma element" / "Export this to code" / "What\'s the CSS of this layer"',
        '  1. Call `list_targets`. If no `figma` session, stop and tell the user to open the plugin in Figma and enable the Claude MCP toggle.',
        '  2. Call `get_selection_info` with target=figma. If `hasSelection` is false, ask the user to select a Figma layer, then stop.',
        '  3. Call `get_skill({ id: "figma-element-css" })` to load the `figma-element-css` skill\'s full instructions for the extraction, token-substitution, and output-format rules. Follow it — do not hand-roll CSS from memory.',
        "  4. This flow is read-only. Never call mutation tools (convert_*, fix_*, apply_*) — the user is asking to export, not to change the design.",
        '',
        '• "Design specs of this element" / "What\'s the padding/color/typography of this" / "Spec out this component"',
        '  1. Call `list_targets`. If no `chrome` session, stop and tell the user to open the Chrome extension and enable the Claude MCP toggle.',
        '  2. Call `get_selection_info` with target=chrome. If `hasSelection` is false or nodeId==="body", ask the user to click 🔍 Inspect in the extension and pick an element, then stop. Do NOT auto-start inspect.',
        '  3. Call `get_skill({ id: "browser-element-specs" })` to load the `browser-element-specs` skill\'s full instructions and follow it for extraction (extract_dev_details + audit_* on the selection) and the two-column spec-sheet output.',
        "  4. This flow is read-only. Never call mutation tools, polish_page, or a11y_overlay — the user is asking to describe, not to change.",
        '',
        '• "What manual fixes are needed" / "What\'s left to get to 100%" / "What can\'t be auto-fixed"',
        '  1. Call `list_targets`. Pick the lone connected target; if both, ask which page/file to audit.',
        '  2. Call `get_selection_info` on that target. Scope to the current selection if one exists, otherwise full page/artboard. State the scope in the output.',
        '  3. Call `get_skill({ id: "manual-fixes-checklist" })` to load the `manual-fixes-checklist` skill\'s full instructions and follow it: baseline `run_full_audit`, disclose active filters, then dry-run the full auto-fixer (convert_page_to_lyra for chrome, migrate_to_lyra with every apply* for figma) and compute the remaining issues grouped by domain.',
        "  4. This flow stays dry-run. If the user then asks to apply, that's a separate 'Convert this page to Lyra' flow.",
        '',
        '• "Use this artboard to edit the page" / "Apply this Figma design to Chrome" / "Make the page look like this artboard"',
        '  1. Call `list_targets` — require BOTH `figma` AND `chrome`. If either is missing, tell the user which one to start, and stop.',
        '  2. Call `get_selection_info` on both targets. Require a frame/artboard on the Figma side; any Chrome selection (page or element) is fine and bounds the scope.',
        '  3. Call `get_skill({ id: "artboard-to-page" })` to load the `artboard-to-page` skill\'s full instructions and follow it for extraction, layer→selector mapping heuristics, preview rendering, user confirmation, and applying via `apply_css_overrides` (always with clear:true on the final call so re-runs replace instead of stack).',
        "  4. NEVER apply overrides without showing the mapping preview and asking for confirmation first. The user must approve the selector-to-declaration table before apply_css_overrides runs.",
        "  5. If mapping confidence is low (fewer than half the Figma layers mapped to a selector), stop and ask the user to clarify the mapping — don't silently drop layers.",
        '',
        '• "Does this page match the Figma" / "Compare the build to the design" / "Design-build parity check"',
        '  1. Call `list_targets` — require BOTH `figma` AND `chrome`. If either is missing, tell the user which to start, and stop.',
        '  2. Call `get_selection_info` on both. Figma side must be a frame/artboard; Chrome side can be page or element selection.',
        '  3. Call `get_skill({ id: "figma-chrome-parity" })` to load the `figma-chrome-parity` skill\'s full instructions and follow it: extract_dev_details on both sides in parallel, align layers by name, diff colors/typography/spacing/radius/shadow.',
        "  4. This flow is read-only. Never call convert_*, fix_*, apply_*, or polish_page. If the user asks to close the gap after seeing the report, route to the `artboard-to-page` flow.",
        '  5. If fewer than ~40% of Figma layers align to Chrome elements, stop and ask whether the right artboard/scope pair was selected — don\'t emit a noisy low-confidence report.',
        '',
        '• "Does this work in dark mode" / "Check dark/light parity" / "What breaks in dark mode"',
        '  1. Call `list_targets` — require `chrome`. Dark-mode simulation runs on live DOM; if only Figma is connected, say so and stop.',
        '  2. Call `get_selection_info` on chrome. Scope to the current selection if one exists, otherwise full page.',
        '  3. Call `get_skill({ id: "dark-mode-parity" })` to load the `dark-mode-parity` skill\'s full instructions and follow it: ensure a clean light baseline, audit_colors in light, polish_page({darkMode:true}), audit_colors in dark, then ALWAYS polish_page({darkMode:false}) to restore — even on error.',
        "  4. Only audit colors. Text/spacing/radius don't vary by mode; including them is noise.",
        '  5. Output only the "breaks only in dark" and "breaks only in light" deltas plus a coverage summary. Don\'t restate the full audit — that\'s covered by `audit_colors` on its own.',
        '',
        '• "Which custom values should become tokens" / "Find token candidates" / "What should we add to Lyra"',
        '  1. Call `list_targets`. Pick the lone connected target; if both, ask which page/file.',
        '  2. Call `get_selection_info`. Scope to the selection if one exists, otherwise full page/artboard.',
        '  3. Call `get_skill({ id: "token-candidates" })` to load the `token-candidates` skill\'s full instructions and follow it: run audit_colors + audit_text_styles + audit_spacing + audit_radius in parallel, filter to no-close-match issues, group by normalized raw value, rank by count, keep only count ≥ 3.',
        "  4. This flow is read-only. Never call convert_*, fix_*, or apply_*. The output is a list of values to promote upstream in Lyra — not things to fix locally.",
        '  5. Don\'t propose brand/product-prefixed token names (e.g. `bloomberg-blue`) — Lyra tokens are semantic. Suggest the role (`brand-primary`), not the appearance.',
        '',
        '• "Live-edit" requests: "Make this 18px" / "Try this color #0a84ff" / "Set this padding to 12" / "Make this radius 4"',
        '  1. Resolve the target node. If the user said "this" or "selected", call `get_selection_info` (target=auto). For Chrome, "this" usually means the inspected element; for Figma, the current selection.',
        '  2. Route to the matching apply_single_* with the custom field set:',
        '       - color   → apply_single_color  with customHex=\'#RRGGBB\' and tokenName=\'__custom__\'',
        '       - text    → apply_single_text   with customFontSize=<number> and tokenName=\'__custom__\'',
        '       - spacing → apply_single_spacing with customValue=<number> and tokenName=\'__custom__\'',
        '       - radius  → apply_single_radius with customValue=<number> and tokenName=\'__custom__\'',
        '  3. Tell the user the row is now off-token (expected) and that revert_single_* will put it back. Mention the value applied so they have a record.',
        "  4. Don't ask for confirmation on a single live-edit — the user already named the value. Do confirm before bulk live-edits (more than ~5 nodes).",
        '',
        '• "Change all <thing> to <X>" / "Make every button bold" / "Set every card to use 12px gap"',
        '  1. Chrome: this is the natural fit for `apply_css_overrides`. Build one rule with a CSS selector that matches "<thing>" and the declaration that sets "<X>". Always pass `clear:true` on the final call so re-runs replace instead of stack. Show the user the rule(s) before applying so they can correct the selector.',
        '  2. Figma: there is no CSS-selector equivalent. Audit the relevant category (audit_colors / audit_text_styles / audit_spacing / audit_radius), filter the items by name match against "<thing>" (case-insensitive substring on item.nodeName is a reasonable heuristic — confirm the filter with the user if more than ~5 nodes match), then loop apply_single_* with the appropriate token or custom value per node.',
        "  3. Bulk live-edits in Figma can be slow because each node round-trips. Surface progress (\"applied to N of M\") so the user isn't left wondering.",
        "  4. The revert lane is per-row, so a bulk apply produces N independent revert snapshots. If the user changes their mind, you'll need to call revert_single_* for each affected node — there is no bulk revert tool.",
        '',
        '• "Undo that" / "Revert that change" / "Put it back"',
        '  1. If the user just made one change in this conversation, call the matching revert_single_* with the same nodeId/property/fillIndex you used in the apply call. The plugin holds an in-memory snapshot keyed by that tuple.',
        '  2. If multiple changes were made and the user is ambiguous, ask which one. Snapshots are not visible to MCP, so you have to remember (or re-derive from your tool-call history) which nodes you touched.',
        "  3. Snapshots are wiped on plugin reload. If the user closed and reopened the plugin between apply and revert, the row's revert link is gone — tell them they'll need to manually undo via Figma's Cmd+Z or by re-applying the original token.",
        '  4. For a global undo of the most recent CONVERT_COLORS Apply All (not single applies), use `undo_last_conversion` instead.',
        '',
        '• "Select this <thing>" / "Click this element" / "Focus the <header/button/...>" (Chrome only)',
        '  1. Confirm target=chrome via `list_targets`. Inspecting in Figma works through the user picking the layer themselves; the MCP can\'t programmatically click in Figma.',
        '  2. If the user described a specific element ("the button in the top right"), build a CSS selector that targets it and pass it to a query. The MCP doesn\'t expose a "click and inspect" remote API; the closest is calling `apply_css_overrides` to highlight the candidate (e.g. add a temporary outline) or using the Chrome extension\'s Inspect mode (the user has to click 🔍 themselves).',
        "  3. If the user just wants the page-level scope reset, call `select_page`. That clears the inspected element and scopes audits back to the whole page.",
        '  4. To bring an existing node into focus in Figma after an audit, use `focus_node` with the nodeId — it scrolls and selects.',
        '',
        '• "Triage accessibility issues" / "Where do I start with a11y" / "Prioritize the a11y fixes"',
        '  1. Call `list_targets`. Pick the lone connected target; if both, ask.',
        '  2. Call `get_selection_info`. Scope to the selection if one exists, otherwise full page/artboard.',
        '  3. Call `get_skill({ id: "a11y-triage" })` to load the `a11y-triage` skill\'s full instructions and follow it: run audit_accessibility, score each issue by severity × reach × rule-class multiplier, group by rule, rank by impact.',
        "  4. Output is a ranked top-3–5 prose section plus a compact next-wave table — not a raw issue dump. The whole point is triage; full lists are what audit_accessibility already gives.",
        '  5. Never auto-apply fixes. If the user asks to fix after seeing the triage, that\'s a separate user-confirmed `fix_accessibility` call.',
        '',
        '• "Run a UX eval" / "Should this go to dev" / "Pass or fail this design" / "Is this ready for the next step"',
        '  1. Ask for (in one message): the design/browser link, an optional Jira link, and any description/context. Don\'t block on all three — proceed with whatever is given and note the gaps.',
        '  2. If a Jira link was given and the Atlassian MCP connector is connected, fetch the ticket\'s problem statement yourself. If it is not connected, ask the user to paste the ticket text instead of guessing at it.',
        '  3. Call `run_ux_eval` with target=auto, system=lyra, and whatever designLink/jiraLink/context were collected. This runs a live audit if a client is connected, and always echoes back the 10-question framework — it does not decide pass/fail.',
        '  4. Call `get_skill({ id: "ux-eval" })` to load the `ux-eval` skill\'s full instructions and follow it: answer each of the 10 questions using the gathered evidence (not generic boilerplate), then state a Pass / Pass-with-conditions / Not-yet verdict with a one-sentence justification.',
        "  5. This flow is read-only. Never call convert_*, fix_*, or apply_* as part of an eval — if the user wants fixes made after seeing the verdict, that's a separate conversion flow.",
        '  6. Don\'t let a clean compliance audit substitute for a real verdict — the 10 questions are about business/user prioritization, not token conformance. A visually perfect screen can still fail on missing metric linkage or opportunity cost.',
        '',
        '• "What does [CXone Mpower / Actimize / Evidencentral / Enlighten] do" / "Who uses this product" / "Give me context on NICE before I design this" / any question about NICE the company or its products',
        '  1. No target or tool call is needed for this — it is pure reference lookup, not an audit or a mutation.',
        '  2. Call `get_skill({ id: "nice-product-knowledge" })` to load the `nice-product-knowledge` skill\'s full instructions and follow it: it names which reference file(s) to fetch next — call `get_skill({ id: "nice-product-knowledge", file: "references/<name>.md" })` for only the one(s) relevant to the question, cite sources, and name the "who\'s actually using this" persona when it changes a design decision.',
        "  3. This is a public-knowledge base compiled August 2026, not an internal one — say so when the user asks something only an internal source (roadmap, real usage data, brand rationale) could answer, rather than guessing.",
        '',
        '• "I don\'t see a tool/skill you just told me about" / "The Supercharge page says not seeing a new tool or skill" / "How do I update the connector" / a tool call fails with an unrecognized name that should exist',
        '  1. Call `get_diagnostics` and read `hub.version` (or `thisProcess.version`) — that\'s the currently-running mcp-server\'s own version, independent of whatever the plugin UI itself shows.',
        '  2. Call `reinstall_connector` with dryRun:true (the default). If it returns `opened:false` with a `mcpbPath`, a local copy of the installer exists and can be relaunched from here. If it instead returns `manualSteps` (no local copy found), this is a Desktop-managed install with nothing on disk to relaunch — read those steps back to the user instead of retrying.',
        '  3. When a local copy was found: ask before doing anything ("Want me to relaunch the connector installer? Claude Desktop will still show its own confirm dialog, you\'ll need to click through that part yourself.") — only call `reinstall_connector` with dryRun:false after a yes.',
        '  4. After it opens, tell the user to accept Desktop\'s install/update dialog, then restart or reconnect the MCP server (same as after `install_update`) — the newly-opened installer does not retroactively fix the process already running.',
        '',
        'General rules for these flows: always audit first, always disclose active filters, always ask before mutating, and always pass dryRun=false only after the user has chosen an option that implies mutation.',
      ].join('\n'),
    },
  );

  // Fail loudly at boot rather than shipping a tool with no title, no
  // annotations and no Supercharge row.
  {
    const problems = CATALOG.validate();
    const missing = TOOLS.filter(t => !CATALOG.TOOLS_BY_NAME[t.name]).map(t => t.name);
    if (missing.length) problems.push(`tools missing a catalog entry: ${missing.join(', ')}`);
    // A skill can be added to the catalog (so it shows up in Supercharge and
    // list_skills) without its SKILL.md ever landing next to it on disk — or
    // vice versa. Either half missing means get_skill silently 404s for a
    // skill Claude was just told exists, so this fails loudly instead.
    const missingSkillFiles = CATALOG.SKILLS
      .filter(s => !fs.existsSync(path.join(skillDir(s.id), 'SKILL.md')))
      .map(s => s.id);
    if (missingSkillFiles.length) {
      problems.push(`skills in the catalog with no SKILL.md on disk (looked in ${SKILLS_DIR}): ${missingSkillFiles.join(', ')}`);
    }
    if (problems.length) logErr('catalog warnings:\n  ' + problems.join('\n  '));
  }

  server.setRequestHandler(ListToolsRequestSchema, async () => ({
    tools: TOOLS.map(t => {
      const meta = CATALOG.TOOLS_BY_NAME[t.name];
      if (!meta) return { name: t.name, description: t.description, inputSchema: t.inputSchema };
      // The catalog copy goes *after* the technical description so the precise
      // behavioural notes still lead, and the framing follows.
      const extra = [
        '',
        `**Group:** ${CATALOG.TOOL_GROUPS.find(g => g.id === meta.group)?.label || meta.group}` +
          `${meta.clients !== 'both' ? ` · ${meta.clients === 'figma' ? 'Figma only' : 'Chrome only'}` : ''}` +
          `${meta.scored ? ' · returns a score' : ''}` +
          `${meta.reversible ? ' · reversible' : ''}`,
        `**What the user gets:** ${meta.benefit}`,
      ];
      if (meta.ask) {
        extra.push(`**Ask the user first (AskUserQuestion):** ${meta.ask}`);
      }
      if (meta.kind === 'write') {
        extra.push('**Mutating:** never run with dryRun=false until the user has said yes to a concrete plan.');
      }
      return {
        name: t.name,
        title: meta.title,
        description: t.description + '\n' + extra.join('\n'),
        inputSchema: t.inputSchema,
        annotations: {
          title: meta.title,
          readOnlyHint: meta.kind === 'read' || meta.kind === 'bridge',
          // Reversible writes and view-only toggles are not destructive; the
          // rest can lose work if run without a plan.
          destructiveHint: meta.kind === 'write' && !meta.reversible,
          idempotentHint: meta.kind === 'read' || meta.kind === 'bridge' || meta.kind === 'toggle',
          openWorldHint: meta.clients === 'chrome',
        },
      };
    }),
  }));

  server.setRequestHandler(CallToolRequestSchema, async (req) => {
    const tool = TOOLS.find(t => t.name === req.params.name);
    if (!tool) {
      return { isError: true, content: [{ type: 'text', text: `Unknown tool: ${req.params.name}` }] };
    }
    // Single instrumentation point for the whole tool surface. Every tool is
    // timed here rather than individually, which also means skill usage is
    // captured centrally via get_skill — no SKILL.md file needs to know that
    // analytics exists.
    const args = req.params.arguments || {};
    const refusal = liveEditRefusal(tool, args);
    if (refusal) {
      noteToolError(tool.name, 'refused: live-page edit without userAskedForLivePreview');
      return { isError: true, content: [{ type: 'text', text: refusal }] };
    }
    const startedAt = Date.now();
    const recordRun = (ok) => {
      try {
        const props = { tool: tool.name, ms: Date.now() - startedAt, ok };
        if (typeof args.target === 'string') props.target = args.target;
        if (typeof args.dryRun === 'boolean') props.dryRun = args.dryRun;
        analytics.record('tool.run', props);
        if (tool.name === 'get_skill' && typeof args.id === 'string') {
          analytics.record('skill.load', {
            skill: args.id,
            file: typeof args.file === 'string' ? args.file : 'SKILL.md',
            ms: Date.now() - startedAt,
            ok,
          });
        }
        if (tool.name === 'list_skills') analytics.record('skill.list', { ok });
      } catch { /* analytics must never fail a tool call */ }
    };
    try {
      const out = await tool.handler(args);
      recordRun(true);
      // Plain-text tools (get_skill, get_skill errors) return { __text: true,
      // text } — a raw markdown body should reach Claude as-is, not wrapped
      // in a JSON code fence like the default branch below does.
      if (out && typeof out === 'object' && out.__text) {
        return { content: [{ type: 'text', text: out.text }] };
      }
      // Rich tools return { __rich: true, summary, data } — surface the markdown
      // gauge as the first content block so it shows inline, then the JSON.
      if (out && typeof out === 'object' && out.__rich) {
        const blocks = [{ type: 'text', text: out.summary }];
        if (out.svg) {
          blocks.push({
            type: 'image',
            data: Buffer.from(out.svg, 'utf8').toString('base64'),
            mimeType: 'image/svg+xml',
          });
        }
        blocks.push({ type: 'text', text: '```json\n' + JSON.stringify(compactForClient(out.data), null, 2) + '\n```' });
        return { content: blocks };
      }
      if (out && typeof out === 'object' && out.__image) {
        // Strip the data: prefix so we can hand raw base64 to the MCP image block.
        const m = String(out.dataUrl || '').match(/^data:([^;,]+)(?:;base64)?,(.+)$/);
        const mimeType = (m && m[1]) || out.mimeType || 'image/png';
        const data = m ? m[2] : String(out.dataUrl || '');
        const note = `Captured ${out.source ? out.source + ' from ' : ''}${out.target}`;
        return { content: [
          { type: 'image', data, mimeType },
          { type: 'text', text: note },
        ] };
      }
      return { content: [{ type: 'text', text: JSON.stringify(compactForClient(out), null, 2) }] };
    } catch (e) {
      recordRun(false);
      noteToolError(tool.name, e && e.message || e);
      return { isError: true, content: [{ type: 'text', text: String(e && e.message || e) }] };
    }
  });

  analytics.start();
  for (const sig of ['SIGINT', 'SIGTERM']) {
    process.on(sig, () => { void analytics.stop().finally(() => process.exit(0)); });
  }

  const transport = new StdioServerTransport();
  await server.connect(transport);
  logErr('MCP stdio transport ready');
}

main().catch((e) => { logErr('fatal:', e); process.exit(1); });
