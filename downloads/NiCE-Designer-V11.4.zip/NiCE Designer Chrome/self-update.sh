#!/usr/bin/env bash
# Updates an unpacked Chrome install of NiCE Designer Suite in place.
#
# Chrome will not let a sideloaded (Load unpacked) extension replace its own
# files or reload itself — that's a deliberate browser security restriction,
# not something this script can work around. What it *can* do is collapse
# "download the zip, unzip it, copy the files over" into one step, so the
# only thing left for you to do by hand is click Reload in chrome://extensions.
#
# Usage: run this from inside your installed extension folder (the one you
# pointed "Load unpacked" at) — e.g. `bash self-update.sh`.
set -euo pipefail

VERSION_URL="https://erick-nice.github.io/nice-designer-suite-website/version.json"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [ ! -f manifest.json ]; then
  echo "error: no manifest.json here — run this from inside the installed extension folder." >&2
  exit 1
fi

current_version="$(grep -m1 '"version"' manifest.json | sed -E 's/.*"version"[^"]*"([^"]+)".*/\1/')"
echo "Installed version: $current_version"

version_json="$(curl -fsSL "$VERSION_URL")"
latest_version="$(echo "$version_json" | grep -m1 '"latest"' | sed -E 's/.*"latest"[^"]*"([^"]+)".*/\1/')"
download_url="$(echo "$version_json" | grep -m1 '"downloadUrl"' | sed -E 's/.*"downloadUrl"[^"]*"([^"]+)".*/\1/')"
echo "Latest version:    $latest_version"

is_newer() {
  # Segment-wise numeric compare for "x.y" versions — mirrors isNewerVersion()
  # in src/ui/index.tsx. Plain string/Number compare breaks once a segment
  # reaches double digits (e.g. "11.10" vs "11.9").
  IFS='.' read -ra a <<< "$1"
  IFS='.' read -ra b <<< "$2"
  local len=${#a[@]}
  [ ${#b[@]} -gt "$len" ] && len=${#b[@]}
  for ((i = 0; i < len; i++)); do
    local av=${a[i]:-0} bv=${b[i]:-0}
    if [ "$av" -ne "$bv" ]; then
      [ "$av" -gt "$bv" ] && return 0 || return 1
    fi
  done
  return 1
}

if ! is_newer "$latest_version" "$current_version"; then
  echo "Already up to date."
  exit 0
fi

tmp_dir="$(mktemp -d)"
trap 'rm -rf "$tmp_dir"' EXIT

echo "Downloading v$latest_version…"
curl -fsSL "$download_url" -o "$tmp_dir/update.zip"

echo "Extracting…"
unzip -q "$tmp_dir/update.zip" -d "$tmp_dir/extracted"

# The zip's top-level folder name has varied across releases (e.g. "chrome/"),
# so just take whatever single directory unzip produced rather than hardcoding it.
src_dir="$(find "$tmp_dir/extracted" -mindepth 1 -maxdepth 1 -type d | head -1)"
if [ -z "$src_dir" ]; then
  echo "error: couldn't find the extracted extension folder inside the zip." >&2
  exit 1
fi

echo "Installing over $SCRIPT_DIR…"
rsync -a --delete "$src_dir/" "$SCRIPT_DIR/"

echo
echo "Updated to v$latest_version."
echo "Last step (Chrome won't let this script do it for you):"
echo "  chrome://extensions -> NiCE Designer Suite -> Reload"
