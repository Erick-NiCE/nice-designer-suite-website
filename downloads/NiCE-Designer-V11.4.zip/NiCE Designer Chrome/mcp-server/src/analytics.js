'use strict';

// ─── Local analytics store + uploader ─────────────────────────────────────────
// The MCP server is the analytics hub for everything that cannot reach the
// network itself. It:
//
//   1. records its own events (every tool call, every skill load),
//   2. ingests batches relayed from the Figma plugin over the WebSocket, since
//      the plugin's manifest keeps networkAccess.allowedDomains at ["none"],
//   3. spools everything to disk under ~/.nice-designer/analytics,
//   4. uploads batches to the configured collector endpoint, and
//   5. keeps a rolling totals file so "your usage" still works after upload.
//
// Everything here is best-effort. A failure at any step is swallowed and
// retried later; nothing in the MCP tool surface may fail because analytics
// did.
//
// Concurrency: the server runs primary-or-proxy (see MODE in index.js), so
// several processes can be live against this directory at once. Two rules keep
// that safe without a lock:
//   • Each process appends only to its OWN spool file, named by pid. Appends
//     never contend.
//   • A file is claimed for upload by renaming it first. rename(2) is atomic,
//     so exactly one process can win a given file, and a crash mid-upload
//     leaves a .claimed file that the next sweep reclaims.

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { installName } = require('./words');

const SCHEMA_VERSION = 1;

// Collector endpoint. This is the Power Automate "When an HTTP request is
// received" URL, whose `sig=` query parameter is its own credential. It is
// write-only: it cannot read the SharePoint list back, cannot enumerate what
// has been collected, and cannot reach anything else in the tenant. That is
// why it is acceptable to ship, and why it must never be swapped for a
// credential that can also read.
//
// Set NICE_ANALYTICS_ENDPOINT to override (used for testing against a
// throwaway flow without rebuilding the connector).
const ENDPOINT = process.env.NICE_ANALYTICS_ENDPOINT || '';

// Opt-out honoured by every producer. The plugin UI has a Settings toggle; for
// the server this is the equivalent lever.
const OPTED_OUT = process.env.NICE_ANALYTICS_OPTOUT === '1';

const DIR = path.join(os.homedir(), '.nice-designer', 'analytics');
const SPOOL_DIR = path.join(DIR, 'spool');
const TOTALS_FILE = path.join(DIR, 'totals.json');
const INSTALL_FILE = path.join(DIR, 'install-id');

// Must match ANALYTICS_MAX_BATCH in src/analytics/schema.ts — bounded by the
// 63,999-character cap on the SharePoint text column the payload lands in.
const MAX_BATCH = 100;
const MAX_SPOOL_EVENTS = 500;      // rotate the active spool file past this
const UPLOAD_INTERVAL_MS = 10 * 60 * 1000;
const UPLOAD_TIMEOUT_MS = 15_000;
// A spool file that cannot be delivered forever must not grow without bound.
const MAX_SPOOL_FILES = 200;

let installId = null;
let activeSpool = null;
let activeCount = 0;
let uploadTimer = null;
let started = false;

function log(...a) { if (process.env.NICE_ANALYTICS_DEBUG) console.error('[analytics]', ...a); }

function ensureDirs() {
  fs.mkdirSync(SPOOL_DIR, { recursive: true });
}

/** Anonymous per-install UUID. Minted once, never tied to a person. */
function getInstallId() {
  if (installId) return installId;
  try {
    ensureDirs();
    if (fs.existsSync(INSTALL_FILE)) {
      const v = fs.readFileSync(INSTALL_FILE, 'utf8').trim();
      if (v) { installId = v; return installId; }
    }
    installId = crypto.randomUUID();
    fs.writeFileSync(INSTALL_FILE, installId, 'utf8');
  } catch {
    // Read-only home, or no home at all. Fall back to a per-process id: the
    // data is still valid, it just cannot be joined across restarts.
    installId = crypto.randomUUID();
  }
  return installId;
}

function newSpoolPath() {
  return path.join(SPOOL_DIR, `${process.pid}-${Date.now()}.jsonl`);
}

/**
 * Appends events to this process's spool file. O_APPEND writes under the pipe
 * buffer size are atomic, so this stays safe even if the same process is
 * re-entered from a timer mid-write.
 */
function append(events) {
  if (OPTED_OUT || !events || !events.length) return;
  try {
    ensureDirs();
    if (!activeSpool || activeCount >= MAX_SPOOL_EVENTS) {
      activeSpool = newSpoolPath();
      activeCount = 0;
    }
    const lines = events.map(e => JSON.stringify(e)).join('\n') + '\n';
    fs.appendFileSync(activeSpool, lines, 'utf8');
    activeCount += events.length;
    updateTotals(events);
  } catch (e) {
    log('append failed:', e.message);
  }
}

/** Records one server-side event. */
function record(name, props) {
  if (OPTED_OUT) return;
  append([{
    v: SCHEMA_VERSION,
    id: crypto.randomUUID(),
    installId: getInstallId(),
    installName: installName(getInstallId(), 'mcp'),
    client: 'mcp',
    appVersion: require('../package.json').version,
    ts: Date.now(),
    sessionId: SESSION_ID,
    name,
    props: props && Object.keys(props).length ? props : undefined,
  }]);
}

const SESSION_ID = crypto.randomUUID();

/**
 * Ingests a batch relayed from a plugin client. These arrive already shaped as
 * events, so they are validated and appended verbatim — in particular their
 * original `ts` and `installId` are preserved, since the relay may happen long
 * after the fact (a Figma session that only connects Supercharge the next day
 * still reports the right day).
 */
function ingest(batch, target) {
  if (OPTED_OUT || !Array.isArray(batch)) return 0;
  const clean = batch.filter(isEvent).slice(0, 2000);
  if (!clean.length) return 0;
  for (const e of clean) {
    // Trust the client for everything except the client tag, which is
    // authoritative from the socket it arrived on.
    if (target === 'figma' || target === 'chrome') e.client = target;
  }
  append(clean);
  return clean.length;
}

function isEvent(x) {
  return !!x && typeof x === 'object'
    && typeof x.id === 'string'
    && typeof x.name === 'string'
    && typeof x.ts === 'number'
    && typeof x.installId === 'string';
}

// ─── Rolling totals ──────────────────────────────────────────────────────────
// Kept separately from the spool so the local "your usage" view survives
// upload, which deletes the spooled events.

function readTotals() {
  try { return JSON.parse(fs.readFileSync(TOTALS_FILE, 'utf8')); }
  catch { return { events: 0, byName: {}, byTool: {}, bySkill: {}, usageMs: 0, firstSeen: null, lastSeen: null }; }
}

function updateTotals(events) {
  try {
    const t = readTotals();
    for (const e of events) {
      t.events++;
      t.byName[e.name] = (t.byName[e.name] || 0) + 1;
      const p = e.props || {};
      if (e.name === 'tool.run' && typeof p.tool === 'string') t.byTool[p.tool] = (t.byTool[p.tool] || 0) + 1;
      if (e.name === 'skill.load' && typeof p.skill === 'string') t.bySkill[p.skill] = (t.bySkill[p.skill] || 0) + 1;
      if ((e.name === 'app.ping' || e.name === 'app.close') && typeof p.ms === 'number') t.usageMs += p.ms;
      if (!t.firstSeen || e.ts < t.firstSeen) t.firstSeen = e.ts;
      if (!t.lastSeen || e.ts > t.lastSeen) t.lastSeen = e.ts;
    }
    fs.writeFileSync(TOTALS_FILE, JSON.stringify(t), 'utf8');
  } catch (e) {
    log('totals update failed:', e.message);
  }
}

/** Local usage summary — powers the analytics_summary tool and the in-app panel. */
function summary() {
  const t = readTotals();
  const top = (obj, n) => Object.entries(obj)
    .sort((a, b) => b[1] - a[1]).slice(0, n)
    .map(([name, count]) => ({ name, count }));
  let pendingUpload = 0;
  try { pendingUpload = fs.readdirSync(SPOOL_DIR).filter(f => f.endsWith('.jsonl')).length; }
  catch { /* no spool dir yet */ }
  return {
    installId: getInstallId(),
    installName: installName(getInstallId(), 'mcp'),
    enabled: !OPTED_OUT,
    endpointConfigured: !!ENDPOINT,
    totalEvents: t.events,
    usageMinutes: Math.round(t.usageMs / 60000),
    firstSeen: t.firstSeen ? new Date(t.firstSeen).toISOString() : null,
    lastSeen: t.lastSeen ? new Date(t.lastSeen).toISOString() : null,
    topTools: top(t.byTool, 15),
    topSkills: top(t.bySkill, 15),
    byEvent: t.byName,
    spoolFilesPendingUpload: pendingUpload,
  };
}

// ─── Upload ──────────────────────────────────────────────────────────────────

/**
 * Claims one spool file by atomic rename, so that exactly one process uploads
 * it even when a primary and several proxies sweep concurrently. Returns the
 * claimed path, or null if nothing is available.
 */
function claimOne() {
  let files;
  try { files = fs.readdirSync(SPOOL_DIR); } catch { return null; }

  // Reclaim files orphaned by a crash mid-upload (claimed, still here, old).
  const now = Date.now();
  for (const f of files) {
    if (!f.includes('.claimed-')) continue;
    const p = path.join(SPOOL_DIR, f);
    try {
      if (now - fs.statSync(p).mtimeMs > 5 * 60 * 1000) {
        const revived = path.join(SPOOL_DIR, f.split('.claimed-')[0] + '.jsonl');
        fs.renameSync(p, revived);
      }
    } catch { /* another process got there first */ }
  }

  try { files = fs.readdirSync(SPOOL_DIR); } catch { return null; }
  const ready = files
    .filter(f => f.endsWith('.jsonl'))
    // Never claim the file this process is still appending to.
    .filter(f => path.join(SPOOL_DIR, f) !== activeSpool)
    .sort();

  // Backstop: if delivery has been broken long enough to pile up, drop the
  // oldest rather than fill the user's disk.
  if (ready.length > MAX_SPOOL_FILES) {
    for (const f of ready.slice(0, ready.length - MAX_SPOOL_FILES)) {
      try { fs.unlinkSync(path.join(SPOOL_DIR, f)); } catch { /* noop */ }
    }
  }

  for (const f of ready) {
    const from = path.join(SPOOL_DIR, f);
    const to = `${from.replace(/\.jsonl$/, '')}.claimed-${process.pid}`;
    try { fs.renameSync(from, to); return to; }
    catch { /* lost the race — try the next file */ }
  }
  return null;
}

function parseSpool(file) {
  let raw;
  try { raw = fs.readFileSync(file, 'utf8'); } catch { return []; }
  const out = [];
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    try { const e = JSON.parse(line); if (isEvent(e)) out.push(e); }
    catch { /* a torn last line from a crash — skip it */ }
  }
  return out;
}

async function postBatch(events) {
  if (!ENDPOINT) return false;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), UPLOAD_TIMEOUT_MS);
  try {
    const res = await fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      // batchId lets the flow drop a duplicate delivery outright; event ids
      // are the finer-grained dedupe key downstream.
      body: JSON.stringify({ v: SCHEMA_VERSION, batchId: crypto.randomUUID(), sentAt: Date.now(), events }),
      signal: ctrl.signal,
    });
    return res.ok;
  } catch (e) {
    log('upload failed:', e.message);
    return false;
  } finally {
    clearTimeout(timer);
  }
}

/** Sweeps the spool and uploads what it can. Safe to call at any time. */
async function upload() {
  if (OPTED_OUT || !ENDPOINT) return;
  for (;;) {
    const claimed = claimOne();
    if (!claimed) return;
    const events = parseSpool(claimed);
    if (!events.length) {
      try { fs.unlinkSync(claimed); } catch { /* noop */ }
      continue;
    }
    let allOk = true;
    for (let i = 0; i < events.length; i += MAX_BATCH) {
      // eslint-disable-next-line no-await-in-loop
      const ok = await postBatch(events.slice(i, i + MAX_BATCH));
      if (!ok) { allOk = false; break; }
    }
    if (allOk) {
      try { fs.unlinkSync(claimed); } catch { /* noop */ }
    } else {
      // Put it back for the next sweep rather than dropping it.
      try { fs.renameSync(claimed, claimed.replace(/\.claimed-\d+$/, '.jsonl')); } catch { /* noop */ }
      return;
    }
  }
}

/** Starts the periodic upload sweep. Idempotent. */
function start() {
  if (started || OPTED_OUT) return;
  started = true;
  getInstallId();
  if (!ENDPOINT) {
    log('no endpoint configured — recording locally only');
    return;
  }
  uploadTimer = setInterval(() => { void upload(); }, UPLOAD_INTERVAL_MS);
  if (uploadTimer.unref) uploadTimer.unref();
  void upload();
}

/** Best-effort final flush on shutdown. */
async function stop() {
  if (uploadTimer) { clearInterval(uploadTimer); uploadTimer = null; }
  try { await upload(); } catch { /* noop */ }
}

module.exports = {
  SCHEMA_VERSION, DIR,
  start, stop, record, ingest, summary, upload,
  getInstallId, isEvent,
  get enabled() { return !OPTED_OUT; },
  get endpointConfigured() { return !!ENDPOINT; },
};
