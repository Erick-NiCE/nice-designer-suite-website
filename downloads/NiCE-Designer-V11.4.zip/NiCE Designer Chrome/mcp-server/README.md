# nice-designer-mcp

Local MCP server that lets Claude drive the [NiCE Designer Suite plugin](../..) — Figma + Chrome — to audit and convert pages against the SOL and Lyra design systems.

## Architecture

```
Claude (stdio MCP client)
        ↓
nice-designer-mcp   (this package, Node, stdio)
        ↓  ws://127.0.0.1:7331
Figma plugin UI    /    Chrome extension background SW
```

The MCP server hosts a local WebSocket hub. When the Figma plugin or the Chrome extension is loaded, it connects out to the hub and registers itself as a `figma` or `chrome` target. Tool calls are correlated via a server-generated request id; the plugin buffers all `PluginMessage` replies emitted in response and returns them in one envelope.

## Install & run

```bash
cd packages/mcp-server
npm install
npm start        # runs the stdio MCP server + ws hub on 127.0.0.1:7331
```

## Claude Desktop

Packaged builds ship `Click to install Claude Connector.mcpb` at the top level of the Chrome bundle
(same folder as `manifest.json` — built via `npm run package` at the repo root, or manually with
`npx @anthropic-ai/mcpb pack packages/mcp-server "<output>.mcpb"`). Double-click the `.mcpb` file —
Claude Desktop shows an Install prompt with the server pre-configured, no config file editing and no
manual restart. This is also the flow the plugin's Supercharge tab walks users through.

## Claude Code

Claude Code doesn't support `.mcpb` bundles, so register the server directly:

```bash
claude mcp add nice-designer -- node /absolute/path/to/nice-designer-plugin/packages/mcp-server/src/index.js
```

Or add it to `~/.claude.json` by hand:

```json
{
  "mcpServers": {
    "nice-designer": {
      "command": "node",
      "args": ["/absolute/path/to/nice-designer-plugin/packages/mcp-server/src/index.js"]
    }
  }
}
```

Either way, exit the current session (`/exit` or `Ctrl+D`) and run `claude` again to pick up the new server.

## Skills

Every skill under `skills/` (root of the plugin repo) ships inside this server — `npm run sync:skills`
(wired into `build:mcpb`) copies the canonical `skills/` folder into `packages/mcp-server/skills/`
before packing, so the `.mcpb` a user installs is fully self-contained. Claude never needs its own
filesystem access to this repo to run a skill:

- `list_skills` — every skill's id, title, question, and one-line description.
- `get_skill({ id, file? })` — the full `SKILL.md` body for that id (or a specific reference file
  inside that skill's folder, e.g. `nice-product-knowledge`'s per-product write-ups).

At runtime, `get_skill`/`list_skills` try a live copy first — `https://erick-nice.github.io/
nice-designer-suite-website/skills/` (published by `npm run publish:skills`, a short-timeout fetch
so a dead network never stalls a tool call) — and fall back to disk if that's unreachable, checking
(in order) the bundled `packages/mcp-server/skills/`, then `<repo root>/skills` (so it also works
from a bare dev checkout via `npm start`, without running `sync:skills` first). This means an edited
or brand-new skill reaches every already-installed `.mcpb` connector with **no reinstall** — only a
genuinely new *tool* (new function name/schema) still needs one, since that's code inside the
connector itself. The server logs a boot-time warning if any skill in the catalog (`src/catalog.js`)
has no matching `SKILL.md` on disk, so a skill added to the catalog without its file (or vice versa)
fails loudly instead of silently 404ing later.

`npm run publish:skills` only stages files into that site's working tree — commit and push from
there to actually go live. That repo needs a root `.nojekyll` file for this to work at all: GitHub
Pages runs Jekyll by default, and Jekyll treats any file with YAML front matter — every
`SKILL.md` has one — as a page and silently renames its output to `.html`, breaking the raw-markdown
fetch above (`catalog.json`, having no front matter, is unaffected and easy to mistake for "it's
working"). Check that `.nojekyll` still exists at the site repo's root before assuming a publish
went out cleanly.

Trust note: because skill content is executed as instructions by whatever Claude session calls
`get_skill`, push access to the `nice-designer-suite-website` repo's `skills/` folder is equivalent
to shipping code to every connected session. Treat it accordingly.

## Tool surface (summary)

Audit (read-only): `run_full_audit`, `audit_colors`, `audit_text_styles`, `audit_spacing`, `audit_radius`, `audit_components`, `audit_accessibility`.

Conversion (dry-run by default): `convert_colors`, `convert_text_styles`, `fix_spacing`, `fix_radius`, `convert_component`, `fix_accessibility`, `convert_mode`, `undo_last_conversion`.

Cross-system: `generate_multi_system` (SOL↔Lyra duplicate + convert).

Dev handoff: `extract_dev_details`, `extract_all_css`.

Introspection: `list_targets`, `get_selection_info`, `check_libraries`, `export_design_tokens`.

Composites: `lyra_compliance_report`, `migrate_to_lyra`.

Escape hatch: `call_plugin` — sends any raw `UIMessage` (see `src/types.ts`) to the plugin.

## Environment

- `NICE_MCP_WS_PORT` — override the WebSocket hub port (default `7331`).
