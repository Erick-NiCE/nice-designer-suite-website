# Persona skill template — not a real skill

This directory is a scaffold, not a shipping skill. It has no catalog entry, so
`list_skills`/`get_skill` never surface it and it never appears on the
Supercharge page — see `TOOLS_BY_NAME`/`SKILLS` lookup in
`packages/mcp-server/src/catalog.js`, which only knows about ids it lists
explicitly. It still travels inside the `.mcpb` (`npm run sync:skills` copies
all of `skills/` wholesale) purely so it's on hand as a reference when someone
adds the next persona — that's harmless since nothing calls it.

Use `SKILL.md.template` as the starting point for a new persona skill. See
`HOW-TO-ADD-A-PERSONA.md` for the full checklist (catalog entry, connectors).
These personas are all public and publish normally — no privacy withholding
by default.

## Why this exists

The purpose is to **vary responses** — an "everything god bot" is useful, but a
set of simpler, more limited personas can bring a genuinely different
perspective to a project by not knowing or not being able to do everything the
default assistant can. The main function is **interviewing the persona** —
asking it research questions and getting an in-character answer, the way
you'd run a discussion guide past an actual participant. The same persona
also doubles as a design/feature critique lens and a prioritization input.

Every persona is specced with the same five fields (see
`SKILL.md.template`): **Persona Name**, **Description** (who they "are" in
their digital life), **Persona Responsibilities** (purpose, and what it
should NOT do), **Connectors and Knowledge** (what it can access, and what
it's deliberately "blind" to), and **Tone** (how it responds, whether it
mimics a specific type of user). The blindness idea is what keeps a persona
from quietly collapsing back into the everything-capable default — it's a
behavioral instruction, not a technical restriction, so writing it well
matters more than the tool-access list does.

Every persona skill is credited to **UX Research** (`author: 'UX Research'`,
`thirdParty: true`) in the catalog, the same pattern as the `ux-research-*`
set contributed by Serena Yang, so they land in the Supercharge Marketplace
tab rather than the in-house tool groups.
