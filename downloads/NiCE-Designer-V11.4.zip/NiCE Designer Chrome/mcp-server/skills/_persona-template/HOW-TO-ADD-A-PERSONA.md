# Adding a new persona skill

Follow this in order — the catalog validation (`npm run gen:catalog`) will refuse to build if a
step is skipped.

## 1. Write the skill

Copy `SKILL.md.template` to `skills/persona-<slug>/SKILL.md` and fill it in. Delete the HTML
comment block at the top — it's build notes, not skill content. Keep the `description` frontmatter
specific: it's the only thing that decides whether this skill triggers, so lean on the persona's
actual vocabulary and situation, not generic UX phrasing that could match any persona.

The template is organized around the five fields UX Research specs every persona with — fill in
all five, none is optional:

| Field | What it answers | Where in the template |
| --- | --- | --- |
| Persona Name | Get personal — a real name, not a role label | The H1 |
| Description | Who they "are" in their digital life | `## Description` |
| Persona Responsibilities | Purpose of this agent; what it should NOT do | `## Persona Responsibilities` |
| Connectors and Knowledge | Tools/data it can access; what it's deliberately blind to | `## Connectors and Knowledge` |
| Tone | How it responds; does it mimic a specific type of user | `## Tone` |

**Access vs. blindness are different mechanisms — don't conflate them when filling in Connectors
and Knowledge:**

- **Access** is real and enforced by the catalog entry (step 3 below): a tool not listed in that
  persona's `tools`/`clients` genuinely cannot be called on its behalf.
- **Blindness** is a behavioral instruction inside the skill body, not a technical restriction —
  the tool or knowledge may still be reachable in the session, but the persona is told to react
  the way the real person would (not know, guess wrong, ask what that even means) rather than
  reach for it. This is what makes a persona feel like a specific limited person instead of the
  default assistant wearing a costume — get concrete about what a *real* person like this
  wouldn't know, not just what would be convenient to restrict.

## 2. Public by default

These personas are cleared for public release — they publish to the public
`nice-designer-suite-website` Pages site like most of `skills/`, with no `NO_PUBLISH_FILES` entry
needed. Two things still apply even though nothing is being withheld:

- Only include a real company or participant name if it's actually been cleared for public use;
  otherwise refer to the customer/participant by the persona name the skill already gives them.
- If a later persona *does* need to be withheld (e.g. it's built from research that turns out to
  be confidential), add its id to `NO_PUBLISH_FILES` in `scripts/publish-skills.mjs` then — same
  mechanism `eac-framework-guide` and `team-strengths` would use, just not the default here.

## 3. Add the catalog entry

In `packages/mcp-server/src/catalog.js`, add an entry to the `SKILLS` array:

```js
{
  id: 'persona-<slug>',
  title: '<Persona Name> — <Role>',
  group: 'personas',
  clients: '<both | figma | chrome>',   // pick per what this persona is actually used against
  question: '<the question someone asks that should trigger this>',
  what: '<one sentence: who this persona is and what grounds it>',
  benefit: '<one sentence: what a design decision gets from using this over a generic user>',
  tools: [/* MCP tool names this persona is meant to pair with, or [] for pure narrative context */],
  author: 'UX Research',
  thirdParty: true,
},
```

**`clients` and `tools` are decided per persona, not inherited** — that's the whole point of the
base being separate from any one persona. A persona built for reviewing Figma critiques might set
`clients: 'figma'` and pair with `get_selection_info`/`extract_dev_details`; one meant for live
dark-mode QA reactions might set `clients: 'chrome'` and pair with `audit_colors`/`polish_page`; a
persona used purely as a prioritization lens (no design artifact involved) should set `tools: []`
and `clients: 'both'`.

## 4. Regenerate and verify

```bash
npm run gen:catalog
```

This fails loudly if the group id is wrong, a required field is missing, or the id has no
`SKILL.md` on disk — read the error, it names the exact problem.

## 5. Update CLAUDE.md

Add a row to the skills table under a "Persona skills" note, same as the other marketplace sets —
see how `ux-research-*` and `eac-framework-guide` are documented there.
